# Architecture Decision Records

V1 不为每个小决定写ADR。规范本身是事实来源；ADR记录**重要决策为什么这样做**，不替代03–07的当前可执行contract。

## 何时需要

- 用户批准的重大架构变化，例如同步SQLAlchemy改异步、单体拆服务、引入队列/外部存储。
- 改变核心实体或source of truth，例如ProductionBatch改为绑定EventProductPlan、持久化库存余额、改变reservation或数值推荐语义。
- 对FROZEN API/schema/state产生跨模块影响、需要长期追溯的spec change。
- 值得保留取舍背景的核心决策；例如“为什么ProductionBatch属于Product”可在需要回顾时记录，不要求为本次整理补写全部历史ADR。

## 何时不需要

局部变量命名、private helper拆分、注释、测试fixture、等价查询优化、常规bug修复、没有contract变化的普通索引优化。按07在任务报告中说明即可。

## 变更顺序

1. Agent发现重大问题，先按AGENTS输出`SPEC CHANGE REQUIRED`，给出具体规则和影响。
2. 等待用户明确批准；如未批准，不把提案标成Accepted，不修改冻结契约或实施依赖代码。
3. 批准后更新受影响spec，并写一份简短ADR记录批准依据及决定。
4. 实施migration/代码/测试，核验兼容性；任务报告链接spec/ADR。

05中的SC-01至SC-05目前只是待审问题记录，**不等于Accepted ADR**。生成本README不表示用户已同意任何提案。

## 命名与模板

文件名：`ADR-001-short-title.md`，依次递增。一个重大决策一份，不要求一项代码改动一份。

```markdown
# ADR-001 · 决策标题

- Status: Proposed / Accepted / Rejected / Superseded
- Date: YYYY-MM-DD
- Affected spec: 文件与规则编号
- Approval: 用户明确批准的日期 / 对话位置；未批准写Pending

## Context
具体问题、现行规则及反例。

## Decision
批准后的精确规则；可简述关键替代方案与不采用的原因。

## Consequences
API/schema/state/migration/tests影响；限制与兼容性。

## Verification
对应测试、验收结果或后续检查。
```

被新决策替代时保留旧文件并标记Superseded，链接新ADR。不要静默改写历史批准内容。

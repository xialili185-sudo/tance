# V1 后端未决规则实施提案

状态：APPROVED（2026-09-21）。用户在本任务明确回复：“批准全部五项，完成 V1 后端”。以下规则覆盖 03–06 中对应旧规则与待批准标记。原文提案措辞保留用于追溯。

## SPEC CHANGE REQUIRED — SC-01 库存

Affected spec: 03 InventoryAllocation；04 §12/13；05 SC-01；06 Inventory/Sales。
Current rule: 累计分配量 A ≤ 现货 C − 其他活动预留 O。
Problem: 本场已售 S 后，现货已扣 S，再用累计 A 比较会重复扣减。
Proposed change: A ≤ C − O + S；本场剩余预留为 A−S。Event 或 Plan 为 COMPLETED/CANCELLED 时不预留。全局要求 C≥0，活动预留合计≤C，A≥本场销量。库存写操作统一先锁 Product，再校验、写入，同一事务提交。
Impact: 不改表、不改响应字段；更正分配上限计算。到货、销售、分配、更正、结束展会均测试库存不变量与并发。

## SPEC CHANGE REQUIRED — SC-02 任务

Affected spec: 04 §14；05 SC-02。
Current rule: 非 DONE 且超时可能显示 OVERDUE。
Problem: 已取消任务也被显示为逾期。
Proposed change: 仅 TODO/IN_PROGRESS 且 due_at<now 显示 OVERDUE；DONE/CANCELLED 显示原状态。
Impact: 无迁移；响应派生值与边界测试变更。

## SPEC CHANGE REQUIRED — SC-03 历史警告

Affected spec: 03 QuantityDecision；04 §9；05 SC-03。
Current rule: API 返回 warnings，表没有保存位置。
Problem: 删除或更新需求信号后，不能还原历史警告。
Proposed change: QuantityDecision 增加 warnings JSON NOT NULL，生成时存 [{code,message}]，无警告存 []，历史读取不重算。仅在空 quantity_decisions 表上应用此新增列；若已有决策则停止迁移，另提旧数据策略。
Impact: 新增一条 Alembic revision；API 形状不变。不声称保存了全部原始输入或可精确重跑历史算法。

## SPEC CHANGE REQUIRED — SC-04 状态

Affected spec: 04 状态写入；05 SC-04。
Current rule: 状态集合与部分条件已定，完整迁移边未定。
Problem: 任意互转与严格线性流转都可能改变业务规则。
Proposed change: 采用 05 SC-04 的候选矩阵，未列迁移拒绝，同状态允许普通字段更正；不自动级联，不按日期自动变更。

- Event：PLANNING→PREPARING/CANCELLED；PREPARING→PLANNING/READY/CANCELLED；READY→PREPARING/COMPLETED/CANCELLED；终态不重开。
- Plan：PLANNING→PREPARING/CANCELLED；PREPARING→PLANNING/READY/CANCELLED；READY→PREPARING/SELLING/CANCELLED；SELLING→COMPLETED；终态不重开。
- Product/Content/Vendor：ACTIVE↔ARCHIVED。允许归档资产建立新引用，不额外添加禁止规则。
- Batch：PLANNED→SAMPLING/ORDERED/CANCELLED；SAMPLING→PLANNED/ORDERED/CANCELLED；ORDERED→PRODUCING/SHIPPED/RECEIVED/CANCELLED；PRODUCING→SHIPPED/RECEIVED/CANCELLED；SHIPPED→RECEIVED/CANCELLED；终态不重开。
- Sample：PENDING→APPROVED/REVISION_REQUIRED/REJECTED；结果可回 PENDING 修正。
- Task：TODO↔IN_PROGRESS；两者均可→DONE/CANCELLED；DONE→TODO/IN_PROGRESS；CANCELLED→TODO。
- Create 不额外收窄既定状态类型，仍校验目标状态必填条件；Batch Create 缺正式下单时间，因此 ORDERED/PRODUCING/SHIPPED/RECEIVED 创建会失败。
- Event/Plan 终态仍允许更正元信息及历史销售；允许更正/删除分配，但须有销售时不得删、累计量不得低于销售。终态分配不预留现货，每次历史销售更正仍校验全局库存。
- 已到货 Batch 允许更正数量/成本/日期，但不改 product_id、状态不回退；减量不得破坏库存不变量。
- 允许 Event 取消保留历史销量；Plan 仅按上述矩阵取消（SELLING 须完成）。不自动取消子实体。
Impact: HTTP 写入允许范围明确化；无新增状态或字段；测试每条迁移及终态更正。

## IMPLEMENTATION-TIME SPEC REQUIRED — SC-05 算法与汇总

Affected spec: 04 readiness/recommendation/overview/dashboard；05 SC-05；06 对应服务。
Current rule: 输入输出和三档扣库存公式已定，参数及汇总判定未定。
Problem: 无法从示例推出唯一算法，不能伪造推荐或固定返回演示数据。
Proposed change: 以下仅为可调的 V1 启发式初始配置，非统计验证结果。

### 需求与置信度

- 每类信号按 observed_at DESC、signal_id DESC 取一；0 是有效证据。未来 observed_at 不参与当前推荐；不删除原始记录。
- 转换候选：新印调×0.8、预订×1、手工估计×1、社媒×0.05、心愿×0.1、外部历史×0.8。内部历史取之前最近一场有销售记录的销量×0.8。重叠来源取最大值，不累加。
- 所有过去信号都可参与，但超过30天的印调/预订/社媒候选再乘0.5，降低新鲜度。其余不施加时间衰减。所有参数在统一 Python 配置中维护。
- 无来源返回 INSUFFICIENT_DEMAND_DATA；只有0值来源仍可生成0需求。
- balanced=向上取整最大候选；conservative=向下取整 balanced×0.8；aggressive=向上取整 balanced×1.2。三档均至少为当前预订量（超过30天的预订仍保留全量下界）。
- 各档 production=max(demand−physical stock,0)；不改成扣可分配量。
- 新鲜印调+新鲜预订→HIGH；新鲜印调/手工估计/内部历史任一→MEDIUM；其余→LOW。再贩缺新鲜印调降一级（最低LOW），添加 NEW_SURVEY_RECOMMENDED。LOW 选 CONSERVATIVE，其他选 BALANCED。
- 使用心愿、旧证据或外部历史时生成相应规则警告，说明启发式局限；LLM 不改数值。LLM provider 未选择时返回 UNAVAILABLE，保留可替换解释接口和失败降级测试，不假装已接入。

### 生命周期、历史与进度

- “此前场次”按 (start_date,event_id) 排序，小于当前场；仅有 SalesRecord 的场次算一轮（0销量记录也算），保留完成/取消场真实销售。当前之前记录数+1为 sale_round；外部历史不增加场次数。
- 当前计划最新 Decision 按 (created_at,decision_id) 降序；销售汇总取最新生成的 balanced_demand_estimate。可选 stale 两字段暂不提供，避免假装有完整输入快照。
- demand：无证据 MISSING，有证据 READY；recommendation：无记录 NOT_GENERATED，否则 GENERATED；final_quantity：未确认 UNCONFIRMED，否则 CONFIRMED（含0）；inventory：无行 NOT_ALLOCATED，否则 ALLOCATED；sales：无记录 NOT_STARTED，否则 RECORDED。
- production：Product 最新非取消 Batch（created_at,batch_id）状态，缺少则 NOT_STARTED；仅表示该商品的最新批次，不表示与本计划精确绑定。
- attention：缺需求、缺决策、未确认、缺分配分别生成对应 type，severity=WARNING；已到期未完成任务 type=TASK_OVERDUE、severity=WARNING。终态计划不产生准备提醒。按固定类型顺序、主键稳定排序去重。
- Event product_count 计全部 Plan；ready_product_count 计 READY/SELLING；demand_checked_count 计有有效证据；production_ready_count 计有分配且分配量>0；attention_count 计该场计划提醒及独立逾期任务数。

### 展会发现与 Dashboard

- 业务日期使用 Asia/Shanghai，可在统一配置调整。upcoming=true 指 end_date≥today 且非 COMPLETED/CANCELLED；false 指其补集。
- Listing 时间过滤要求整段展期包含在提供的可用日期范围中。城市去首尾空白后精确匹配。IP/tag 去首尾空白后不区分大小写精确匹配。
- 推荐排除已结束、CLOSED、报名截止已过的 Listing；保留 OPEN/UPCOMING/UNKNOWN，按此顺序再按 start_date/id 升序；指定 IP 必须匹配 tag。理由来自实际匹配字段。
- Dashboard next_event 取未结束、非终态 Event 按 start_date/id 最早一个；days_remaining 可为负（正在举办）。upcoming_tasks 取非终态 Event 的 TODO/IN_PROGRESS，due_at非空，按 due_at/id 升序前10（含逾期）。recent_products 按 created_at/id 倒序前5，使用既定 ProductSummaryResponse。production_summary 计全库对应状态批次数；attention 汇总活动展会提醒。

Impact: 新增确定性算法/聚合代码与边界测试；无新增 API/状态/表。以上所有规则须整体或逐项批准后实施，参数仍需后续真实销售数据校准。

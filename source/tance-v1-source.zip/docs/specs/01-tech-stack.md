# 01 · 技术栈

## 1. 已选技术（FROZEN）

| 层 | 技术 | V1 使用边界 |
|---|---|---|
| 前端 | Vue 3、TypeScript、Vite | 本文件只记录选择，不设计页面 / UI demo |
| 前端路由 / 状态 / 请求 | Vue Router、Pinia、Axios | 通过 API 消费数据；不在前端另建业务事实源 |
| 语言 / HTTP | Python、FastAPI | 单体后端；Router 只处理 HTTP |
| 校验 / DTO | Pydantic、pydantic-settings | 输入输出校验、配置读取 |
| ORM | SQLAlchemy 2.x | **同步** `create_engine`、`Session`；统一 Session 入口 |
| Migration | Alembic | 唯一 schema 演进路径 |
| 数据库 / 驱动 | MySQL、PyMySQL | 真实关系型约束；不以 SQLite 测试替代 MySQL 验收 |
| 测试 | pytest、HTTPX / FastAPI TestClient | 单元测试、HTTP 契约测试、MySQL 集成验证 |
| 运行 | Uvicorn | 启动 FastAPI |
| AI | LLM API + structured output | Python 算出数值后，LLM 可选生成解释 |

原对话只冻结主版本路线，未冻结 Python/FastAPI/MySQL 的具体小版本。首次安装时选兼容版本并记录实际版本；这不是允许改用另一套技术。SQLAlchemy 必须保持 2.x 风格，V1 不引入异步驱动或 AsyncSession。

## 2. Skeleton 最小依赖

```text
fastapi
uvicorn
sqlalchemy
pymysql
alembic
pydantic-settings
pytest
httpx
```

保存可复现的依赖版本；生产依赖与测试依赖可在同一 requirements 文件中分组，拆分文件属于实现组织。LLM provider SDK 仅在 AI 阶段且批准后加入；先建可替换 client 边界，不在 Skeleton 阶段安装 AI framework。

## 3. 未批准不得引入

LangChain、LangGraph、Redis、Kafka、Celery、microservices、DDD、复杂 Clean Architecture 分层，以及为这些路线增加的 repository/domain/use_cases/adapters 层。也不引入 Docker SDK、RAG / 向量库、事件总线、任务队列、独立缓存服务或通用工作流引擎。

增加依赖前写明：当前任务为何需要、标准库 / 现有依赖为何不足、版本、用途和维护成本；按 [07](07-development-rules.md) 获得明确批准。只使用已选库不需为每次 import 重复申请。

## 4. 配置（编纂约定）

`backend/app/core/config.py` 统一读取环境变量，`.env` 只在本地使用，`.env.example` 提供占位示例：

```dotenv
APP_NAME=TANCE API
DEBUG=true
DATABASE_HOST=localhost
DATABASE_PORT=3306
DATABASE_USER=your_user
DATABASE_PASSWORD=your_password
DATABASE_NAME=tance
LLM_API_KEY=
```

以结构化数据库配置构造连接 URL，正确处理密码中的特殊字符。`.env`、密钥、数据库密码不得提交或输出到日志。LLM key 未配置不应阻止基础 API 启动或 Python 数值推荐；解释视为不可用。

## 5. 跨层数据格式

- 钱：数据库 `DECIMAL(10,2)`，Python `Decimal`，JSON 十进制字符串，例如 `"20.00"`。不以 binary float 计算金额。
- 数量：非负整数；`ordered_quantity > 0`。主键与数量数据库使用 BIGINT；API 沿用原契约 JSON integer，不悄悄改为字符串 ID。
- 日期：`DATE` ↔ `YYYY-MM-DD`。时间：API 必须有 offset / `Z` 的 ISO 8601；编纂约定为应用统一转 UTC 存 MySQL DATETIME，读出恢复 UTC timezone 后序列化，不依赖操作系统默认时区。
- 状态：数据库 `VARCHAR` + Python Enum，不用 Status 表，不在迁移中创建 MySQL 原生 ENUM。
- 命名：数据库 / JSON 字段 `snake_case`，Python Schema / Model 类名 `PascalCase`；公共命名服从 03–06。

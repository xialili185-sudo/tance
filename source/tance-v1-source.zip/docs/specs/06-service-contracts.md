# 06 · Service Contracts V1

> 2026-09-21 已批准更新：SC-01–SC-05 以 [V1 完成决议](decisions/2026-09-21-v1-completion-proposal.md) 为准；本文原有“待批准”说明保留作历史记录，对应条目现已获批。
状态：公共职责、输入 / 输出含义、数据归属、依赖方向与业务不变量为 **FROZEN**。公共函数名称沿用原讨论，Python 具体 signature、实例 / 函数式组织与 private helper 划分不冻结。

## 1. 公共调用约定

- 输入为明确 ID、已校验 DTO、查询条件及统一 Session；输出为 DTO 所需业务结果或明确领域错误，由 Router 映射为 04 的 HTTP 响应。
- Schema 校验格式，Service 校验数据库存在性、唯一性、归属、状态、库存与业务历史。写入前合并 PATCH 后检查最终对象。
- 外层写 Service 管理事务，内部被调用函数不随意 commit；出错 rollback。读取不得偷偷生成持久记录。
- 数据事实从 SQLAlchemy 查询；允许 Service 互调以复用规则，但不允许循环依赖。跨服务读取不等于可以跨服务改写对方所有状态。
- 私有 helper、SQL 查询结构、缓存于请求内的中间值不冻结；不能引入跨请求的未批准 Redis 或持久余额表。
- 05 的待批准条目未解决前，不把相应服务标记为业务完成。

## 2. EventService

责任：管理用户的 EventPlan 与展会概览；不管理外部 Listing，不实现推荐算法。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| create_event | EventCreate | 创建 PLANNING；手工来源为 null |
| list_events | status/upcoming filters | EventSummaryResponse 列表与 total |
| get_event | event_id | EventDetailResponse；不存在则 EVENT_NOT_FOUND |
| update_event | event_id + EventUpdate | 合并字段、日期校验、已批准状态规则 |
| delete_event | event_id | 检查 Plan/Task 等下游；有依赖报 EVENT_HAS_DEPENDENCIES |
| get_event_summary | event_id | product_count、ready等计数与attention_count；SC-05 |

依赖：EventPlan/Task/Plan 只读查询；概览可调 EventProductService/TaskService。下层不反向调用 EventService 获取存在性，应直接读取轻量 Model 或共用不循环的查询 helper。

## 3. EventRecommendationService

责任：外部候选发现、匹配、解释与 Add to Plan。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| list_event_listings | city/status/date filters | Listing summary 列表与 total |
| get_event_listing | listing_id | Listing detail + tags + source |
| recommend_events | ip/preferred_cities/available dates | 真实候选及 match_reasons；不存推荐结果表 |
| add_listing_to_plan | listing_id | 创建独立 EventPlan 快照；阻止非取消来源重复 |

依赖：EventListing/EventListingTag；创建计划时可调 EventService 受控创建能力并共享事务；可选 AI 解释客户端。不通过 HTTP 请求自身接口。

流程：查询真实候选 → 日期 / 城市 / 报名过滤 → Tag/IP 匹配 → 排名 → 可选 LLM 理由。LLM 不能产生新的 event_listing_id、修改日期或声称不存在的报名状态。筛选与排序参数按 SC-05 定稿，不做 RAG。

## 4. ProductService

责任：长期制品、内容关联、全局库存事实和内部销售历史的统一读取。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| create_product / list_products / get_product | Create / filters / product_id | 04 的 Product DTO；默认 ACTIVE |
| update_product / delete_product | ID + Update / ID | 默认价格成对；保护业务依赖；支持归档 |
| get_current_stock | product_id | 全局 physical stock 整数；不存在 Product 报404 |
| get_sales_history | product_id | 按 Event 时间组织销量序列，系统内历史只查 SalesRecord |
| link_content / unlink_content | product_id + content_id | 校验实体与重复；只改 ProductContent |
| get_product_contents | product_id | 已关联 Content 摘要 |

**get_current_stock 冻结公式：**

```text
Σ ProductionBatch.received_quantity WHERE status=RECEIVED
− Σ SalesRecord.sold_quantity（通过 EventProductPlan 找该 Product；包含全部历史）
```

空 SUM=0；不减 Allocation；不加在途 ordered_quantity。负结果意味着数据不变量被破坏，应暴露业务冲突，不通过 max(stock,0) 隐藏。

依赖：Product/ProductContent/Content、ProductionBatch、EventProductPlan/SalesRecord 的直接只读查询。**不调 SalesService 或 InventoryService**，避免 Inventory→Product→Sales→Inventory 循环。

## 5. ContentService

责任：创作资产 CRUD 与使用关系读取，不处理商品价格、库存或业务状态。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| create_content / list_contents / get_content | Create / filters / content_id | Content DTO、使用数量 |
| update_content | content_id + Update | 更新作品元信息 / 归档 |
| delete_content | content_id | 有 ProductContent 返回 CONTENT_IN_USE |
| get_content_products | content_id | LinkedProductResponse 列表 |

原 Service 大纲没有逐个列 Content 函数，上述为既定 Content API 的直接映射。依赖 Content/ProductContent/Product 只读查询；关联写入归 ProductService，不双向互调。URL/路径不触发文件下载、上传或存储服务。

## 6. EventProductService

责任：Product 参与某场 Event 的计划与派生概况。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| create_plan | event_id + EventProductPlanCreate | 校验 Event/Product、唯一组合、默认价格复制、创建 PLANNING |
| list_event_products | event_id | Plan summary 列表 |
| get_plan | plan_id | Plan detail、lifecycle、progress、attention |
| update_plan | plan_id + Update | 价格对、READY/SELLING必填、已批准迁移 |
| delete_plan | plan_id | 下游 Demand/Decision/Allocation/Sales/Task 检查 |
| get_lifecycle | plan_id | is_resale、sale_round、previous_event_sales，不存数据库 |
| get_progress | plan_id | 业务步骤状态；不能直接拿 Task 完成值代替事实 |
| get_attention_items | plan_id | 规则触发的 type/severity/message |

依赖：ProductService 的库存/历史、DemandService 的 readiness、InventoryService 的分配读取、QuantityDecision/ProductionBatch/Task 直接查询或无循环的汇总函数。get_lifecycle 使用 ProductService 历史，不让 DemandService 反向依赖 EventProductService，避免 `EventProduct→Demand→EventProduct`。

不在 Plan 增加派生字段；ProductionBatch 属 Product，汇总的含义按 SC-05 定稿。生命周期规则统一封装在无循环共享函数或 ProductService 内部实现，不复制多套。

## 7. DemandService

责任：原始需求快照与当前证据准备度；不持久化数值推荐。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| add_signal | plan_id + DemandSignalCreate | INSERT新快照，不覆盖旧值 |
| list_signals | plan_id + signal_type? | 按 observed_at DESC 的历史 |
| delete_signal | signal_id | 删除错误快照；不覆写已存 Decision |
| get_latest_signal | plan_id + signal_type | 最新一条或 None，不求和 |
| get_latest_signals_by_type | plan_id | 每种类型至多一条的映射 |
| get_readiness | plan_id | level/checks/latest_signals/warnings/lifecycle |

**get_latest_signal** 按 observed_at DESC、signal_id DESC 取一；observed_at 决定新鲜度，created_at 表示录入时刻。累计 Wishlist/Preorder/Survey 不是增量；历史 21/29/38 的当前值为38。值0必须保留。

**get_readiness** 同时读取内部 SalesRecord 历史和本场信号；再贩缺新印调产生 warning，不能误判为完全不能推荐。等级与recent阈值待SC-05。依赖 ProductService.get_sales_history、Plan/Signal Model；不调 RecommendationService 或 EventProductService。

## 8. RecommendationService

责任：确定性数量推荐、持久化决策快照、用户最终确认与历史读取。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| generate_recommendation | plan_id | 新 QuantityDecisionResponse；有效输入才生成 |
| get_recommendation_history | plan_id | 决策摘要 newest first |
| get_decision | decision_id | 当次已存数值与解释；warnings缺口SC-03 |
| confirm_final_quantity | decision_id + final + note? | 更新final/confirmed_at，可多次确认，0合法 |
| check_stale | decision_id | is_stale/stale_reasons派生；不改旧数值 |

**generate_recommendation 的输入 / 输出责任：**

1. 验证 Plan；调用 DemandService 收集各类型最新快照与readiness；调用 ProductService 获取历史销售和 current_stock。
2. 无有效需求来源返回 INSUFFICIENT_DEMAND_DATA。再贩缺印调为降级 / 警告，不自动拒绝。
3. Python 算需求三档、confidence、strategy；以 physical current_stock 快照算 production 三档；recommended 数值对应 strategy。
4. 将计算结果传给可选 RecommendationExplainer。LLM 仅返回经校验的文本；失败仍保存并返回有效推荐。
5. 保存新的 QuantityDecision；final与confirmed_at初始为null。不覆盖上次结果，不自动创建 Batch / Allocation / Task。

依赖：DemandService、ProductService、QuantityDecision Model、AI explainer。不得让 AI 或 Router 直接创建 Decision；不得用 InventoryService 的“可分配量”替换冻结的 current_stock_snapshot。

`collect_current_signals`、`calculate_base_demand`、`calculate_quantity_options`、`calculate_confidence` 等可作为 private helper，但名称、数量和拆分不冻结。算法参数待 SC-05，不能用原对话示例充当实现。

## 9. ProductionService

责任：Vendor、Product 级批次、打样轮次与状态前置条件。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| create_vendor / list_vendors / get_vendor / update_vendor / delete_vendor | 相应DTO/ID | Vendor CRUD与引用保护 |
| create_batch / list_product_batches / get_batch | product_id / batch_id / Create | 03字段、04响应；默认PLANNED |
| update_batch | batch_id + Update | 合并校验、ORDERED/RECEIVED条件、库存影响 |
| delete_batch | batch_id | 仅PLANNED且无SampleRound |
| create_sample_round / list_sample_rounds | batch_id + Create / batch_id | 唯一轮次；打样可选 |
| update_sample_round / delete_sample_round | sample_id + Update / sample_id | 允许录错修正；不自动改Batch |

ORDERED/PRODUCING/SHIPPED/RECEIVED 必须有 vendor/cost/currency/ordered_at；RECEIVED 还需实际 received_quantity/received_at，不能用 ordered_quantity 默认冒充到货数。

依赖：Vendor/Batch/SampleRound/Product Model；到货修正影响库存时可调 InventoryService 的只读校验能力并共享事务（规则须先批准 SC-01），但 InventoryService 不反向调 ProductionService。

## 10. InventoryService

责任：现货预留及单 Plan Allocation；不保存库存余额，不把在途货当成可分配。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| get_allocation | plan_id | Allocation与04全部派生字段；缺行也返回状态 |
| upsert_allocation | plan_id + allocated_quantity + notes? | 新建/替换累计分配总量，不是增量 |
| delete_allocation | plan_id | 有任意SalesRecord则ALLOCATION_HAS_SALES |
| get_reserved_stock | product_id + 排除plan? | 活动展会的未售预留合计；不能跨Product相加 |
| get_max_allocatable_stock | plan_id | 可分配上限，具体口径必须按SC-01批准结果 |

依赖：ProductService.get_current_stock；Allocation/Plan/Event/SalesRecord 直接只读查询。**不调 SalesService**，避免循环。

原冻结上限为 current_stock - other active reservations；既有销量后的累计量比较存在 SC-01。不能把提案公式默默写进实现；批准后全服务与API同步。写入需保持 allocation>=本场销量、全局现货与reservation不变量，并在 Product 级事务保护下完成检查与写入。

## 11. SalesService

责任：日销售事实、录错修正、销售汇总。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| create_sales_record | plan_id + sale_date/quantity/notes | Allocation存在；每天一条；校验累计 |
| list_sales_records | plan_id | 日记录及remaining_after_sale |
| update_sales_record | record_id + Update | 用新值替换旧日事实，不双计；日期变更检查unique |
| delete_sales_record | record_id | 删除错误记录，派生库存恢复 |
| get_sales_summary | plan_id | allocation/total_sold/remaining/sell-through/planning_vs_actual |

依赖：SalesRecord/Plan/Allocation/Decision Model；可调用 InventoryService 读取分配 / 已批准库存校验。ProductService 不反向调用本服务。

无Sales→DemandSignal自动复制；不写HistoricalSales表。不自动完成Event或Plan；sales不能超过allocation。已完成展会的历史销售更正也会影响全局现货，按SC-01/SC-04审定后处理。summary用哪个Decision按SC-05确认。

## 12. TaskService

责任：展会行动事项、归属校验、完成时间和派生显示状态。

| 主要函数 | 输入 | 输出 / 责任 |
|---|---|---|
| create_task | event_id + TaskCreate | 校验可选Plan同Event；默认TODO |
| list_event_tasks / list_plan_tasks | event_id + filters / plan_id | 04的列表与display_status |
| update_task | task_id + Update | 校验归属、状态与completed_at同步 |
| delete_task | task_id | 可删除包括已完成任务 |
| get_display_status | stored status + due_at + now | 派生显示，不UPDATE数据库 |

依赖：Task/Plan/Event 直接查询；不调业务服务去“代做”到货或数量确认。Task事件归属不需要额外复合FK；CANCELLED逾期语义待SC-02。

## 13. DashboardService

`get_dashboard()`：无业务写入输入，输出04的DashboardResponse。调用 EventService、TaskService、ProductionService、EventProductService，并按需组合 ProductService摘要；只做聚合，不重写库存 / 需求算法。

空态固定为next_event=null、数组空、production_summary全0。非空筛选 / 排序 / 上限与业务日期规则见SC-05。Dashboard不能反向成为底层服务的依赖，不能写Analytics或Dashboard缓存表。

## 14. 推荐依赖方向与事务验收

```text
Dashboard → Event / EventProduct / Task / Production / Product
Event → EventProduct / Task
EventRecommendation → Event + optional AI
EventProduct → Demand / Inventory / Product
Recommendation → Demand / Product + optional AI
Production → Inventory（库存修正校验）
Sales → Inventory
Inventory → Product
Demand → Product
Product / Content / Task → SQLAlchemy Model查询
```

这是避免循环的可用组织，不强制每条查询都必须跨 Service。公共业务公式必须只有一个责任归属；直接查询Model不等于可以复制另一套库存算法。

最低跨服务验证：推荐与Product detail使用相同current stock公式；Demand最新快照不累加；Allocation/Sales并发时不超额；嵌套服务出错整次事务回滚；LLM失败仍有数值Decision；Task展示不写OVERDUE。完整测试要求见07。

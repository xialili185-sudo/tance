# 05 · 状态、派生值与业务不变量

> 2026-09-21 已批准更新：SC-01–SC-05 以 [V1 完成决议](decisions/2026-09-21-v1-completion-proposal.md) 为准；本文原有“待批准”说明保留作历史记录，对应条目现已获批。
本文件集中定义状态词汇与已确认规则。**状态集合已冻结，不代表原对话已经定义了所有迁移边。** 下文将既定规则与待批准矩阵明确区分；未批准的提案不进入实现。

## 1. 所有持久化状态与类型（FROZEN）

| 对象 / 字段 | 值 | 默认值 |
|---|---|---|
| EventPlan.status / EventStatus | PLANNING、PREPARING、READY、COMPLETED、CANCELLED | PLANNING |
| EventProductPlan.status / EventProductStatus | PLANNING、PREPARING、READY、SELLING、COMPLETED、CANCELLED | PLANNING |
| Product / Content / Vendor.status / AssetStatus | ACTIVE、ARCHIVED | ACTIVE |
| ProductionBatch.status / BatchStatus | PLANNED、SAMPLING、ORDERED、PRODUCING、SHIPPED、RECEIVED、CANCELLED | PLANNED |
| SampleRound.status / SampleStatus | PENDING、APPROVED、REVISION_REQUIRED、REJECTED | PENDING |
| Task.status / TaskStatus | TODO、IN_PROGRESS、DONE、CANCELLED | TODO |
| EventListing.registration_status / RegistrationStatus | OPEN、CLOSED、UPCOMING、UNKNOWN | UNKNOWN |
| QuantityDecision.confidence_level / ConfidenceLevel | LOW、MEDIUM、HIGH | Python 计算，无随意默认 |
| QuantityDecision.recommended_strategy / RecommendationStrategy | CONSERVATIVE、BALANCED、AGGRESSIVE | Python 计算，无随意默认 |

其他持久化 Enum：

| 字段 | V1 值 |
|---|---|
| Product.product_type / ProductType | BADGE、ACRYLIC_STAND、POSTCARD、BOOK、STICKER、PRINT、OTHER |
| Content.content_type / ContentType | ILLUSTRATION、DESIGN、COVER、LOGO、OTHER |
| DemandSignal.signal_type / SignalType | EVENT_INTEREST_SURVEY、WISHLIST_COUNT、PREORDER_COUNT、SOCIAL_ENGAGEMENT、MANUAL_ESTIMATE、EXTERNAL_HISTORY |
| Task.task_type / TaskType | APPLICATION、SURVEY、ARTWORK、SAMPLING、PRODUCTION、SHIPPING、EVENT_PREP、OTHER |

Content 早期曾提出 IMAGE/DESIGN/OTHER 的替代选项，后续 API 使用 ILLUSTRATION。本基线沿用原主方案，不同时暴露两套类型。数据库 VARCHAR + Python Enum；新增值仍是 contract change，不是普通重构。

## 2. EventPlan

| 状态 | 含义 |
|---|---|
| PLANNING | 已加入计划，尚未正式准备 |
| PREPARING | 正在印调、准备商品与生产 |
| READY | 关键准备完成 |
| COMPLETED | 本次参展完成 |
| CANCELLED | 不再参加 |

通常业务方向：`PLANNING → PREPARING → READY → COMPLETED`；取消通过 CANCELLED 表达，保留历史。数据库日期合法性不随状态放宽。

既定规则：默认 PLANNING；不因当前日期自动更新状态；有下游数据不得删除；COMPLETED Event 释放尚未销售的 reservation；历史 SalesRecord 继续扣减 physical stock。Event 状态不能替代商品级状态或 Task 状态。

原文没有定义 READY 必须满足多少计数、允许哪些跳步 / 回退、COMPLETED/CANCELLED 是否可重开、是否同步更新子 Plan。**这些不是已冻结逻辑**，涉及实现时走 SC-04/SC-05。

## 3. EventProductPlan

| 状态 | 含义 | 已确认前置条件 |
|---|---|---|
| PLANNING | 商品刚加入本场 | event/product 存在且组合唯一 |
| PREPARING | 做印调、数量决策、生产准备 | 价格可未定 |
| READY | 商品已准备好参展 | selling_price 与 currency 都存在 |
| SELLING | 本场销售进行中 | selling_price 与 currency 都存在 |
| COMPLETED | 此商品本场销售结束 | 保留历史数据 |
| CANCELLED | 本场不卖此商品 | 保留历史数据 |

通常方向：`PLANNING → PREPARING → READY → SELLING → COMPLETED`。价格在任何状态都成对；不是只在状态变化那一刻检查——READY/SELLING 的普通 PATCH 也不得把价格清空。

不把生产完成、分配完成或日期变化自动写成 READY/SELLING/COMPLETED。First Sale/Resale/Sale Round 是历史查询结果，不是 stored status。原文未冻结 READY 必须“存在已确认 Decision / 已到货 Batch / 非零 Allocation”等附加条件，不能擅加。

## 4. Product、Content、Vendor

ACTIVE 表示正在使用的资产 / 厂商；ARCHIVED 表示归档，不删除历史。Product 库存为 0 不把 status 写成 OUT_OF_STOCK；有参展计划也不把 Product 写成 SELLING。

已有关联业务历史的 Product、已被 Batch 使用的 Vendor 应归档，不能删除。Content 正被关联时删除返回 CONTENT_IN_USE。

归档不改变库存，不清除关联或历史；未定义“归档后是否禁止所有新关联”时不能自行加整套限制。恢复 ACTIVE 的允许性随 SC-04 的完整矩阵审定。

## 5. ProductionBatch

| 状态 | 含义 | 必须满足 |
|---|---|---|
| PLANNED | 准备生产 | ordered_quantity > 0；可无 vendor / 成本 |
| SAMPLING | 正在打样 | ordered_quantity > 0；原文未强制报价 |
| ORDERED | 已正式下单 | vendor_id、unit_cost、currency、ordered_at 非空 |
| PRODUCING | 厂商生产中 | 保留所有 ORDERED 条件 |
| SHIPPED | 已发货 | 保留所有 ORDERED 条件 |
| RECEIVED | 已实际收到 | 所有 ORDERED 条件 + received_quantity、received_at 非空 |
| CANCELLED | 批次取消 | 不计入库存；不能借取消抹掉已收货事实 |

通常方向：`PLANNED → SAMPLING → ORDERED → PRODUCING → SHIPPED → RECEIVED`。SampleRound 可为 0，因此不应强制每批必须打样；不打样路线需要允许 `PLANNED → ORDERED`（由“打样可选”直接推出）。

进一步规则：

1. 用目标状态枚举集合判断 required fields，禁止用字符串大小或 Enum 下标解释“>= ORDERED”。
2. unit_cost/sample_cost 等允许 0，但金额与 currency 成对；received_quantity 允许 0，不得用 truthiness 检查必填。
3. 只有 RECEIVED.received_quantity 参与现货；ordered_quantity 不参与库存，不允许在途库存预分配。
4. RECEIVED 不应再 CANCELLED；有销售信息后不能靠减少到货数造成负库存 / 超额预留。更正到货数的完整约束见 SC-01。
5. 仅 PLANNED 且无 SampleRound 可物理删除；其余情况返回 409。
6. 是否跳过 PRODUCING/SHIPPED、是否允许状态回退等尚无完整规则，见 SC-04。

## 6. SampleRound

PENDING 表示等待样品或评审；APPROVED 为通过；REVISION_REQUIRED 为需要修改后再打样；REJECTED 为本轮否决。round_number 表达轮次，不能增加 ROUND_1_FAILED 等枚举。

同 Batch 不重复轮次。新增轮次保留上一轮结果；样品通过不自动下单、不修改库存。API 允许修改 / 删除录错记录；不能以“快照”名义禁掉其已冻结 PATCH。

原文未要求 APPROVED 必有 received_at，也未定义终态能否改回 PENDING，不能擅加。推荐迁移矩阵放 SC-04 审批。

## 7. Task 的 stored 与 derived states

存储状态：TODO / IN_PROGRESS / DONE / CANCELLED。`TaskDisplayStatus = TaskStatus + OVERDUE` 只用于响应。

冻结规则：进入 DONE 时 Service 自动设 completed_at=now；离开 DONE 时清空 completed_at。对 DONE 重复 PATCH DONE 不应无故重写原完成时间（幂等编纂约定）。completed_at 不由客户端写。due_at=null 不会逾期。

原文 Task 物理设计给过：`status != DONE and due_at < now → OVERDUE`，会包含 CANCELLED；后续 Service 示例只写了 TODO。**CANCELLED 的显示行为存在歧义，见 SC-02**。不能把 OVERDUE 存进数据库或用每日后台作业更新状态。

Task 只提醒用户行动；`Task.status=DONE` 不会自动使 ProductionBatch RECEIVED 或 QuantityDecision confirmed。

## 8. registration_status、readiness、confidence 与 strategy

| 字段 / 值 | 含义 |
|---|---|
| registration_status=OPEN | 来源明确当前开放报名 |
| CLOSED | 来源明确已经截止 |
| UPCOMING | 尚未开放 |
| UNKNOWN | 没有明确报名信息 |
| readiness LOW/MEDIUM/HIGH | 当前需求证据完整度 / 可用度，响应派生值 |
| confidence LOW/MEDIUM/HIGH | 当次推荐置信等级，存 QuantityDecision 快照 |
| CONSERVATIVE/BALANCED/AGGRESSIVE | 当次选择三档中的一个策略，不等于用户最终决定 |
| explanation_status AVAILABLE/UNAVAILABLE | 是否有有效解释，派生值 |

registration_status 是持久化来源事实，不是 Task 逾期状态；deadline 可用于推荐过滤 / 提示，但不应定时覆写 UNKNOWN 为 CLOSED。日期和来源冲突时需透明提示，不能让 LLM编造“报名开放”。OPEN/CLOSED/UPCOMING/UNKNOWN 的候选过滤规则仍需 SC-05 的决策表。

readiness 不存 EventProductPlan；confidence 是当次 Python 计算结果而非 LLM 判断。没有有效需求证据时不生成数值；至少有合法证据时，即使再贩缺新印调，仍允许生成，给出风险与较低 confidence。有效 0 是数据，不等于缺失。

固定数值关系：

```text
production_conservative = max(demand_conservative - current_stock_snapshot, 0)
production_balanced = max(demand_balanced - current_stock_snapshot, 0)
production_aggressive = max(demand_aggressive - current_stock_snapshot, 0)
recommended_* 取 recommended_strategy 对应的一档
```

V1 不假定永远推荐 BALANCED，也不允许 LLM 改动策略或数量。需求 conversion/reliability/decay、readiness/confidence 阈值和策略选择规则尚未冻结，不填入伪精确参数。

## 9. 不能持久化的派生数据

| 派生项 | 责任来源 |
|---|---|
| current_stock、total_received、total_sold | ProductService，RECEIVED.received_quantity 减所有销售 |
| reserved_by_other_events、max_allocatable_quantity、unallocated_available_stock | InventoryService；SC-01 |
| event_remaining、remaining_after_sale、sell_through_rate | Allocation + SalesRecord |
| is_resale、sale_round、previous_event_sales | 历史 EventProductPlan + SalesRecord |
| demand_readiness、readiness checks、latest_signals | DemandService |
| production_status / progress / attention_items / counters | 各 Service 聚合；部分规则 SC-05 |
| Task.display_status=OVERDUE | Task.status + due_at + now；SC-02 |
| QuantityDecision generated/confirmed | final_production_quantity 是否为 null |
| explanation_status | recommendation_reason 是否含有效解释 |
| is_stale / stale_reasons | Decision 与后续证据变化比较 |
| days_remaining、Dashboard 汇总 | 当前日期及上述服务 |

“不能持久化”不包括已经明确保存的 QuantityDecision 数值 / confidence / strategy 快照。不能把当次快照改成读取时重算。

## 10. 待批准规范问题

以下为**可审阅提案**，不是现行 contract；本次文档整理未改代码或数据。后续 Agent 必须先取得明确批准，再按批准内容同步更新 03/04/05/06 及测试。算法阶段才需要解决的条目不阻塞 Skeleton。

### SC-01 · 累计分配上限与剩余库存

```text
SPEC CHANGE REQUIRED
Affected spec: 03 §14/17；04 §12/13；05 §5/9；06 InventoryService/SalesService
Current rule: C = physical current_stock；O = other active event reservations；
              max_allocatable_quantity = C - O；allocated_quantity <= C - O。
              allocated_quantity 是本场累计分配总量，Sales 已经从 C 扣除。
Problem: 已到货100，本场分配80、已售60，则C=40、O=0。
         原分配80不变也不满足80<=40，甚至把分配从80改为70也被误拒绝。
         原API例子的未分配库存也存在算术不一致。
Proposed change: 令 S=本场累计销量、A=本场累计分配量。
                 对活动计划：remaining_reservation=A-S；
                 max_allocatable_quantity=S+C-O；校验 S<=A<=S+C-O。
                 可新增的未售预留容量仍为C-O；不新增字段、不改变A含义。
                 active reservation仅计Event非COMPLETED/CANCELLED且
                 Plan非COMPLETED/CANCELLED的A-S。
                 unallocated_available_stock=C-Σ所有active remaining reservations。
                 Event/Plan结束或取消释放预留，不改变physical stock。
Impact: 不需schema migration；同名响应max_allocatable_quantity的计算需修正；
        修改InventoryService与相关契约测试，原始无销售场景结果不变。
        所有库存相关写入还须校验变更后的C>=0、全部active reservation<=C；
        Allocation不得低于已有销量；事务内按Product串行校验，防并发超分。
Status: 待用户明确批准。
```

提案一致示例：到货 100，全部已售 20，C=80；其他活动展会 O=30；本场 S=20，A=50，则 max=70、本场 remaining=30、unallocated=20。

应覆盖的验收反例：已有销量后保持 / 增加 / 减少总分配；两场同时分配；销售编辑与删除；历史 Event 补录销售；到货量下调；取消 / 完成释放；重开计划重新占用。终态写入是否允许，须和 SC-04 一并定稿，不能把释放后的历史 allocation 当作仍持有现货。

另一个限制保留原冻结含义：QuantityDecision 仍扣 **physical stock**，不自动扣除 other reservations。因此它不是“保证各展会同时足量”的跨展会计划器。若要让推荐扣 reservation，是另一项需批准的计算语义变更，不能随 SC-01 偷改。

### SC-02 · 已取消 Task 是否逾期

```text
SPEC CHANGE REQUIRED
Affected spec: 04 §14；05 §7；06 TaskService
Current rule: 原物理设计写status != DONE且due_at<now；后续示例仅说明TODO。
Problem: CANCELLED会被原公式显示成OVERDUE，和取消的含义不一致。
Proposed change: status in {TODO, IN_PROGRESS}且due_at非空且due_at<now时，
                 display_status=OVERDUE；其他情况display_status=status。
Impact: 无schema migration；调整派生状态与测试；存储枚举不变。
Status: 待用户明确批准。
```

due_at==now 不算逾期；DONE/CANCELLED 在提案下不会显示 OVERDUE。

### SC-03 · 历史推荐 warnings 的保真

```text
SPEC CHANGE REQUIRED
Affected spec: 03 QuantityDecision；04 QuantityDecisionResponse；06 RecommendationService
Current rule: 完整Decision API返回warnings；QuantityDecision无warnings列，
              不建QuantityDecisionSignal，原始Signal允许删除。
Problem: 重新读取历史Decision时无法保证重现当时的warnings。
         用今天的数据和规则重算再标作当时警告，会误导用户。
Proposed change: QuantityDecision增加warnings JSON NOT NULL，
                 由Python在生成时保存[{code,message}]，无警告保存[]。
                 历史详情读取快照，不重算覆盖；不增加信号关联表。
Impact: 需批准schema migration、Model/Schema映射及测试；API形状不变。
        若已有历史数据，不能把未知旧警告伪造成已知空列表，需另定回填策略。
        该字段只保存警告，不宣称补足全部历史输入或算法版本。
Status: 待用户明确批准。当前03字段表未添加此列。
```

批准前可实现计算和新生成的响应组装，但不能宣称持久化历史详情已完整符合 warnings 契约；不得把所有历史 warnings 固定为 [] 通过验收。

### SC-04 · 完整状态迁移矩阵

```text
SPEC CHANGE REQUIRED
Affected spec: 04所有状态PATCH/Create；05 §2–7；06状态写入服务
Current rule: 状态集合、通常流程、ORDERED/RECEIVED与Task条件已定，
              未穷举跳步、回退、终态重开、子实体同步规则。
Problem: 严格线性状态机和任意枚举互转都可能改变用户意图。
Proposed change: 审定下方候选矩阵；未列边拒绝，同状态PATCH只校验最终字段。
                 不按日期自动迁移，不自动级联父/子状态。
Impact: 无schema变化，但改变HTTP写入允许范围，必须补迁移边与前置条件测试。
Status: 候选矩阵尚未批准。
```

| 对象 | 候选允许迁移（并非已冻结） |
|---|---|
| EventPlan | PLANNING→PREPARING/CANCELLED；PREPARING→PLANNING/READY/CANCELLED；READY→PREPARING/COMPLETED/CANCELLED；COMPLETED/CANCELLED 不重开 |
| EventProductPlan | PLANNING→PREPARING/CANCELLED；PREPARING→PLANNING/READY/CANCELLED；READY→PREPARING/SELLING/CANCELLED；SELLING→COMPLETED；COMPLETED/CANCELLED 不重开 |
| Product/Content/Vendor | ACTIVE↔ARCHIVED；不级联改动历史 |
| ProductionBatch | PLANNED→SAMPLING/ORDERED/CANCELLED；SAMPLING→PLANNED/ORDERED/CANCELLED；ORDERED→PRODUCING/SHIPPED/RECEIVED/CANCELLED；PRODUCING→SHIPPED/RECEIVED/CANCELLED；SHIPPED→RECEIVED/CANCELLED；RECEIVED/CANCELLED 无出边 |
| SampleRound | PENDING→APPROVED/REVISION_REQUIRED/REJECTED；结果录错允许回到PENDING后修正，重新打样创建新轮次 |
| Task | TODO/IN_PROGRESS→DONE/CANCELLED且两者互转；DONE→TODO/IN_PROGRESS；CANCELLED→TODO；进入/离开DONE维护completed_at |

还须在同次批准中决定：终态后允许哪些销售 / 到货 / 分配事实更正；取消已有销量的 Plan 是否允许；归档资产能否新增引用；Create.status 是否限定为初始状态。未列问题不视为“矩阵默认允许”。当前文件不改03状态值或04请求字段。

### SC-05 · 算法与聚合规则未完成

```text
SPEC CHANGE REQUIRED
Affected spec: 04 Readiness/Recommendation/Overview/Dashboard；05 §8/9；06
Current rule: 输入、输出、确定性边界、三档与库存扣减公式已定；
              未给完整conversion/weight/decay/threshold/aggregation决策表。
Problem: 仅凭示例无法生成可信的需求数值、confidence或统一进度。
Proposed change: 在相应算法/聚合实施阶段提交下列决策表与输入输出用例，
                 用户明确批准后再实现；不更改已定API资源/数据库实体。
Impact: 算法与聚合测试；若需额外持久化字段或API值集合，另列具体变更。
Status: 尚未冻结；此条不批准任何默认算法参数。
```

待定义的最小表单：

| 决策 | 已有边界 | 必须补齐 |
|---|---|---|
| 需求估计 | 用最新快照 + 内部历史；Wishlist只辅助 | conversion、去重、权重、生命周期衰减、三档系数、整数取整、strategy选择 |
| readiness/confidence | LOW/MEDIUM/HIGH；再贩缺新印调需降级 | 各证据组合等级、有效期、0值行为、最低等级处理 |
| 生命周期 | 由以前发生销售的场次推导 | 同日场次顺序、0销量是否算一轮、完成/取消过滤、外部历史如何参与 |
| stale | 新信号可令推荐过时，旧结果不覆盖 | created_at/observed_at口径、补录旧快照、删除信号、库存变化、用户已确认时如何提示 |
| progress/attention | 原文仅有示例 | 每个progress字段的完整值域、触发条件、severity值域、去重与排序 |
| Plan production summary | 批次属于Product，不属于Plan | 多批次如何合并 / 选取production_status；不能伪造精确归属 |
| Event summary | product_count等输出已定 | ready/demand_checked/production_ready/attention_count判定 |
| Event recommendation | 真Listing；按date/city/registration/tag筛选 | 日期包含或重叠、UNKNOWN/UPCOMING处理、过期报名、tag标准化与排序 |
| Dashboard | 空态和主要字段已定 | next_event/upcoming/recent筛选、上限、业务日期时区、recent_products非空形状 |
| Sales summary | 数量/售罄率公式已定 | 多Decision时balanced_demand_estimate选最近生成还是最近确认 |

此清单禁止用随机数、固定样例或 LLM 自由判断填空。无需提前引入新表或框架来解决这些业务规则问题。

# 02 · 架构、职责与目录

## 1. 调用链（FROZEN）

```text
Vue → Axios → FastAPI Router → Service → SQLAlchemy → MySQL
                 ↕                │
            Pydantic Schema       └→ RecommendationService
                                       ├→ Python deterministic calculation
                                       └→ optional LLM explainer
```

EventRecommendationService 同样先查询真实 EventListing、筛选与排序，再可选解释。不能让 LLM 凭空生成展会。

## 2. 各层职责

| 层 | 必须承担 | 禁止承担 |
|---|---|---|
| Router | 路径、HTTP method/status、依赖注入、调用 Service、响应映射 | 写 SQL、计算库存、需求算法、散落业务状态规则 |
| Schema | 类型、必填 / 可空、长度、范围、金额 / 时间序列化、DTO | 访问数据库判断存在性、重复关系或业务历史 |
| Service | 业务校验、状态规则、跨实体计算、写操作事务、读取聚合 | 改写 API 契约、让 HTTP 细节渗入算法 |
| Model | 映射字段、关系、PK/FK/unique/index | 生成 API 形状、调用 LLM、持有 UI 派生状态 |
| AI | 接受已算结果和证据摘要、验证结构化解释、故障回退 | 决定数值、写业务表、覆盖 Python confidence / strategy |
| core/config | 读取 / 验证配置 | 内嵌真实密码、创建业务表 |
| db/base / session | DeclarativeBase、Engine、SessionLocal、get_db | 提交业务决策、导入 Router 或 AI |
| main.py | 创建 FastAPI、metadata、注册 Router / 异常映射 | 连接检查、SQL、业务逻辑、自动建表 |

`end_date >= start_date` 等纯输入关系可由 Schema 校验；PATCH 必须在 Service 合并旧值后再次校验最终对象。不可把“请求字段 Optional”误解为“数据库 NOT NULL 字段可被清空”。

## 3. AI 故障边界（FROZEN）

1. 收集原始信号、历史销售和库存，Python 完成 readiness、三档需求 / 生产量、confidence、strategy 与规则警告。
2. QuantityDecision 的数值只取 Python 结果。历史结果不可因重新计算或 LLM 文案改变而被覆盖。
3. 将不可修改的数值与摘要交给 `RecommendationExplainer`。使用结构化响应；不接受 LLM 额外输出的替代数量 / 策略。
4. timeout、缺 key、provider 错误、无效结构化输出均降级：`recommendation_reason=null`、`explanation_status=UNAVAILABLE`；有效推荐仍保存并返回 201。
5. 有合格解释时返回 `AVAILABLE`。解释不得暗示 LLM 改变过数值，也不得把不可靠信号包装成确定事实。

不新增异步作业协议或队列。外部调用应有有限超时，不持有库存行锁等待 LLM；本地实现可先计算、关闭读取事务后请求解释，再短事务保存快照。其间新数据可使推荐变 stale，不能悄悄重算旧结果。具体 helper 和同步 client 实现不冻结。

## 4. 数据库与事务（编纂约定）

- V1 使用同步 Session，按请求 / 明确业务操作管理生命周期，异常 rollback，结束 close；不共享可变全局 Session。
- 最外层写 Service 管理一次业务操作的事务。Service 互调时共享同一 Session；被调用 helper 不独立 commit，避免一半成功一半失败。
- `add-to-plan` 的非取消重复检查必须和创建原子完成；可锁对应 EventListing 行，不添加错误的 `UNIQUE(source_event_listing_id)`。
- 同一 Product 的销售、分配、到货修正等库存相关写入，应通过统一事务和一致锁顺序保护，防止并发检查均通过。锁与 SQL 写法是实现选择，业务不变量不可改。
- DB unique/FK 是最后防线；Service 给出业务错误。完整性冲突 rollback 后映射约定的 409/404，不把数据库异常原文回传。
- 单用户不等于单请求；不能只在应用内“先查再写”而忽略并发。

## 5. 目录（SEMI-FROZEN）

```text
TANCE/
├── AGENTS.md
├── docs/specs/                     # 本规范集合
├── backend/
│   ├── app/
│   │   ├── api/
│   │   │   ├── health.py
│   │   │   ├── events.py
│   │   │   ├── event_listings.py
│   │   │   ├── products.py
│   │   │   ├── contents.py
│   │   │   ├── event_product_plans.py
│   │   │   ├── demand_signals.py
│   │   │   ├── recommendations.py
│   │   │   ├── vendors.py
│   │   │   ├── production.py
│   │   │   ├── inventory.py
│   │   │   ├── sales.py
│   │   │   ├── tasks.py
│   │   │   └── dashboard.py
│   │   ├── models/                # 03 的 15 个实体
│   │   ├── schemas/               # common + 各资源 Schema
│   │   ├── services/              # 06 的 12 个 Service
│   │   ├── ai/
│   │   │   ├── client.py
│   │   │   ├── prompts.py
│   │   │   └── recommendation_explainer.py
│   │   ├── core/config.py
│   │   ├── db/
│   │   │   ├── base.py
│   │   │   └── session.py
│   │   └── main.py
│   ├── alembic/versions/
│   ├── alembic.ini
│   ├── tests/
│   ├── .env                       # 本地，不提交
│   ├── .env.example
│   ├── .gitignore
│   └── requirements.txt
└── frontend/                      # 这里只保留系统边界，不生成页面
```

Python package 按需加 `__init__.py`。Model module 拆分、测试 fixture、私有函数组织可调整并说明；不得借目录调整引入 repository/domain/use_cases/adapters 等额外层。

## 6. 对外边界

- 对外资源名称、API DTO 见 04；DTO 不等于表。汇总响应不能导致 Model 增加冗余字段。
- API 基础路径为 `/api/v1`。Skeleton 使用 **`GET /api/v1/health`**，不额外自创 `/health` 别名。
- Service 可互调但不得形成 `A → B → A`。Dashboard 位于聚合最上层，其他 Service 不反向依赖 Dashboard。
- FK 与级联不替代业务删除校验；例如 ProductContent 允许 DB CASCADE，Content API 仍先拒绝删除正在使用的 Content。

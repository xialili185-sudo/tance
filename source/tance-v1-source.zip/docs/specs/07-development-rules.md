# 07 · 开发规则、工程基线与验收

> 2026-09-21 已批准更新：SC-01–SC-05 以 [V1 完成决议](decisions/2026-09-21-v1-completion-proposal.md) 为准；本文原有“待批准”说明保留作历史记录，对应条目现已获批。
## 1. 三层冻结边界

| 层级 | 内容 | Agent 可否自行调整 |
|---|---|---|
| FROZEN | 实体、字段类型/nullable/含义、关系、PK/FK/unique、存储vs派生、状态值与已定规则、API method/path/字段/响应/error、库存/快照语义、AI边界、公共Service职责 | 不可；明确批准后先改spec再改代码 |
| SEMI-FROZEN | 模块内组织、查询方式、公共职责的实现拆分、普通性能索引、响应组装、测试fixture、事务/锁的具体实现 | 可在不改变外部行为时调整，报告原因和验证 |
| FLEXIBLE | 函数内变量名、private helper名称/实现、注释、测试样例、日志措辞、局部SQLAlchemy表达方式 | 可自主选择，仍受事实/隐私/测试约束 |

优先按**影响**分类，不按文件名分类。private helper 若改变数量公式或金额取整，就是 FROZEN 变更；加普通索引可能属 SEMI-FROZEN，加 UNIQUE 改业务约束则属 FROZEN。把公开字段加长、新增状态、新增普通列写成“正常 migration”并不免除批准。

## 2. 每次编码工作流

1. 读取 AGENTS.md、00、本文以及任务适用的01–06。先查05的待批准条目，不能直接照猜测实现。
2. 说明本次范围、受影响模块、所依赖规则和最低验收场景。保持任务小而完整。
3. 对照FROZEN contract，列出新增/修改/删除的接口或字段；若涉及变更或规范缺口，停止受影响实现，输出下述模板。
4. 没有冲突时实施最小改动。先跑通业务事实与确定性计算，再接可选AI。
5. 运行与改动有关的测试、migration检查或烟测；失败就修复，不用修改spec来“让测试通过”。
6. 对照spec复核结果、边界与失败路径，确认没有增加额外资源/状态/冗余表。
7. 报告files changed / tests run / spec impact，注明实际未执行的检查与未解决项。

```text
SPEC CHANGE REQUIRED
Affected spec: <文件 / 章节 / 规则编号>
Current rule: <现行规则或未定义项>
Problem: <具体反例 / 冲突>
Proposed change: <精确规则 / 字段 / API diff>
Impact: <调用方、数据库、migration、状态、测试、兼容性>
```

等待用户明确批准；仅“继续写代码”不等于批准未展示的contract change。批准后同步spec→migration/代码→测试；拒绝则保持现行规则并说明无法完成的受影响部分。无关已授权工作可以继续。

## 3. 依赖与架构纪律

- 首轮只安装01的最小依赖；版本记录到requirements或项目采用的锁定文件。不要为了一个helper引入framework。
- 新库、外部服务、异步DB、消息队列、缓存、架构层均先解释必要性并取得明确批准。已授权依赖不需每次使用再次申请。
- 不引入LangChain/LangGraph/Redis/Kafka/Celery/microservices/DDD/复杂Clean Architecture；不加repository/domain/use_cases/adapters套层。
- 不在Router写SQL或库存/推荐逻辑；不在Model调用AI；不在main.py创建表。
- Secret只通过配置注入；`.env`、`.venv`、缓存、测试数据库产物不提交。`.env.example`只放占位值。
- 调用外部LLM必须有限超时；结构错误或不可用降级为解释缺失，保持有效Python数值结果。

## 4. Migration规则

1. Alembic是schema唯一演进路径。应用启动与日常测试不得用`Base.metadata.create_all()`代替真实migration。
2. 改Model前对照03；改变FROZEN字段必须先有用户批准。数据库实际结构、Model、migration、spec保持一致。
3. Alembic env导入统一Base以及所有已实施Model，使target_metadata完整；不能因漏import把已有表误判为应删除。
4. autogenerate只是生成草稿，必须审阅字段nullable/default、FK/ON DELETE、unique/index和潜在drop；禁止盲目执行。
5. 不改写已经共享/应用的历史revision。追加新revision，说明upgrade与downgrade行为；可能丢数据的操作明确写出影响并按任务权限处理。
6. 在专用MySQL测试库验证空库upgrade到head；有既有数据的变更还需验证从上一版本升级。不要用真实用户数据做破坏性测试。
7. 对索引变更说明支撑的查询；不得未经批准把非唯一索引改成唯一约束。
8. UTC时间转换发生在应用边界；MySQL DATETIME无时区，不能只声明timezone=True就声称已保存offset。

## 5. 测试最低要求

按当前阶段执行相关项，不在Skeleton阶段一次构建全套业务测试。测试验证可观察行为和关键反例，不复制实现细节。

| 改动 | 最低验证 |
|---|---|
| Skeleton | FastAPI启动；GET /api/v1/health→200且精确body；配置可读；真实MySQL连通；Alembic能生成/应用最小Product migration；pytest health通过 |
| CRUD/API | 正常创建/读/改/删；404；长度/类型/nullable；PATCH省略vsnull；status code与统一error形状 |
| 关系/unique | 重复ProductContent、Event+Product、Batch+round、Plan+date被拒；Task跨Event归属拒绝；FK/删除保护 |
| 金额/时间 | Decimal字符串与价格对；零金额合法；无时区datetime拒绝；带offset往返保留同一时刻 |
| Demand | 新snapshot不覆盖；按observed_at取最新；补录旧快照不冒充最新；0值保留；不能累加累计值 |
| Recommendation | 已批准算法的确定性用例；三档有序；production=max(demand-stock,0)；缺证据422；缺新印调降级；历史不覆盖；final=0与重复确认 |
| AI | timeout/缺key/无效结构不影响数值Decision成功；不能用LLM数量覆盖Python结果 |
| Production | ORDERED必填集合；RECEIVED包含全部下单条件与实际到货；下单100收到98只计98；非RECEIVED不计库存 |
| Inventory/Sales | Allocation不扣现货；销售扣现货；不超过分配；同日PATCH不是累加；SC-01批准后的已售补货/并发/释放/更正回归 |
| State/Task | SC-04批准矩阵的允许/拒绝边；DONE/completed_at一致；display_status不持久化；SC-02取消逾期回归 |
| Migration | 真实MySQL上检查PK/FK/unique/index/nullability、空库upgrade；必要时验证旧版本升级与安全downgrade |
| Aggregation | 空数组/null/零值；SC-05批准后验证非空计数、排序、选取与不重复计算 |

单用户应用也可能有并发写请求；涉及库存、重复加入与唯一组合时必须验证原子性。集成测试使用隔离数据库；仅SQLite通过不能标记MySQL验收完成。

## 6. Definition of Done

- 范围内代码符合已批准spec，没有私自改接口、字段、状态或业务含义。
- 新行为与错误路径有适度测试；对应测试实际通过。未执行的MySQL/migration检查明确标注，不能假装完成。
- 涉及数据库时Model/migration/spec一致；无需启动自动建表。
- Decimal、timezone、nullable与derived语义跨Model/Schema/Service一致。
- LLM故障不影响数值推荐；没有秘密信息进入代码、输出或日志。
- 没有未说明的FROZEN变更；待批准SC条目仍未解决的相关模块不能宣称业务完成。
- 交付报告包含三个固定栏目：

```text
files changed: <路径 + 修改目的>
tests run: <实际命令/检查 + 结果；未执行项和原因>
spec impact: <none / approved change及批准记录 / pending SPEC CHANGE REQUIRED>
```

“已生成文档”“已通过文档校验”“后端运行通过”是三个不同结论，不得混用。

## 7. Backend Skeleton严格启动顺序

```text
SDD baseline
→ backend dirs
→ venv / dependencies
→ config
→ db/base/session
→ main + health
→ MySQL
→ Alembic
→ minimal Product model smoke test
→ migration
→ pytest
→ 正式 models
→ CRUD
→ business services
→ algorithm
→ AI
```

| 步骤 | 要做什么 | 通过条件 |
|---|---|---|
| 0 SDD baseline | 根AGENTS + 8份spec + decisions规则；识别待批准项 | Agent可按文件找约束；不把提案当冻结事实 |
| 1 backend dirs | 建app/api/models/schemas/services/ai/db/core、tests | 按02；Python包可导入 |
| 2 venv/dependencies | backend/.venv、最小requirements，记录兼容版本 | 依赖安装正常；不加AI framework |
| 3 config | pydantic-settings；APP_NAME/DEBUG及分项DB配置 | `.env.example`可参考；真实secret未提交 |
| 4 db/base/session | DeclarativeBase、同步Engine、SessionLocal、get_db | 唯一标准Session入口；能回滚/关闭 |
| 5 main+health | app元信息、health Router | FastAPI能启动，`GET /api/v1/health`返回`{"status":"ok"}` |
| 6 MySQL | 配置本地/指定开发库，独立连通性检查 | SQLAlchemy真实连接成功 |
| 7 Alembic | 初始化env/versions/target_metadata | 配置正确、从env读连接配置 |
| 8 minimal Product | 只用Product验证ORM与metadata链，不加CRUD | 最小模型可被Alembic发现 |
| 9 migration | revision autogenerate→人工审阅→upgrade head | MySQL实际出现正确Product表 |
| 10 pytest | health test与上面已完成的smoke核对 | health通过，真实DB/migration证据明确 |

最小Product仅指验证范围小，不重新设计Product。原Skeleton示例只列product_id/name/product_type/description/status/created_at/updated_at；本基线**优先采用03的完整小型Product表**（含可空default_selling_price/default_currency），仍只实施一张表，避免遗漏默认价格字段成为“新正式版本”。若任务明确要求分阶段少字段烟测，必须标注为临时阶段，并在正式Product CRUD前追加迁移补齐03；不得删掉既定字段或把阶段性模型宣布为完整V1。

示意命令（实施时在backend目录执行；本文件生成阶段未执行这些命令）：

```sh
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m uvicorn app.main:app --reload
.venv/bin/alembic revision --autogenerate -m "create product"
.venv/bin/alembic upgrade head
.venv/bin/python -m pytest tests/test_health.py
```

Alembic init/config与Model import先完成，再执行revision；启动server与后续命令在不同终端进行。命令不是跳过spec审阅或数据库权限的授权。

## 8. Skeleton之后

1. 正式15个Model与关系，完成V1 migration。
2. Event/Product/Content CRUD与关联，验证HTTP↔Service↔MySQL。
3. EventProductPlan/DemandSignal/Task基本能力。
4. Production/Inventory/Sales业务服务；进入冲突路径前先解决SC-01/02/04。
5. 在已冻结输入输出内提交确定性算法决策表，解决SC-05相关部分并实现测试；解决SC-03后完整持久化历史推荐。
6. 最后接可选LLM解释、Event recommendation与Dashboard聚合；剩余SC-05逐项审定。

不同时铺开全部前后端、AI与基础设施；当前任务没有要求编码时，只交付文档，不擅自创建数据库、安装依赖或启动后端。

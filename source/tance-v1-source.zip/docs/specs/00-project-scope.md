# 00 · 项目边界与基线来源

> 2026-09-21 已批准更新：SC-01–SC-05 以 [V1 完成决议](decisions/2026-09-21-v1-completion-proposal.md) 为准；本文原有“待批准”说明保留作历史记录，对应条目现已获批。
版本：TANCE SDD Baseline V1 · 整理日期：2026-09-21。本文与 01–07 共同构成后端工程基线。

## 1. 产品定位（FROZEN）

TANCE / 摊策是面向**单用户同人摊主的 AI 决策支持系统**。系统帮助用户选择真实展会、管理参展商品、收集需求证据、判断追加生产数量、跟踪生产与到货、分配现货并记录实际销售，利用历史销量支持下一轮再贩。

系统给出可解释的建议，用户保留最终生产决策权。它不是自动下单系统，也不是完整 ERP、财务系统或通用项目管理系统。

## 2. V1 完整业务闭环（FROZEN）

```text
真实 EventListing + Tag
  → 按 IP / 城市 / 时间推荐候选展会
  → Add to Plan 或手工创建 EventPlan
  → 管理 Content 与 Product，并建立 ProductContent 关联
  → Product 加入 Event，形成 EventProductPlan
  → 录入 DemandSignal 快照 + 查询 SalesRecord 历史
  → Demand Readiness 与再贩风险提示
  → Python 生成需求三档与追加生产三档
  → QuantityDecision 保存结果和库存快照，LLM 可选解释
  → 用户确认 final_production_quantity
  → 选择 Vendor，创建 Product 级 ProductionBatch
  → 可选多轮 SampleRound，正式下单、生产、发货、到货
  → 以实际合格到货量计算 physical current stock
  → InventoryAllocation 为展会预留现货
  → 按日期记录 / 修正 SalesRecord
  → 销售汇总、剩余库存、历史销量
  → 下一轮 EventProductPlan / 再贩推荐
```

Task 贯穿展会准备过程，记录行动和截止时间；Dashboard 聚合待办、展会、生产与提醒。Task 完成不是到货、销售或数量确认的事实依据。

## 3. V1 必须保留的业务边界

- EventListing 是外部发现数据；EventPlan 是用户自己的计划快照，加入时复制必要字段，之后不随 Listing 自动变化。
- Product 是长期制品资产；Content 是创作资产；两者 M:N。展会实际售价归 EventProductPlan，批次成本归 ProductionBatch。
- ProductionBatch 属于 Product，不直接绑定 EventProductPlan 或 QuantityDecision。一批生产可服务多场展会。
- 需求预测、追加生产建议、用户最终生产量、实际下单量、实际到货量、展会分配量、实际销量允许彼此不同，不强制相等。
- 库存来自 RECEIVED 批次实际到货量减全部销售；Allocation 仅预留，不扣 physical stock。
- 数值由 Python 确定性计算，LLM 不是数字 source of truth；LLM 故障不阻塞数值 recommendation。
- 系统内历史销量从 SalesRecord 查询，不复制成 DemandSignal 或另建历史表。

## 4. 明确不做

本次文件集不包含前端页面布局、路由页面草图、组件、交互、视觉规范或 UI demo；01 仅保留已选前端技术栈作为系统边界。

V1 不做：多用户与 User/Auth、权限 / 租户；电商订单 / 支付 / 自动向 Vendor 下单；复杂仓库流水 / 调拨 / 退货 / 损耗账；财务审计 / 汇率换算 / 跨币种收益合计；问卷发放平台与逐人答卷；完整 IP/fandom 知识图谱；自动爬虫或复杂数据采集管线；RAG、模型训练；消息队列、定时自动状态机、通用工作流引擎；文件上传 / 对象存储平台；复杂任务依赖、子任务、周期任务；独立 Analytics 表。

已出现“网店可共用一批生产”的例子只说明 Product 级生产关系，不意味着 V1 提供网店订单或销售渠道 API。V1 销量入口仍是 EventProductPlan 的 SalesRecord。

## 5. 规范阅读与事实优先级

| 文件 | 内容 |
|---|---|
| [01-tech-stack.md](01-tech-stack.md) | 技术栈、依赖、同步数据库约束 |
| [02-architecture.md](02-architecture.md) | 调用链、职责、目录、事务与 AI 边界 |
| [03-data-model.md](03-data-model.md) | 15 个实体、全部字段和数据库约束 |
| [04-api-contract.md](04-api-contract.md) | 业务 API 与 health、请求 / 响应、错误 |
| [05-state-rules.md](05-state-rules.md) | 状态、派生值、库存 / 决策语义、规范问题 |
| [06-service-contracts.md](06-service-contracts.md) | 12 个 Service 的公共职责与依赖 |
| [07-development-rules.md](07-development-rules.md) | 冻结层级、工作流、migration、测试、DoD |
| [decisions/README.md](decisions/README.md) | ADR 使用时机与批准记录 |

冲突处理：用户明确批准的最新变更 → 本次请求的最终修正 → 原对话较晚且明确收敛的设计。文档之间若仍冲突，不能自行挑选；按 AGENTS.md 输出 `SPEC CHANGE REQUIRED`。

标记含义：**FROZEN** 为已确认业务 / 外部契约；**编纂约定** 为本次为可执行文档补齐且不改变已有含义的机械约定；**待批准** 为原对话缺失或冲突之处，不是已批准的契约。编纂约定中涉及对外补齐的部分一经作为工程基线采用，后续变更也走 FROZEN 变更流程。纯索引命名、目录内 helper 组织仍按 07 分类。

## 6. 来源核对记录

来源：[Vue3技术栈选择](chatgpt-conversation://6aaf8170-c4d4-83ec-8e00-8aaefc16e879)，已读取实体物理 Schema、最终数据库 Review、三组 API、Pydantic / Service、Skeleton 与 SDD 讨论。未把前端页面设计纳入本文件集。

| 收敛点 | 原对话 turn ID | 纳入结果 |
|---|---|---|
| Database Schema V1 最终 Review | `e91e5fe1-46fb-4b5a-9024-2255e79f6ab9` | default_currency、售价可空、ordered/received、reservation、confirmed_at |
| EventListing | `fd314fe4-83f7-404f-8769-07d90bd5c5f2` | Listing/Tag、EventPlan 来源 FK 与复制语义 |
| Events / Discovery API | `1f815854-7036-4cf2-946f-c7f719debc59` | method/path/响应与重复加入规则 |
| Product / Content API | `2cf8a941-7667-487a-9519-34b42bd3156b` | CRUD、关联、默认价格成对校验 |
| 其余 API V1 Freeze | `322a6442-53dc-442d-ac70-4add62fa19ff` | 生产、库存、需求、推荐、销售、任务、Dashboard |
| Pydantic / Service | `618d63ea-8d3b-4503-877e-3bbb11637ccb` | Schema 命名、公共 Service 责任 |
| Backend Skeleton | `95f378ab-9738-41cb-b003-5452cca6e9d3` | 同步 SQLAlchemy、health、最小 Product migration |
| SDD 边界 | `d8fd83ea-e62a-44d4-b139-8e495343e7b9` | AGENTS、冻结纪律、spec 先于实现 |

明确采用较晚版本：弃用 `ProductionBatch.quantity`、`QuantityDecision.final_quantity`、`EventProductPlan.planned_quantity`、`INTEREST_COUNT`、`heat_score` 预留字段；不恢复早期 NOT NULL 售价与成本约束。早期 JSON 的裸金额 / 无时区时间统一按较晚 API 全局规则整理。

## 7. 可实施范围与待解决事项

本文件集完整收录当前冻结范围，但原对话**没有冻结完整数值算法或每条状态迁移边**。不能因为文件集完整就声称所有业务细节都已定稿。

可以开始：Backend Skeleton、15 个已定实体、无争议 CRUD、快照读取、基础计算与接口骨架。不得以 mock 值宣称业务服务已完成。

以下问题的具体反例、提案和影响均在 [05 第 10 节](05-state-rules.md#10-待批准规范问题)；实施涉及条目时必须先批准，不阻止其他已确认工作：

| ID | 问题 | 影响 |
|---|---|---|
| SC-01 | 已售后的累计分配上限与剩余库存口径冲突 | Allocation 更新、reservation、Sales 联动 |
| SC-02 | CANCELLED Task 是否显示 OVERDUE 的原文歧义 | Task 展示派生状态 |
| SC-03 | QuantityDecision 历史 warnings 没有保存位置 | 历史响应是否准确复现当次警告 |
| SC-04 | 状态允许跳过 / 回退 / 终态重开未形成完整矩阵 | 状态变更 API |
| SC-05 | 需求转换、权重、阈值、排名与部分聚合指标未定 | 真正的推荐算法、readiness、进度与 Dashboard |

这些问题是本次整理发现的规范缺口，不代表用户已经批准了修正。

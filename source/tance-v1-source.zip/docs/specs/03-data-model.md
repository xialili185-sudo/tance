# 03 · Database Schema V1

> 2026-09-21 已批准更新：SC-01–SC-05 以 [V1 完成决议](decisions/2026-09-21-v1-completion-proposal.md) 为准；本文原有“待批准”说明保留作历史记录，对应条目现已获批。
状态：字段含义、实体关系、PK/FK/unique、存储与派生边界为 **FROZEN**。本文件已合并最终 Review 修正，不得恢复较早字段。

## 1. 统一约定

- 下表 `N` 表示 NOT NULL，`Y` 表示可空；未列默认值的字段没有业务默认值。主业务实体用 `BIGINT PK AUTO_INCREMENT`；两张纯关联表使用复合 PK。
- MySQL 表名采用下表 snake_case 复数形式（编纂约定）；字段名保持原设计。表名、索引名是物理实现命名，不改变业务含义。
- `created_at` / `updated_at` 由应用维护，UTC DATETIME；仅列出的实体有这些字段，**不要为 DemandSignal、QuantityDecision、SampleRound 自动添加 updated_at**。
- 金额 `DECIMAL(10,2)`，货币 `CHAR(3)`，API 十进制字符串。金额与货币成对为空或成对存在；有值时金额 >= 0。不保留会让“无价格但有 CNY”发生的默认货币。
- 所有普通 FK 默认 `ON DELETE RESTRICT`；ProductContent 两个 FK 用 CASCADE；EventPlan 来源 FK 用 SET NULL；EventListingTag 的拥有关系用 CASCADE（编纂约定）。主键不可被 API 修改。
- NOT NULL、PK、FK、unique 由数据库落实。范围 / Enum / 跨实体规则至少在 Schema + Service 校验；可加等价 CHECK，但不能以新增 CHECK 偷改业务规则。
- 下方“必要索引”含原对话明确索引及 FK 查找索引；无业务唯一含义的索引名称 / 冗余消除属 SEMI-FROZEN。额外性能索引须有查询依据，不增加唯一约束。

| Entity | 物理表名 | 主键 |
|---|---|---|
| EventListing | event_listings | event_listing_id |
| EventListingTag | event_listing_tags | (event_listing_id, tag) |
| EventPlan | event_plans | event_id |
| Product | products | product_id |
| Content | contents | content_id |
| ProductContent | product_contents | (product_id, content_id) |
| EventProductPlan | event_product_plans | event_product_plan_id |
| DemandSignal | demand_signals | signal_id |
| QuantityDecision | quantity_decisions | decision_id |
| Vendor | vendors | vendor_id |
| ProductionBatch | production_batches | batch_id |
| SampleRound | sample_rounds | sample_id |
| InventoryAllocation | inventory_allocations | allocation_id |
| SalesRecord | sales_records | sales_record_id |
| Task | tasks | task_id |

## 2. EventListing

用于真实展会发现与推荐，不承载用户参展业务。

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| event_listing_id | BIGINT | N | PK，AUTO_INCREMENT |
| name | VARCHAR(150) | N | 展会名称，不 UNIQUE |
| location | VARCHAR(255) | N | 完整地点 / 场馆 |
| city | VARCHAR(100) | Y | 城市过滤 |
| start_date | DATE | N | 开始日期 |
| end_date | DATE | N | 结束日期，>= start_date |
| application_deadline | DATETIME | Y | 报名截止时间 |
| theme | VARCHAR(255) | Y | 轻量主题文本 |
| description | TEXT | Y | 简短介绍 |
| registration_status | VARCHAR(30) | N | 默认 UNKNOWN；枚举见 05 |
| source_name | VARCHAR(100) | Y | 信息来源名称 |
| source_url | VARCHAR(500) | Y | 可供用户核验的来源链接 |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

关系：1:N EventListingTag；1:N EventPlan 来源引用。无业务唯一索引；city/start_date/registration_status 的查询索引按实际查询选择，原对话未固定组合。Listing 更新不能联动修改已有 EventPlan。API V1 不提供 Listing 创建 / 编辑 / 删除端点，数据可通过受控 seed / 导入维护。

## 3. EventListingTag

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| event_listing_id | BIGINT | N | 复合 PK；FK → EventListing.event_listing_id，CASCADE |
| tag | VARCHAR(100) | N | 复合 PK；轻量 IP / 分类字符串 |

`PRIMARY KEY(event_listing_id, tag)`；无独立 id、无 timestamp、无 Tag/IP 主表。按 tag 反查可加普通 `INDEX(tag)`，属于查询优化。不得保存重复组合。

## 4. EventPlan

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| event_id | BIGINT | N | PK，AUTO_INCREMENT |
| name | VARCHAR(150) | N | 用户展会名称，不 UNIQUE |
| location | VARCHAR(255) | N | 展会地点 |
| start_date | DATE | N | 开始日期 |
| end_date | DATE | N | 结束日期，>= start_date |
| application_deadline | DATETIME | Y | 展会级固定截止时间 |
| source_event_listing_id | BIGINT | Y | FK → EventListing.event_listing_id，SET NULL |
| status | VARCHAR(20) | N | 默认 PLANNING；见 05 |
| notes | TEXT | Y | 用户备注 |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

必要索引：`INDEX(source_event_listing_id)`。**不加 UNIQUE(source_event_listing_id)**：业务仅禁止存在相同来源且 status != CANCELLED 的计划时再次加入；取消后可以重新加入。必须用 Service + 事务防重。

关系：1:N EventProductPlan；1:N Task。手工创建时 source_event_listing_id=null；Add to Plan 复制 name/location/start_date/end_date/application_deadline。删除 Listing 仅清空来源 FK，不删除 EventPlan。

有任意下游数据时禁止物理删除，包括 EventProductPlan 或 Task；取消 / 完成是状态变更。商品截稿、印调、送印等 deadline 存 Task，不扩展固定字段。

## 5. Product

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| product_id | BIGINT | N | PK，AUTO_INCREMENT |
| name | VARCHAR(150) | N | 制品名，不 UNIQUE |
| product_type | VARCHAR(50) | N | Python Enum，见 05 |
| description | TEXT | Y | 制品长期属性 |
| default_selling_price | DECIMAL(10,2) | Y | 默认售价参考，>= 0 |
| default_currency | CHAR(3) | Y | 与 default_selling_price 成对 |
| status | VARCHAR(20) | N | 默认 ACTIVE；ACTIVE / ARCHIVED |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

无业务 unique；不预设 name unique。关系：M:N Content，经 ProductContent；1:N EventProductPlan；1:N ProductionBatch。

默认售价只用于新参展计划预填，不同步覆盖既有售价。Product 不保存 unit_cost/vendor/current_stock/selling_price/event_id/historical_sales/recommended_quantity。存在批次或参展计划等业务历史时不得删除；无业务依赖时物理删除可级联清除 ProductContent 关系。

## 6. Content

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| content_id | BIGINT | N | PK，AUTO_INCREMENT |
| title | VARCHAR(150) | N | 创作资产名，不 UNIQUE |
| content_type | VARCHAR(50) | N | Python Enum，见 05 |
| file_url | VARCHAR(500) | Y | 主文件 URL / 路径字符串 |
| thumbnail_url | VARCHAR(500) | Y | 缩略图 URL / 路径字符串 |
| description | TEXT | Y | 说明 |
| status | VARCHAR(20) | N | 默认 ACTIVE；ACTIVE / ARCHIVED |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

无业务 unique。可独立于 Product/Event 存在；不存二进制文件、event_id、product_id、售价或销量。API 删除前若仍有 ProductContent 则返回 CONTENT_IN_USE，即使 DB 支持 CASCADE 也必须先执行此业务检查。

## 7. ProductContent

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| product_id | BIGINT | N | 复合 PK；FK → Product.product_id，CASCADE |
| content_id | BIGINT | N | 复合 PK；FK → Content.content_id，CASCADE |

`PRIMARY KEY(product_id, content_id)`；必要反向索引 `INDEX(content_id)`。不加独立 id、usage_role、position、timestamp。解除关联不删除 Product 或 Content。

## 8. EventProductPlan

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| event_product_plan_id | BIGINT | N | PK，AUTO_INCREMENT |
| event_id | BIGINT | N | FK → EventPlan.event_id，RESTRICT |
| product_id | BIGINT | N | FK → Product.product_id，RESTRICT |
| selling_price | DECIMAL(10,2) | Y | 本场售价，>= 0 |
| currency | CHAR(3) | Y | 与 selling_price 成对 |
| status | VARCHAR(30) | N | 默认 PLANNING；见 05 |
| notes | TEXT | Y | 本场特有备注 |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

`UNIQUE(event_id, product_id)`（含 CANCELLED 行，不能因取消创建重复 Plan）；必要索引 `INDEX(product_id)`，event_id 查询由 unique 左前缀覆盖。

PLANNING/PREPARING 可无售价；**READY/SELLING 必须有 selling_price 与 currency**。状态与价格必须按 PATCH 合并后的最终对象校验。

关系：1:N DemandSignal/QuantityDecision/SalesRecord/Task；1:0..1 InventoryAllocation。ProductionBatch 不挂此表。有任何下游记录（包括 Allocation、Task）时只能取消，不能删除。event_id/product_id 不通过 PATCH 更换。

不存 planned_quantity、is_resale、sale_round、historical_sales、current_stock、demand_readiness、progress、production_status。历史生命周期从其他参展计划及 SalesRecord 查询；一次推荐的 confidence 保存在 QuantityDecision。

## 9. DemandSignal

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| signal_id | BIGINT | N | PK，AUTO_INCREMENT |
| event_product_plan_id | BIGINT | N | FK → EventProductPlan，RESTRICT |
| signal_type | VARCHAR(50) | N | 6 种类型，见 05 |
| value | BIGINT | N | 非负整数；观察时点总值，非增量 |
| source | VARCHAR(100) | Y | 平台 / 手工来源 |
| observed_at | DATETIME | N | 实际观察时间，决定 recency |
| notes | TEXT | Y | 备注 |
| created_at | DATETIME | N | 录入时间 |

`INDEX(event_product_plan_id, signal_type, observed_at)`。**无 UNIQUE(plan,type)**、无 updated_at。插入新 snapshot 表示更新；不提供 PATCH。允许删除录错的记录。

同类快照按 observed_at 最新取一个，不能累加 `21+29+38`。同一 observed_at 时按 signal_id 降序确定一个（确定性编纂约定）。source 不是独立聚合分组，不能按平台求和制造双计。

EVENT_INTEREST_SURVEY 是本场 / 本轮新印调；WISHLIST_COUNT 是累计兴趣池，仅辅助证据；PREORDER_COUNT 是本轮真实预订累计值；SOCIAL_ENGAGEMENT 是合并社媒互动计数；MANUAL_ESTIMATE 是用户主观需求估计；EXTERNAL_HISTORY 仅记录系统外历史。

系统内销量不能复制为 EXTERNAL_HISTORY；reliability、conversion、recency_weight 不存原始信号。再贩缺新印调不阻塞生成，但应提示并降低 confidence。

## 10. QuantityDecision

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| decision_id | BIGINT | N | PK，AUTO_INCREMENT |
| event_product_plan_id | BIGINT | N | FK → EventProductPlan，RESTRICT |
| current_stock_snapshot | BIGINT | N | 生成时 physical current stock 快照，>= 0 |
| demand_conservative | BIGINT | N | 保守需求，>= 0 |
| demand_balanced | BIGINT | N | 均衡需求，>= 0 |
| demand_aggressive | BIGINT | N | 积极需求，>= 0 |
| recommended_strategy | VARCHAR(20) | N | CONSERVATIVE / BALANCED / AGGRESSIVE |
| recommended_demand | BIGINT | N | 所选档需求 |
| production_conservative | BIGINT | N | 保守追加生产，>= 0 |
| production_balanced | BIGINT | N | 均衡追加生产，>= 0 |
| production_aggressive | BIGINT | N | 积极追加生产，>= 0 |
| recommended_production | BIGINT | N | 所选档追加生产 |
| final_production_quantity | BIGINT | Y | 用户最后确认的追加生产量，>= 0 |
| confidence_level | VARCHAR(20) | N | LOW / MEDIUM / HIGH |
| warnings | JSON | N | 已批准 SC-03：生成时保存规则警告数组，空为 [] |
| recommendation_reason | TEXT | Y | 可选 LLM 解释；失败为 null |
| decision_note | TEXT | Y | 用户确认备注 |
| created_at | DATETIME | N | 生成时间 |
| confirmed_at | DATETIME | Y | 最近一次用户确认时间 |

必要 FK 索引为 event_product_plan_id；历史读取建议使用 `INDEX(event_product_plan_id, created_at)`（编纂约定，覆盖 FK 查询）。一个 Plan 可有多次 Decision；不加 plan unique。

冻结不变量：

```text
0 <= demand_conservative <= demand_balanced <= demand_aggressive
production_x = max(demand_x - current_stock_snapshot, 0)
recommended_demand = demand_<recommended_strategy>
recommended_production = production_<recommended_strategy>
final_production_quantity is null ⇔ confirmed_at is null
```

生成创建新行，数值快照不覆盖。仅 final_production_quantity/decision_note/confirmed_at 可随用户再次确认更新；0 表示确认不追加生产，不等于未确认。不得要求 final 与 recommended 相等，也不自动创建生产批次。

不存 status、heat_score、final_demand_quantity、updated_at、is_stale 或 explanation_status。explanation_status 由 recommendation_reason 是否有有效解释派生。**warnings 的历史保存方式原文缺失，见 SC-03；不得擅加 warnings JSON 或 QuantityDecisionSignal 表。** 当前保存结果能回看当次数值，但未保存完整输入 / 参数版本，不能声称可以精确重跑历史算法。

## 11. Vendor

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| vendor_id | BIGINT | N | PK，AUTO_INCREMENT |
| name | VARCHAR(150) | N | 厂商名称，不 UNIQUE |
| contact | VARCHAR(255) | Y | 联系方式 |
| website | VARCHAR(500) | Y | 网站字符串 |
| notes | TEXT | Y | 备注 |
| status | VARCHAR(20) | N | 默认 ACTIVE；ACTIVE / ARCHIVED |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

关系：1:N ProductionBatch。任何历史批次引用时不得删除，改为 ARCHIVED。不增加 production_days/MOQ/rating/product_types 等未定字段。

## 12. ProductionBatch

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| batch_id | BIGINT | N | PK，AUTO_INCREMENT |
| product_id | BIGINT | N | FK → Product.product_id，RESTRICT |
| vendor_id | BIGINT | Y | FK → Vendor.vendor_id，RESTRICT |
| ordered_quantity | BIGINT | N | 计划 / 正式下单数量，> 0 |
| received_quantity | BIGINT | Y | 实际合格到货量，有值则 >= 0 |
| unit_cost | DECIMAL(10,2) | Y | 单件生产成本，有值则 >= 0 |
| currency | CHAR(3) | Y | 与 unit_cost 成对 |
| status | VARCHAR(30) | N | 默认 PLANNED；见 05 |
| ordered_at | DATETIME | Y | 正式下单时间 |
| expected_at | DATETIME | Y | 预计到货时间 |
| received_at | DATETIME | Y | 实际到货时间 |
| notes | TEXT | Y | 备注 |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

必要索引：`INDEX(product_id)`、`INDEX(vendor_id)`；无业务 unique。关系：Product 1:N Batch、Vendor 1:N Batch、Batch 1:N SampleRound。

PLANNED 允许尚无 vendor/unit_cost/currency。ORDERED/PRODUCING/SHIPPED/**RECEIVED** 必须具备 vendor_id、unit_cost、currency、ordered_at；RECEIVED 额外要求 received_quantity、received_at。不能用字符串排序实现“>= ORDERED”。

只有 RECEIVED.received_quantity 计入库存，其他状态即使填 received_quantity 也不贡献库存。原设计未禁止超额到货，不擅加 received_quantity <= ordered_quantity。零合格到货可记录 0；不等于未知 null。

`ordered_quantity × unit_cost` 是该批下单成本派生值，不存 total_cost。无 event_product_plan_id / quantity_decision_id FK。只有 PLANNED 且无 SampleRound 可物理删除；已 RECEIVED 不能通过取消抹掉库存事实（迁移矩阵待 SC-04）。

## 13. SampleRound

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| sample_id | BIGINT | N | PK，AUTO_INCREMENT |
| batch_id | BIGINT | N | FK → ProductionBatch.batch_id，RESTRICT |
| round_number | INT | N | 轮次，正整数（编纂约定） |
| status | VARCHAR(30) | N | 默认 PENDING；见 05 |
| submitted_at | DATETIME | Y | 提交打样时间 |
| received_at | DATETIME | Y | 收到样品时间 |
| sample_cost | DECIMAL(10,2) | Y | 该轮打样费用，>= 0 |
| currency | CHAR(3) | Y | 与 sample_cost 成对 |
| notes | TEXT | Y | 修改意见 / 备注 |
| created_at | DATETIME | N | 创建时间 |

`UNIQUE(batch_id, round_number)` 覆盖 batch_id 查询。无 updated_at；API 允许 PATCH 和删除录错样品。不要因为缺 updated_at 自动加字段。一批可以没有 SampleRound；不能强制每次下单都先打样。APPROVED 不自动将 Batch 改成 ORDERED。

## 14. InventoryAllocation

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| allocation_id | BIGINT | N | PK，AUTO_INCREMENT |
| event_product_plan_id | BIGINT | N | FK → EventProductPlan，RESTRICT |
| allocated_quantity | BIGINT | N | 本场累计分配总量，>= 0 |
| notes | TEXT | Y | 备注 |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

`UNIQUE(event_product_plan_id)`；1:0..1，而非强制每个 Plan 建行。PUT 为 upsert，不建 Day 1/Day 2 多行，不建分配历史流水。allocation 不要求等于任何 recommended 或 final 数量。

不能分配 PRODUCING/SHIPPED 的在途货。allocation 不减少 physical current stock，但应参与 active Event 的 reservation；结束展会的余量释放预留，实物库存公式不变。已有 SalesRecord 时不能删除 allocation。

原 API 的 `allocated_quantity <= current_stock - other_reservations` 在有本场销售后存在口径冲突。**详见 05 的 SC-01；现有字段保留，不能自行修正公式或把 allocated_quantity 改解释为剩余量。**

## 15. SalesRecord

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| sales_record_id | BIGINT | N | PK，AUTO_INCREMENT |
| event_product_plan_id | BIGINT | N | FK → EventProductPlan，RESTRICT |
| sale_date | DATE | N | 销售日期 |
| sold_quantity | BIGINT | N | 当天最终销售汇总，>= 0 |
| notes | TEXT | Y | 备注 |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

`UNIQUE(event_product_plan_id, sale_date)`，覆盖 Plan 查询。无独立 product_id/event_id/allocation_id FK；沿 Plan 查询。Service 要求 allocation 已存在。

同日更正用 PATCH；不是新增增量记录。累计本场销量 <= allocated_quantity；编辑时扣除原记录后校验替换值，不能把旧值和新值重复累加。允许删除错误记录，并据此重新计算库存与汇总。

所有 Product 的销售，包括已完成 / 取消 Event 下保留的真实销售，均要计入全局库存减项；不能按 active Event 过滤掉历史销量。V1 没有退款 / 负销量。原对话未冻结 sale_date 必须在展会日期内，不擅加此限制。

## 16. Task

| 字段 | 类型 | Nullable | 约束 / 含义 |
|---|---|---|---|
| task_id | BIGINT | N | PK，AUTO_INCREMENT |
| event_id | BIGINT | N | FK → EventPlan.event_id，RESTRICT |
| event_product_plan_id | BIGINT | Y | FK → EventProductPlan，RESTRICT |
| title | VARCHAR(200) | N | 任务名称 |
| task_type | VARCHAR(50) | N | 8 种任务类型，见 05 |
| status | VARCHAR(30) | N | 默认 TODO；stored states 见 05 |
| due_at | DATETIME | Y | 截止时间 |
| completed_at | DATETIME | Y | DONE 时完成时间 |
| notes | TEXT | Y | 备注 |
| created_at | DATETIME | N | 创建时间 |
| updated_at | DATETIME | N | 最近更新时间 |

`INDEX(event_id, due_at)`、`INDEX(event_product_plan_id)`；无业务 unique。Plan 不为空时必须属于同一 Event，Service 检查即可，不另造复合 FK。

DONE/completed_at 保持一致，重新打开清空 completed_at。OVERDUE / display_status 不持久化；CANCELLED 的逾期语义见 SC-02。Task 可编辑 / 删除，不作为生产、数量确认或销售事实。

## 17. 全局关系与派生计算

```text
EventListing 1 ── N EventListingTag
EventListing 0..1 ── N EventPlan（来源，不动态同步）
EventPlan 1 ── N EventProductPlan N ── 1 Product
Product N ── M Content（ProductContent）
Product 1 ── N ProductionBatch N ── 0..1 Vendor
ProductionBatch 1 ── N SampleRound
EventProductPlan 1 ── N DemandSignal / QuantityDecision / SalesRecord
EventProductPlan 1 ── 0..1 InventoryAllocation
EventPlan 1 ── N Task；Task 可再引用同场一个 EventProductPlan
```

```text
total_received(product) = Σ RECEIVED ProductionBatch.received_quantity
total_sold(product) = Σ 所有该 Product 的 SalesRecord.sold_quantity
current_stock(product) = total_received - total_sold
event_sold(plan) = Σ 该 Plan 的 sold_quantity
event_remaining(plan) = allocated_quantity - event_sold
sell_through_rate(plan) = event_sold / allocated_quantity
```

空 SUM 按 0 处理；physical stock 不能因 Allocation 被扣第二次。sell_through_rate 分母为 0 时返回 null（编纂约定，不返回 NaN/Infinity）。库存、reservation、remaining、sell-through、生命周期、进度与注意事项均不增加持久化字段。QuantityDecision 数值快照是明确批准的历史记录例外。

## 18. V1 禁止新增的表

`Inventory`、`HistoricalSales`、`Status`、`ProductType`、`IP` / fandom entity system、`Survey`、`SurveyResponse`、`InventoryTransaction`、`QuantityDecisionSignal`、`User`、`Auth`、`Analytics`。

不得通过同义名称绕过边界，例如 `stock_balances`、`sales_history_cache`、`decision_signal_links`。确有需求时走 `SPEC CHANGE REQUIRED`，明确 schema 与迁移影响。

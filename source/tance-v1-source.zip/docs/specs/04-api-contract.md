# 04 · API Contract V1

> 2026-09-21 已批准更新：SC-01–SC-05 以 [V1 完成决议](decisions/2026-09-21-v1-completion-proposal.md) 为准；本文原有“待批准”说明保留作历史记录，对应条目现已获批。
状态：业务资源、method/path、字段含义、主要响应形状与已给出的业务错误为 **FROZEN**。全文不包含页面 / UI 设计。

## 1. 全局协议

- Base path：`/api/v1`。所有端点返回 JSON，204 无 body；不使用 `{data: ...}` 外层包装。
- `GET` / `PATCH` 成功为 200；创建资源的 POST 为 201；关联 POST 为 204；不创建持久资源的 event-recommendations 为 200；DELETE 为 204。Allocation PUT 两种结果均 200（原文未指定，本次补齐）。
- JSON 金额为十进制字符串，如 `"6.50"`，不使用 float。API datetime 必须带时区，如 `2026-09-21T12:00:00Z` 或 `2026-09-21T20:00:00+08:00`；DATE 用 `2026-09-21`。
- `int` 指 JSON 整数；数量 >= 0，ordered_quantity > 0。`Money` 指非负 Decimal(10,2) 字符串；`Currency` 为 3 位大写货币码；`DT` / `Date` 含义如上。长度上限继承 03。
- 以下形状使用 `name?: T` 表示**请求中可省略**；`T | null` 表示可显式清空。没有 `?` 的响应字段必须存在，可能为 null。`Partial<X>` 仅允许省略字段，不自动允许把非空字段改为 null。
- PATCH 按“仅更新传入字段”处理，合并数据库旧值后校验；不能用整个 defaults 字典覆盖未传字段。只接受本节列出的字段，拒绝 ID、created_at、derived 字段等额外输入（编纂约定）。
- 列表保留原契约差异：`List<T> = {items: T[], total: int}`；`Items<T> = {items: T[]}`。不要为了统一包装改变已给出的响应。空集合返回空数组，不返回 404；父资源不存在才返回 404。
- V1 未定义分页参数、搜索 API 或批量修改。禁止自行引入。未指定的稳定排序可用主键辅助，但不得影响已冻结的历史排序。
- URL 已带父 ID 时 body 不重复传。外部资源 ID 指定后必须检查存在性与归属。
- 基础 `XResponse` 在未单独展开时表示 03 对应实体全部已存字段按上述格式序列化；不得包含 SQLAlchemy 内部属性或未列入 spec 的列。带 Summary/Detail 的形状以本文件为准。

## 2. HTTP 错误

```json
{
  "code": "EVENT_ALREADY_IN_PLAN",
  "message": "This event has already been added to your plan.",
  "details": {"existing_event_id": 14}
}
```

**统一格式为 `{code: string, message: string, details: object | null}`**；无补充信息也保留 details=null。message 可本地化，客户端依赖 code。较早例子把 existing_event_id 放在顶层，本次依较晚统一规则移入 details。不返回 FastAPI 原生 `{detail: ...}`、SQL 或异常栈。

| HTTP | code | 用途 |
|---|---|---|
| 404 | EVENT_NOT_FOUND / EVENT_LISTING_NOT_FOUND / PRODUCT_NOT_FOUND / CONTENT_NOT_FOUND / PLAN_NOT_FOUND / SIGNAL_NOT_FOUND / DECISION_NOT_FOUND / VENDOR_NOT_FOUND / BATCH_NOT_FOUND / SAMPLE_NOT_FOUND / TASK_NOT_FOUND / SALES_RECORD_NOT_FOUND | 路径或 body 引用资源不存在 |
| 409 | EVENT_ALREADY_IN_PLAN | 同来源已有非 CANCELLED EventPlan |
| 409 | EVENT_HAS_DEPENDENCIES | Event 有下游数据 |
| 409 | PRODUCT_HAS_DEPENDENCIES | Product 有生产 / 参展等业务数据 |
| 409 | CONTENT_IN_USE | Content 仍被 Product 使用 |
| 409 | PRODUCT_CONTENT_ALREADY_LINKED | 重复 ProductContent |
| 409 | PRODUCT_ALREADY_IN_EVENT | 重复 event_id + product_id |
| 409 | EVENT_PRODUCT_PLAN_HAS_DEPENDENCIES | Plan 有下游数据 |
| 409 | INVENTORY_NOT_ALLOCATED | 录销售前不存在 Allocation |
| 422 | INVALID_EVENT_DATE | end_date < start_date |
| 422 | INSUFFICIENT_DEMAND_DATA | 没有任何有效需求来源 |

原对话未逐一命名的错误，本次补齐统一名称供实施采用：

| HTTP | code | 用途 |
|---|---|---|
| 422 | VALIDATION_ERROR | 类型、必填、长度、额外字段、非法 Enum、负数量 / 金额、无时区时间 |
| 422 | INVALID_MONEY_PAIR | 金额与货币没有成对出现 |
| 422 | PRICE_REQUIRED | READY/SELLING 缺 selling_price/currency |
| 422 | BATCH_STATE_REQUIREMENTS_NOT_MET | 目标 Batch 状态缺必要字段 |
| 422 | TASK_EVENT_MISMATCH | Task 的 Plan 属于另一 Event |
| 422 | ALLOCATION_EXCEEDS_AVAILABLE_STOCK | 超出已批准的 allocation 上限；见 SC-01 |
| 422 | ALLOCATION_BELOW_SALES | 分配量低于该场已售总量 |
| 422 | SALES_EXCEED_ALLOCATION | 新增 / 更正后累计销量超 allocation |
| 409 | INVALID_STATE_TRANSITION | 状态迁移不允许；完整矩阵待 SC-04 |
| 409 | VENDOR_HAS_DEPENDENCIES | 有历史 Batch 的 Vendor 不可删 |
| 409 | BATCH_NOT_DELETABLE | Batch 非 PLANNED 或有 SampleRound |
| 409 | SAMPLE_ROUND_ALREADY_EXISTS | 同批次重复 round_number |
| 409 | SALES_RECORD_ALREADY_EXISTS | 同一 Plan + sale_date 重复 |
| 409 | ALLOCATION_HAS_SALES | 有 SalesRecord 不可删 Allocation |
| 409 | STOCK_CONFLICT | 更正数据破坏现货 / 预留不变量；规则见 SC-01 |
| 500 | INTERNAL_ERROR | 未预期服务错误，details 不包含内部堆栈 |

这些 code 补齐不授权修改现有错误名称。每个端点都可能返回适用的 404/422；下面表格另外标明其核心错误。不能为待批准规则先发明不同的运行行为。

## 3. Events

```text
EventCreate = {
  name: string, location: string, start_date: Date, end_date: Date,
  application_deadline?: DT | null, notes?: string | null
}
EventUpdate = Partial<EventCreate + {status: EventStatus}>
EventSummaryResponse = {
  event_id: int, name: string, location: string,
  start_date: Date, end_date: Date, status: EventStatus, product_count: int
}
EventDetailResponse = {
  event_id: int, name: string, location: string,
  start_date: Date, end_date: Date, application_deadline: DT | null,
  status: EventStatus, notes: string | null,
  summary: {product_count: int, ready_product_count: int,
            demand_checked_count: int, production_ready_count: int},
  attention_count: int, created_at: DT, updated_at: DT
}
```

| Method | Path（加 /api/v1） | Request / Query | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/events` | EventCreate | 201 EventResponse | 默认 PLANNING；source_event_listing_id=null |
| GET | `/events` | status?、upcoming? boolean | 200 List<EventSummaryResponse> | 非法过滤值 422 |
| GET | `/events/{event_id}` | 无 | 200 EventDetailResponse | 不内嵌全部 Products / Tasks |
| PATCH | `/events/{event_id}` | EventUpdate | 200 EventResponse | 合并后检查日期、状态 |
| DELETE | `/events/{event_id}` | 无 | 204 | 任意下游含 Task：EVENT_HAS_DEPENDENCIES |

EventResponse 包含 source_event_listing_id 和 timestamps。聚合计数的具体判定中尚未冻结的内容见 SC-05；不要用存储字段代替计算。

## 4. Event Listings 与 Event Recommendations

```text
EventListingSummaryResponse = {
  event_listing_id: int, name: string, city: string | null, location: string,
  start_date: Date, end_date: Date, application_deadline: DT | null,
  registration_status: RegistrationStatus, theme: string | null,
  tags: string[], source_name: string | null
}
EventListingDetailResponse = {
  event_listing_id: int, name: string, location: string, city: string | null,
  start_date: Date, end_date: Date, application_deadline: DT | null,
  theme: string | null, description: string | null,
  registration_status: RegistrationStatus, tags: string[],
  source_name: string | null, source_url: string | null
}
EventRecommendationRequest = {
  ip?: string | null, preferred_cities?: string[],
  available_from?: Date | null, available_to?: Date | null
}
EventRecommendationResponse = {
  recommendations: [{
    event_listing: {
      event_listing_id: int, name: string, city: string | null,
      start_date: Date, end_date: Date, application_deadline: DT | null,
      registration_status: RegistrationStatus
    },
    match_reasons: string[]
  }]
}
```

推荐条件的可省略性为冷启动场景的编纂补齐；缺省表示不施加对应偏好，不编造 IP / 城市。两端日期都提供时 available_to >= available_from。原物理模型讨论用 preferred_regions，最终 API 已收敛为 **preferred_cities**，不并列支持两个字段。

| Method | Path | Request / Query | Success | 核心 validation / error |
|---|---|---|---|---|
| GET | `/event-listings` | city?、registration_status?、available_from?、available_to? | 200 List<EventListingSummaryResponse> | 日期范围合法 |
| GET | `/event-listings/{event_listing_id}` | 无 | 200 EventListingDetailResponse | 找不到 404 |
| POST | `/event-recommendations` | EventRecommendationRequest | 200 EventRecommendationResponse | 无候选返回 recommendations=[] |
| POST | `/event-listings/{event_listing_id}/add-to-plan` | 无或 `{}` | 201 EventResponse | EVENT_ALREADY_IN_PLAN，details.existing_event_id |

候选从真实 Listing 查得；筛选时间 / 城市 / 报名，再 Tag/IP 匹配与排名。LLM 可选，只解释已有候选；失败用 Python 生成的 match_reasons。不得返回未经定义的 match_score。product_type/budget 只是原对话未来可选项，**V1 不接受、不实现**。

Add to Plan 创建独立快照，默认 PLANNING；复制规则见 03。对同来源存在 status != CANCELLED 的计划（包括 COMPLETED）返回 409，不自动复用或更新旧计划。Listing 无公开写入 API。

## 5. Products

```text
ProductCreate = {
  name: string, product_type: ProductType, description?: string | null,
  default_selling_price?: Money | null, default_currency?: Currency | null
}
ProductUpdate = Partial<ProductCreate + {status: AssetStatus}>
ProductSummaryResponse = {
  product_id: int, name: string, product_type: ProductType,
  default_selling_price: Money | null, default_currency: Currency | null,
  status: AssetStatus, current_stock: int, event_count: int, content_count: int
}
ProductDetailResponse = {
  product_id: int, name: string, product_type: ProductType, description: string | null,
  default_selling_price: Money | null, default_currency: Currency | null,
  status: AssetStatus,
  inventory_summary: {total_received: int, total_sold: int, current_stock: int},
  sales_summary: {event_count: int, latest_event_sales: int | null},
  created_at: DT, updated_at: DT
}
ProductSalesHistoryResponse = {
  product_id: int,
  items: [{event_id: int, event_name: string, event_start_date: Date, total_sold: int}]
}
```

| Method | Path | Request / Query | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/products` | ProductCreate | 201 ProductResponse | 默认 ACTIVE；默认金额 / 货币成对 |
| GET | `/products` | status?、product_type? | 200 List<ProductSummaryResponse> | current_stock 只读 |
| GET | `/products/{product_id}` | 无 | 200 ProductDetailResponse | 不内嵌完整历史批次等 |
| PATCH | `/products/{product_id}` | ProductUpdate | 200 ProductResponse | 不接受 unit_cost/current_stock/historical_sales |
| DELETE | `/products/{product_id}` | 无 | 204 | PRODUCT_HAS_DEPENDENCIES |
| GET | `/products/{product_id}/sales-history` | 无 | 200 ProductSalesHistoryResponse | 按 Event 时间升序；同日用 event_id 稳定排序 |

生产历史另走第 10 节。Product 默认价格修改不影响已存在 Plan。没有历史时 items=[]；latest_event_sales=null（编纂补齐）。

## 6. Contents 与 Product–Content 关联

```text
ContentCreate = {
  title: string, content_type: ContentType, file_url?: string | null,
  thumbnail_url?: string | null, description?: string | null
}
ContentUpdate = Partial<ContentCreate + {status: AssetStatus}>
ContentSummaryResponse = {
  content_id: int, title: string, content_type: ContentType,
  thumbnail_url: string | null, status: AssetStatus, used_in_product_count: int
}
ContentDetailResponse = ContentResponse + {used_in_product_count: int}
LinkedContentResponse = {
  content_id: int, title: string, content_type: ContentType, thumbnail_url: string | null
}
LinkedProductResponse = {product_id: int, name: string, product_type: ProductType}
```

| Method | Path | Request / Query | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/contents` | ContentCreate | 201 ContentResponse | 默认 ACTIVE |
| GET | `/contents` | status?、content_type? | 200 List<ContentSummaryResponse> | used_in_product_count 派生 |
| GET | `/contents/{content_id}` | 无 | 200 ContentDetailResponse | 找不到 404 |
| PATCH | `/contents/{content_id}` | ContentUpdate | 200 ContentResponse | 可 ARCHIVED |
| DELETE | `/contents/{content_id}` | 无 | 204 | CONTENT_IN_USE |
| GET | `/products/{product_id}/contents` | 无 | 200 Items<LinkedContentResponse> | 检查 Product 存在 |
| POST | `/products/{product_id}/contents/{content_id}` | 无 body | 204 | PRODUCT_CONTENT_ALREADY_LINKED |
| DELETE | `/products/{product_id}/contents/{content_id}` | 无 body | 204 | 只解除关系；父实体必须存在 |
| GET | `/contents/{content_id}/products` | 无 | 200 Items<LinkedProductResponse> | 检查 Content 存在 |

解除已不存在关联返回 204 为本次幂等编纂约定。file_url/thumbnail_url 按可空字符串与长度校验，不要求仅能是 HTTP URL；不把写路径扩展为上传功能。

## 7. Event Product Plans

```text
EventProductPlanCreate = {
  product_id: int, selling_price?: Money | null, currency?: Currency | null,
  notes?: string | null
}
EventProductPlanUpdate = {
  selling_price?: Money | null, currency?: Currency | null,
  status?: EventProductStatus, notes?: string | null
}
EventProductPlanSummaryResponse = {
  event_product_plan_id: int, product_id: int, product_name: string, product_type: ProductType,
  selling_price: Money | null, currency: Currency | null, status: EventProductStatus,
  current_stock: int, demand_readiness: ReadinessLevel,
  latest_recommended_production: int | null, recommendation_confidence: ConfidenceLevel | null,
  production_status: BatchStatus | null, warnings: string[]
}
EventProductPlanDetailResponse = {
  event_product_plan_id: int,
  event: {event_id: int, name: string, start_date: Date, end_date: Date},
  product: {product_id: int, name: string, product_type: ProductType},
  selling_price: Money | null, currency: Currency | null, status: EventProductStatus,
  lifecycle: {is_resale: bool, sale_round: int, previous_event_sales: int | null},
  current_stock: int,
  progress: {demand: string, recommendation: string, final_quantity: string,
             production: string, inventory: string, sales: string},
  attention_items: [{type: string, severity: string, message: string}]
}
```

| Method | Path | Request | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/events/{event_id}/product-plans` | EventProductPlanCreate | 201 EventProductPlanResponse | PRODUCT_ALREADY_IN_EVENT；默认 PLANNING |
| GET | `/events/{event_id}/product-plans` | 无 | 200 List<EventProductPlanSummaryResponse> | 全部派生值只读 |
| GET | `/event-product-plans/{plan_id}` | 无 | 200 EventProductPlanDetailResponse | PLAN_NOT_FOUND |
| PATCH | `/event-product-plans/{plan_id}` | EventProductPlanUpdate | 200 EventProductPlanResponse | PRICE_REQUIRED；不能换 event/product |
| DELETE | `/event-product-plans/{plan_id}` | 无 | 204 | EVENT_PRODUCT_PLAN_HAS_DEPENDENCIES |

创建时，省略价格对可复制 Product 的默认价格对；显式同时 null 表示暂未定价。只传其中一个且最终不成对则 422（遗漏与显式 null 的编纂约定）。READY/SELLING 必须有价格，禁止在保持该状态时清空价格。

progress 原文仅给 READY/GENERATED/CONFIRMED/IN_PROGRESS/NOT_ALLOCATED/NOT_STARTED 示例，没有完整枚举和判定表，见 SC-05；不得把示例字符串照抄为全部 Plan 的响应。ProductionBatch 属 Product，不能假装某批次被 FK 精确绑定该 Plan。

## 8. Demand Signals 与 Readiness

```text
DemandSignalCreate = {
  signal_type: SignalType, value: int, source?: string | null,
  observed_at: DT, notes?: string | null
}
DemandReadinessResponse = {
  level: ReadinessLevel, is_resale: bool, sale_round: int,
  checks: {historical_sales: bool, current_event_survey: bool, wishlist: bool,
           preorder: bool, recent_social_signal: bool},
  latest_signals: {[SignalType]: {value: int, observed_at: DT}},
  warnings: [{code: string, message: string}]
}
```

| Method | Path | Request / Query | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/event-product-plans/{plan_id}/demand-signals` | DemandSignalCreate | 201 DemandSignalResponse | value >= 0；observed_at 必须有时区 |
| GET | `/event-product-plans/{plan_id}/demand-signals` | signal_type? | 200 Items<DemandSignalResponse> | 历史按 observed_at DESC、signal_id DESC |
| DELETE | `/demand-signals/{signal_id}` | 无 | 204 | 允许删除录错快照 |
| GET | `/event-product-plans/{plan_id}/demand-readiness` | 无 | 200 DemandReadinessResponse | 所有值由 Python 计算 |

**没有 DemandSignalUpdate / PATCH。** 缺少某种 signal 时 latest_signals 不含该 key；有效 0 值必须保留，不能当作缺失。Readiness LOW 不自动等于不能推荐；真正无有效需求数据才返回 INSUFFICIENT_DEMAND_DATA。

原文已出现 warning `NEW_SURVEY_RECOMMENDED`；同类快照不累加。完整 readiness 阈值尚未冻结，见 SC-05。

## 9. Recommendations 与 Quantity Decisions

```text
QuantityRangeResponse = {conservative: int, balanced: int, aggressive: int, recommended: int}
QuantityDecisionResponse = {
  decision_id: int, event_product_plan_id: int, created_at: DT,
  current_stock_snapshot: int, confidence_level: ConfidenceLevel,
  recommended_strategy: RecommendationStrategy,
  demand: QuantityRangeResponse, production: QuantityRangeResponse,
  warnings: [{code: string, message: string}],
  recommendation_reason: string | null, explanation_status: ExplanationStatus,
  final_production_quantity: int | null, confirmed_at: DT | null,
  is_stale?: bool, stale_reasons?: string[]
}
QuantityDecisionSummaryResponse = {
  decision_id: int, created_at: DT, recommended_strategy: RecommendationStrategy,
  recommended_demand: int, recommended_production: int,
  final_production_quantity: int | null, confidence_level: ConfidenceLevel
}
FinalDecisionUpdate = {final_production_quantity: int, decision_note?: string | null}
FinalDecisionResponse = {
  decision_id: int, recommended_production: int,
  final_production_quantity: int, confirmed_at: DT
}
```

本节 stale 两字段的 `?` 是原文允许的**响应可选扩展**，应同时出现；不能把 is_stale 作为存储字段。Schema 大纲曾省略 event_product_plan_id，此处沿用较完整的 API response，保留归属 ID。

| Method | Path | Request | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/event-product-plans/{plan_id}/recommendations` | 无或 `{}` | 201 QuantityDecisionResponse | PLAN_NOT_FOUND；INSUFFICIENT_DEMAND_DATA |
| GET | `/event-product-plans/{plan_id}/recommendations` | 无 | 200 Items<QuantityDecisionSummaryResponse> | created_at DESC，decision_id DESC |
| GET | `/quantity-decisions/{decision_id}` | 无 | 200 QuantityDecisionResponse | 读取当次已保存数值 |
| PATCH | `/quantity-decisions/{decision_id}/final-decision` | FinalDecisionUpdate | 200 FinalDecisionResponse | final >= 0；允许多次确认 |

response 映射：demand.conservative ← demand_conservative；demand.recommended ← recommended_demand；production 对应 production_*。LLM 只提供 recommendation_reason，explanation_status 为 AVAILABLE/UNAVAILABLE。

```json
{
  "decision_id": 91,
  "event_product_plan_id": 56,
  "created_at": "2026-09-21T12:00:00Z",
  "current_stock_snapshot": 30,
  "confidence_level": "MEDIUM",
  "recommended_strategy": "BALANCED",
  "demand": {"conservative": 60, "balanced": 80, "aggressive": 100, "recommended": 80},
  "production": {"conservative": 30, "balanced": 50, "aggressive": 70, "recommended": 50},
  "warnings": [{"code": "CUMULATIVE_WISHLIST", "message": "Wishlist is supporting evidence."}],
  "recommendation_reason": null,
  "explanation_status": "UNAVAILABLE",
  "final_production_quantity": null,
  "confirmed_at": null
}
```

上例只说明协议与减库存公式，不代表需求算法固定为 60/80/100。再贩无新印调降置信并提示，不阻塞；没有 LLM 或 LLM 失败仍 201。每次 regenerate 新建 Decision，不能覆盖旧行。final=0 合法；confirmed_at 更新为最近确认时间；不强制 final==recommended、不自动下单。

新加入信号可能让已有 recommendation stale；不能因为 stale 自动改掉历史结果。历史 warnings 的保真缺口见 SC-03；完整 stale 触发集见 SC-05。

## 10. Vendors 与 Production Batches

```text
VendorCreate = {name: string, contact?: string | null, website?: string | null, notes?: string | null}
VendorUpdate = Partial<VendorCreate + {status: AssetStatus}>
ProductionBatchCreate = {
  vendor_id?: int | null, ordered_quantity: int,
  unit_cost?: Money | null, currency?: Currency | null,
  status?: BatchStatus, expected_at?: DT | null, notes?: string | null
}
ProductionBatchUpdate = {
  vendor_id?: int | null, ordered_quantity?: int,
  received_quantity?: int | null, unit_cost?: Money | null, currency?: Currency | null,
  status?: BatchStatus, ordered_at?: DT | null,
  expected_at?: DT | null, received_at?: DT | null, notes?: string | null
}
ProductionBatchSummaryResponse = {
  batch_id: int, vendor_name: string | null, ordered_quantity: int,
  received_quantity: int | null, unit_cost: Money | null, currency: Currency | null,
  status: BatchStatus, ordered_at: DT | null, expected_at: DT | null, received_at: DT | null
}
```

| Method | Path | Request / Query | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/vendors` | VendorCreate | 201 VendorResponse | 默认 ACTIVE |
| GET | `/vendors` | status? | 200 List<VendorResponse> | 列表 total 为编纂补齐 |
| GET | `/vendors/{vendor_id}` | 无 | 200 VendorResponse | VENDOR_NOT_FOUND |
| PATCH | `/vendors/{vendor_id}` | VendorUpdate | 200 VendorResponse | 可归档 |
| DELETE | `/vendors/{vendor_id}` | 无 | 204 | VENDOR_HAS_DEPENDENCIES |
| POST | `/products/{product_id}/production-batches` | ProductionBatchCreate | 201 ProductionBatchResponse | 默认 PLANNED；ordered_quantity > 0 |
| GET | `/products/{product_id}/production-batches` | 无 | 200 Items<ProductionBatchSummaryResponse> | 从 Product 查全部批次 |
| GET | `/production-batches/{batch_id}` | 无 | 200 ProductionBatchResponse | BATCH_NOT_FOUND |
| PATCH | `/production-batches/{batch_id}` | ProductionBatchUpdate | 200 ProductionBatchResponse | 按合并后目标状态校验必要字段 |
| DELETE | `/production-batches/{batch_id}` | 无 | 204 | BATCH_NOT_DELETABLE |

Create 没有 ordered_at/received_at/received_quantity；因此不得声称支持直接创建 ORDERED/RECEIVED：缺少必要数据就按规则拒绝，先创建 PLANNED 再 PATCH。是否收窄 Create.status 枚举见 SC-04，不能擅改 body 字段。

ORDERED/PRODUCING/SHIPPED/RECEIVED 均需 vendor_id、unit_cost、currency、ordered_at；RECEIVED 还需 received_quantity/received_at。PLANNED 可无报价。零成本成对有 currency 合法。不得让非 RECEIVED 批次贡献库存；不可重命名 ordered_quantity 为 quantity。

## 11. Sample Rounds

```text
SampleRoundCreate = {
  round_number: int, status?: SampleStatus, submitted_at?: DT | null,
  sample_cost?: Money | null, currency?: Currency | null, notes?: string | null
}
SampleRoundUpdate = Partial<SampleRoundCreate + {received_at: DT | null}>
```

| Method | Path | Request | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/production-batches/{batch_id}/sample-rounds` | SampleRoundCreate | 201 SampleRoundResponse | 默认 PENDING；round_number > 0 |
| GET | `/production-batches/{batch_id}/sample-rounds` | 无 | 200 Items<SampleRoundResponse> | 按 round_number 升序（编纂约定） |
| PATCH | `/sample-rounds/{sample_id}` | SampleRoundUpdate | 200 SampleRoundResponse | SAMPLE_ROUND_ALREADY_EXISTS |
| DELETE | `/sample-rounds/{sample_id}` | 无 | 204 | 允许删除错误记录 |

没有单独 GET /sample-rounds/{id} 或强制审批 API。SampleRoundUpdate 的可编辑普通字段沿 Create 补齐，不允许修改 batch_id。状态完整迁移限制见 SC-04。

## 12. Inventory Allocation

```text
InventoryAllocationUpsert = {allocated_quantity: int, notes?: string | null}
InventoryAllocationResponse = {
  current_stock: int, reserved_by_other_events: int, max_allocatable_quantity: int,
  allocated_quantity: int, event_sold_quantity: int, event_remaining_quantity: int,
  unallocated_available_stock: int
}
```

| Method | Path | Request | Success | 核心 validation / error |
|---|---|---|---|---|
| GET | `/event-product-plans/{plan_id}/inventory-allocation` | 无 | 200 InventoryAllocationResponse | Plan 存在但未分配仍返回状态 |
| PUT | `/event-product-plans/{plan_id}/inventory-allocation` | InventoryAllocationUpsert | 200 InventoryAllocationResponse | 新建或替换累计量；非增量 |
| DELETE | `/event-product-plans/{plan_id}/inventory-allocation` | 无 | 204 | ALLOCATION_HAS_SALES |

无 allocation 行时 allocated_quantity/event_sold_quantity/event_remaining_quantity 为 0（编纂补齐）；零分配行与未分配行响应数值可能相同，SalesService 必须查真实存在性，不能凭 0 推断。DELETE 不存在行幂等 204，Plan 不存在 404。

不返回在途货作为可分配库存。原契约：`max_allocatable_quantity = current_stock - reserved_by_other_events` 且 `allocated_quantity <= max_allocatable_quantity`；该规则销售后冲突，**见 SC-01，未批准前不得改成另一公式上线**。原示例的 unallocated_available_stock 也不自洽，本文件不把该错误示例当计算依据。

## 13. Sales Records 与 Summary

```text
SalesRecordCreate = {sale_date: Date, sold_quantity: int, notes?: string | null}
SalesRecordUpdate = Partial<SalesRecordCreate>
SalesRecordListItem = {
  sales_record_id: int, sale_date: Date, sold_quantity: int, remaining_after_sale: int
}
SalesSummaryResponse = {
  allocated_quantity: int, total_sold: int, event_remaining: int,
  sell_through_rate: number | null,
  planning_vs_actual: {
    balanced_demand_estimate: int | null, final_user_allocation: int, actual_sales: int
  }
}
```

| Method | Path | Request | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/event-product-plans/{plan_id}/sales-records` | SalesRecordCreate | 201 SalesRecordResponse | INVENTORY_NOT_ALLOCATED / SALES_RECORD_ALREADY_EXISTS |
| GET | `/event-product-plans/{plan_id}/sales-records` | 无 | 200 Items<SalesRecordListItem> | 按 sale_date 升序（编纂约定） |
| PATCH | `/sales-records/{sales_record_id}` | SalesRecordUpdate | 200 SalesRecordResponse | 替换旧日汇总后验累计上限 |
| DELETE | `/sales-records/{sales_record_id}` | 无 | 204 | 允许更正错误事实 |
| GET | `/event-product-plans/{plan_id}/sales-summary` | 无 | 200 SalesSummaryResponse | 所有 summary 指标派生 |

累计销量不能超过 allocation；不能把同一天修改当增量追加。remaining_after_sale 是当前 allocation 减按销售日期累计至该记录的销量（编纂约定），不是不可修改的当时库存快照。

sell_through_rate 为比率，例如 0.9；分母为 0 返回 null。尚无 Decision 时 balanced_demand_estimate=null；final_user_allocation 对应分配量，**不是 final_production_quantity**。多 Decision 选择口径见 SC-05。

## 14. Tasks

```text
TaskCreate = {
  title: string, task_type: TaskType, event_product_plan_id?: int | null,
  due_at?: DT | null, notes?: string | null
}
TaskUpdate = Partial<TaskCreate + {status: TaskStatus}>
TaskResponse = <03 Task 全部字段> + {display_status: TaskDisplayStatus}
TaskListItem = {
  task_id: int, title: string, task_type: TaskType, status: TaskStatus,
  display_status: TaskDisplayStatus, due_at: DT | null,
  event_product_plan_id: int | null, product_name: string | null
}
```

| Method | Path | Request / Query | Success | 核心 validation / error |
|---|---|---|---|---|
| POST | `/events/{event_id}/tasks` | TaskCreate | 201 TaskResponse | 默认 TODO；TASK_EVENT_MISMATCH |
| GET | `/events/{event_id}/tasks` | status?、task_type? | 200 Items<TaskListItem> | status 只接受 stored states |
| GET | `/event-product-plans/{plan_id}/tasks` | 无 | 200 Items<TaskListItem> | 仅该 Plan 的任务 |
| PATCH | `/tasks/{task_id}` | TaskUpdate | 200 TaskResponse | DONE 自动 completed_at；重开清空 |
| DELETE | `/tasks/{task_id}` | 无 | 204 | DONE 也可删 |

禁止 body 写 event_id、completed_at、display_status；修改可选 Plan 关联时仍检查同 Event。请求 status=OVERDUE 返回 422。CANCELLED Task 的派生展示冲突见 SC-02。

## 15. Dashboard

| Method | Path | Request | Success |
|---|---|---|---|
| GET | `/dashboard` | 无 | 200 DashboardResponse |

```text
DashboardResponse = {
  next_event: {event_id: int, name: string, start_date: Date,
               days_remaining: int, status: EventStatus} | null,
  attention_items: [{type: string, severity: string, event_id: int,
                    event_product_plan_id: int | null, product_name: string | null,
                    message: string}],
  upcoming_tasks: [{task_id: int, title: string, due_at: DT | null}],
  production_summary: {sampling: int, producing: int, shipped: int},
  recent_products: ProductSummaryResponse[]
}
```

recent_products 原文仅给空数组，本次用已存在 ProductSummaryResponse 作为候选补齐形状；采用前需连同 SC-05 审定选择数量与排序，不能把未知当作已冻结。

冷启动精确返回：

```json
{
  "next_event": null,
  "attention_items": [],
  "upcoming_tasks": [],
  "production_summary": {"sampling": 0, "producing": 0, "shipped": 0},
  "recent_products": []
}
```

只聚合 Service，不另建 Dashboard/Analytics 表，不把聚合值持久化。

## 16. Backend Skeleton Health

| Method | Path | Request | Success |
|---|---|---|---|
| GET | `/health`（完整路径 `/api/v1/health`） | 无 | 200 `{"status":"ok"}` |

只验证进程和路由可用，不要求 MySQL 或 LLM 可用；不能把 `database: connected` 当作 V1 固定响应加入。MySQL 连通性另行 smoke 验证。

## 17. 实现前的协议检查

1. 本文共列 65 个业务 method/path 和 1 个 health，已与原对话的 API V1 Endpoint Map 逐项核对；每条实现都需对照请求、响应和状态码。
2. 必须保留 `/events` 与 `/event-listings` 区别，以及嵌套资源的父 ID。不要改写成 `/ai/generate-quantity` 等路径。
3. 03 是存储契约，04 是 HTTP 契约。无需把每个表机械做全 CRUD；未列出的端点不自动补。
4. schema / 状态问题按 05 的 SC 条目处理；缺失规则不以 mock 固定值或未经批准的新字段补齐。

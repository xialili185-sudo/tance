"""Read-only environment check; never prints passwords or LLM API keys."""
from importlib.metadata import version
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))


def main() -> int:
    print(f"Python {platform.python_version()} · {platform.machine()}")
    failures = []
    if sys.version_info[:2] != (3, 13):
        failures.append("Run this script with backend/.venv/bin/python (Python 3.13).")
    for command in (["node", "--version"], ["npm", "--version"], ["git", "--version"]):
        try:
            print(subprocess.check_output(command, text=True).strip())
        except (OSError, subprocess.CalledProcessError):
            failures.append(f"Unavailable: {command[0]}")
    for package in ("fastapi", "pydantic", "SQLAlchemy", "alembic", "PyMySQL", "pytest", "httpx", "uvicorn"):
        try:
            print(f"{package} {version(package)}")
        except Exception:
            failures.append(f"Missing dependency: {package}")
    try:
        from sqlalchemy import create_engine, text
        from app.config import get_settings
        from app.ai.client import configuration_status
        settings = get_settings()
        for is_test in (False, True):
            engine = create_engine(settings.database_url(test=is_test), connect_args={"connect_timeout": 3})
            try:
                with engine.connect() as conn:
                    row = conn.execute(text("SELECT DATABASE(), VERSION(), @@character_set_database")).one()
                    print(f"MySQL connected: {row[0]} · {row[1]} · {row[2]}")
            finally:
                engine.dispose()
        print(f"LLM: {configuration_status(settings)} (configuration only; no paid request)")
    except Exception as error:
        failures.append(f"Database/configuration check failed ({type(error).__name__}); inspect .env and local MySQL service.")
    for failure in failures:
        print(f"FAIL: {failure}")
    print("Environment checks passed." if not failures else "Environment needs attention.")
    return bool(failures)


if __name__ == "__main__":
    sys.exit(main())

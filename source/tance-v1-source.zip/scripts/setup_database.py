"""Initialize local development databases without exposing credentials.

Run using backend/.venv/bin/python. --secure-new-root is only for a fresh,
passwordless Homebrew installation; existing authenticated root is preserved.
"""
import argparse
import configparser
import os
from pathlib import Path
import secrets
import sys

import pymysql
from dotenv import dotenv_values

ROOT = Path(__file__).resolve().parents[1]


def private_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w") as file:
        file.write(text)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--secure-new-root", action="store_true")
    args = parser.parse_args()
    env_path = ROOT / ".env"
    if not env_path.exists():
        template = (ROOT / ".env.example").read_text()
        private_write(env_path, template.replace("replace_with_your_local_password", secrets.token_urlsafe(32)))
    settings = dotenv_values(env_path)
    if settings.get("DATABASE_HOST") != "127.0.0.1" or settings.get("DATABASE_USER") != "tance":
        raise RuntimeError("This setup script only initializes the local tance account.")
    names = [settings["DATABASE_NAME"], settings["TEST_DATABASE_NAME"]]
    if names != ["tance_dev", "tance_test"]:
        raise RuntimeError("Only tance_dev and tance_test may be initialized by this script.")
    admin_path = ROOT / ".secrets/mysql-admin.cnf"
    root_password = os.environ.get("MYSQL_ADMIN_PASSWORD", "")
    if admin_path.exists():
        config = configparser.ConfigParser(interpolation=None)
        config.read(admin_path)
        root_password = config["client"]["password"]
    connection = pymysql.connect(user="root", password=root_password,
        unix_socket="/tmp/mysql.sock", autocommit=True, connect_timeout=5)
    with connection, connection.cursor() as cursor:
        if args.secure_new_root and not root_password:
            cursor.execute("SHOW DATABASES")
            existing = {row[0] for row in cursor.fetchall()}
            if existing - {"mysql", "sys", "information_schema", "performance_schema", "tance_dev", "tance_test"}:
                raise RuntimeError("Existing non-TANCE databases found; root credentials left unchanged.")
            new_root_password = secrets.token_urlsafe(40)
            private_write(admin_path, f"[client]\nuser=root\npassword={new_root_password}\nsocket=/tmp/mysql.sock\n")
            cursor.execute("ALTER USER 'root'@'localhost' IDENTIFIED BY %s", (new_root_password,))
            print("Fresh local root secured; credentials stored in ignored .secrets/mysql-admin.cnf (0600).")
        for name in names:
            cursor.execute(f"CREATE DATABASE IF NOT EXISTS `{name}` CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci")
        cursor.execute("CREATE USER IF NOT EXISTS 'tance'@'localhost' IDENTIFIED BY %s", (settings["DATABASE_PASSWORD"],))
        for name in names:
            cursor.execute(f"GRANT ALL PRIVILEGES ON `{name}`.* TO 'tance'@'localhost'")
    for name in names:
        with pymysql.connect(host="127.0.0.1", port=int(settings["DATABASE_PORT"] or 3306),
                            user="tance", password=settings["DATABASE_PASSWORD"],
                            database=name, charset="utf8mb4", connect_timeout=5) as db:
            with db.cursor() as cursor:
                cursor.execute("SELECT 1")
                assert cursor.fetchone() == (1,)
        print(f"Verified local application access: {name}")


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(f"Database setup failed ({type(error).__name__}); existing data was not deleted.", file=sys.stderr)
        raise SystemExit(1) from None

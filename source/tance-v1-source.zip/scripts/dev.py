"""Run both development servers; Ctrl+C stops only processes started here."""
import os
from pathlib import Path
import shutil
import signal
import socket
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    for port in (5173, 8000):
        with socket.socket() as sock:
            try:
                sock.bind(("127.0.0.1", port))
            except OSError:
                print(f"Port {port} is already in use. Stop that service or reuse the existing TANCE session.")
                return 1
    npm = shutil.which("npm")
    python = ROOT / "backend/.venv/bin/python"
    if not npm or not python.exists():
        print("Install project dependencies first; see README.md.")
        return 1
    processes: list[subprocess.Popen] = []
    def stop(_signal=None, _frame=None):
        raise KeyboardInterrupt
    signal.signal(signal.SIGTERM, stop)
    try:
        processes.append(subprocess.Popen([str(python), "-m", "uvicorn", "app.main:app", "--reload", "--host", "127.0.0.1", "--port", "8000"], cwd=ROOT / "backend", start_new_session=True))
        processes.append(subprocess.Popen([npm, "run", "dev"], cwd=ROOT / "frontend", start_new_session=True))
        print("Frontend: http://127.0.0.1:5173\nAPI docs: http://127.0.0.1:8000/docs", flush=True)
        while all(process.poll() is None for process in processes):
            time.sleep(0.3)
        return 1
    except KeyboardInterrupt:
        return 0
    finally:
        for process in processes:
            try:
                os.killpg(process.pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
        for process in processes:
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()


if __name__ == "__main__":
    sys.exit(main())

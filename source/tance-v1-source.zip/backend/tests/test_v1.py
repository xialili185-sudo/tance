from datetime import date, timedelta
from sqlalchemy import inspect, select, text
from app import models as m
from app.core.policy import business_today
from app.db.types import utcnow


def request(api, method, path, expected=200, body=None):
    response = api.request(
        method, "/api/v1" + path, **({"json": body} if body is not None else {})
    )
    assert response.status_code == expected, (
        method,
        path,
        response.status_code,
        response.text,
    )
    return response.json() if expected != 204 else None


def product(api, **extra):
    return request(
        api,
        "POST",
        "/products",
        201,
        {"name": "徽章", "product_type": "BADGE", **extra},
    )


def event(api, **extra):
    day = business_today() + timedelta(days=60)
    return request(
        api,
        "POST",
        "/events",
        201,
        {
            "name": "测试展",
            "location": "上海",
            "start_date": day.isoformat(),
            "end_date": day.isoformat(),
            **extra,
        },
    )


def plan(api, event_id, product_id, **extra):
    return request(
        api,
        "POST",
        f"/events/{event_id}/product-plans",
        201,
        {"product_id": product_id, **extra},
    )


def received(api, product_id, quantity=100):
    vendor = request(api, "POST", "/vendors", 201, {"name": "测试厂商"})
    batch = request(
        api,
        "POST",
        f"/products/{product_id}/production-batches",
        201,
        {
            "ordered_quantity": quantity,
            "vendor_id": vendor["vendor_id"],
            "unit_cost": "2.00",
            "currency": "CNY",
        },
    )
    request(
        api,
        "PATCH",
        f"/production-batches/{batch['batch_id']}",
        body={"status": "ORDERED", "ordered_at": utcnow().isoformat()},
    )
    return request(
        api,
        "PATCH",
        f"/production-batches/{batch['batch_id']}",
        body={
            "status": "RECEIVED",
            "received_quantity": quantity,
            "received_at": utcnow().isoformat(),
        },
    )


def test_health_and_frozen_endpoint_map(api, mysql_engine):
    assert request(api, "GET", "/health") == {"status": "ok"}
    from app.main import app
    from pathlib import Path
    import re

    spec = Path("../docs/specs/04-api-contract.md").read_text()
    entries = re.findall(r"^\| (GET|POST|PATCH|PUT|DELETE) \| `([^`]+)`", spec, re.M)
    actual = {
        (verb.upper(), path)
        for path, ops in app.openapi()["paths"].items()
        for verb in ops
        if verb in ["get", "post", "patch", "put", "delete"]
    }
    assert len(entries) == 66
    assert {(method, "/api/v1" + path) for method, path in entries} <= actual
    inspector = inspect(mysql_engine)
    assert len(set(inspector.get_table_names()) - {"alembic_version"}) == 15
    assert "current_stock" not in {c["name"] for c in inspector.get_columns("products")}
    assert "warnings" in {
        c["name"] for c in inspector.get_columns("quantity_decisions")
    }
    assert "updated_at" not in {
        c["name"] for c in inspector.get_columns("demand_signals")
    }
    assert {
        tuple(x["column_names"])
        for x in inspector.get_unique_constraints("event_product_plans")
    } == {("event_id", "product_id")}
    assert (
        inspector.get_foreign_keys("event_plans")[0]["options"]["ondelete"]
        == "SET NULL"
    )


def test_product_content_contract_and_patch(api):
    p = product(api, default_selling_price="0.00", default_currency="CNY")
    pid = p["product_id"]
    assert p["default_selling_price"] == "0.00"
    assert (
        request(api, "PATCH", f"/products/{pid}", body={"name": "new"})[
            "default_currency"
        ]
        == "CNY"
    )
    assert (
        request(api, "PATCH", f"/products/{pid}", 422, {"default_currency": None})[
            "code"
        ]
        == "INVALID_MONEY_PAIR"
    )
    assert request(api, "GET", f"/products/{pid}")["default_currency"] == "CNY"
    for payload in [
        {"name": None},
        {"current_stock": 100},
        {"default_selling_price": 3.14},
        {"default_selling_price": "NaN"},
        {"default_selling_price": "1.001"},
        {"status": "SELLING"},
        {"product_type": "IMAGE"},
    ]:
        assert (
            request(api, "PATCH", f"/products/{pid}", 422, payload)["code"]
            == "VALIDATION_ERROR"
        )
    c = request(
        api,
        "POST",
        "/contents",
        201,
        {"title": "画稿", "content_type": "ILLUSTRATION", "file_url": "local/art.png"},
    )
    cid = c["content_id"]
    request(api, "POST", f"/products/{pid}/contents/{cid}", 204)
    assert (
        request(api, "POST", f"/products/{pid}/contents/{cid}", 409)["code"]
        == "PRODUCT_CONTENT_ALREADY_LINKED"
    )
    assert request(api, "GET", f"/contents/{cid}")["used_in_product_count"] == 1
    assert request(api, "DELETE", f"/contents/{cid}", 409)["code"] == "CONTENT_IN_USE"
    assert (
        request(api, "GET", f"/contents/{cid}/products")["items"][0]["product_id"]
        == pid
    )
    assert (
        request(api, "GET", f"/products/{pid}/contents")["items"][0]["content_id"]
        == cid
    )
    request(api, "PATCH", f"/contents/{cid}", body={"status": "ARCHIVED"})
    request(api, "GET", "/contents?status=ARCHIVED&content_type=ILLUSTRATION")
    request(api, "DELETE", f"/products/{pid}/contents/{cid}", 204)
    request(api, "DELETE", f"/products/{pid}/contents/{cid}", 204)
    request(api, "DELETE", f"/contents/{cid}", 204)
    request(api, "PATCH", f"/products/{pid}", body={"status": "ARCHIVED"})
    request(api, "PATCH", f"/products/{pid}", body={"status": "ACTIVE"})
    request(api, "GET", "/products?status=ACTIVE&product_type=BADGE")
    request(api, "DELETE", f"/products/{pid}", 204)
    assert request(api, "GET", f"/products/{pid}", 404)["code"] == "PRODUCT_NOT_FOUND"


def test_inventory_sales_full_cycle_and_rollback(api):
    p = product(api)
    pid = p["product_id"]
    e = event(api)
    plan1 = plan(api, e["event_id"], pid)
    plan_id = plan1["event_product_plan_id"]
    e2 = event(api)
    plan2 = plan(api, e2["event_id"], pid)
    other = plan2["event_product_plan_id"]
    batch = received(api, pid, 100)
    assert (
        request(api, "GET", f"/products/{pid}")["inventory_summary"]["current_stock"]
        == 100
    )
    request(
        api,
        "PUT",
        f"/event-product-plans/{plan_id}/inventory-allocation",
        body={"allocated_quantity": 50},
    )
    request(
        api,
        "PUT",
        f"/event-product-plans/{other}/inventory-allocation",
        body={"allocated_quantity": 30},
    )
    assert (
        request(api, "GET", f"/products/{pid}")["inventory_summary"]["current_stock"]
        == 100
    )
    sale = request(
        api,
        "POST",
        f"/event-product-plans/{plan_id}/sales-records",
        201,
        {"sale_date": "2026-09-20", "sold_quantity": 20},
    )
    state = request(api, "GET", f"/event-product-plans/{plan_id}/inventory-allocation")
    assert state == {
        "current_stock": 80,
        "reserved_by_other_events": 30,
        "max_allocatable_quantity": 70,
        "allocated_quantity": 50,
        "event_sold_quantity": 20,
        "event_remaining_quantity": 30,
        "unallocated_available_stock": 20,
    }
    request(
        api,
        "PUT",
        f"/event-product-plans/{plan_id}/inventory-allocation",
        body={"allocated_quantity": 70},
    )
    assert (
        request(
            api,
            "PUT",
            f"/event-product-plans/{other}/inventory-allocation",
            422,
            {"allocated_quantity": 31},
        )["code"]
        == "ALLOCATION_EXCEEDS_AVAILABLE_STOCK"
    )
    assert (
        request(
            api,
            "PUT",
            f"/event-product-plans/{plan_id}/inventory-allocation",
            422,
            {"allocated_quantity": 19},
        )["code"]
        == "ALLOCATION_BELOW_SALES"
    )
    request(
        api,
        "PATCH",
        f"/sales-records/{sale['sales_record_id']}",
        body={"sold_quantity": 30},
    )
    assert (
        request(api, "GET", f"/products/{pid}")["inventory_summary"]["current_stock"]
        == 70
    )
    request(
        api,
        "PATCH",
        f"/sales-records/{sale['sales_record_id']}",
        422,
        {"sold_quantity": 71},
    )
    assert (
        request(api, "GET", f"/products/{pid}")["inventory_summary"]["current_stock"]
        == 70
    )
    assert (
        request(
            api,
            "PATCH",
            f"/production-batches/{batch['batch_id']}",
            409,
            {"received_quantity": 99},
        )["code"]
        == "STOCK_CONFLICT"
    )
    assert (
        request(api, "GET", f"/production-batches/{batch['batch_id']}")[
            "received_quantity"
        ]
        == 100
    )
    assert (
        request(
            api,
            "POST",
            f"/event-product-plans/{plan_id}/sales-records",
            409,
            {"sale_date": "2026-09-20", "sold_quantity": 1},
        )["code"]
        == "SALES_RECORD_ALREADY_EXISTS"
    )
    request(api, "DELETE", f"/event-product-plans/{plan_id}/inventory-allocation", 409)
    assert (
        request(api, "GET", f"/event-product-plans/{plan_id}/sales-records")["items"][
            0
        ]["remaining_after_sale"]
        == 40
    )
    assert (
        request(api, "GET", f"/event-product-plans/{plan_id}/sales-summary")[
            "total_sold"
        ]
        == 30
    )
    assert (
        request(api, "GET", f"/products/{pid}/sales-history")["items"][0]["total_sold"]
        == 30
    )
    request(api, "PATCH", f"/events/{e['event_id']}", body={"status": "CANCELLED"})
    assert (
        request(api, "GET", f"/event-product-plans/{other}/inventory-allocation")[
            "unallocated_available_stock"
        ]
        == 40
    )
    request(api, "DELETE", f"/sales-records/{sale['sales_record_id']}", 204)
    assert (
        request(api, "GET", f"/products/{pid}")["inventory_summary"]["current_stock"]
        == 100
    )
    request(api, "DELETE", f"/event-product-plans/{plan_id}/inventory-allocation", 204)
    assert (
        request(api, "DELETE", f"/events/{e['event_id']}", 409)["code"]
        == "EVENT_HAS_DEPENDENCIES"
    )
    assert (
        request(api, "DELETE", f"/products/{pid}", 409)["code"]
        == "PRODUCT_HAS_DEPENDENCIES"
    )


def test_demand_history_recommendations_and_zero_confirmation(api):
    p = product(api)
    e = event(api)
    pid = plan(api, e["event_id"], p["product_id"])["event_product_plan_id"]
    base = f"/event-product-plans/{pid}"
    assert (
        request(api, "POST", base + "/recommendations", 422)["code"]
        == "INSUFFICIENT_DEMAND_DATA"
    )
    observed = utcnow()

    def signal(value, when, kind="EVENT_INTEREST_SURVEY"):
        return request(
            api,
            "POST",
            base + "/demand-signals",
            201,
            {"signal_type": kind, "value": value, "observed_at": when.isoformat()},
        )

    signal(21, observed - timedelta(days=2))
    latest = signal(38, observed)
    signal(29, observed - timedelta(days=1))
    signal(1000, observed + timedelta(days=1))
    assert (
        request(api, "GET", base + "/demand-readiness")["latest_signals"][
            "EVENT_INTEREST_SURVEY"
        ]["value"]
        == 38
    )
    assert request(api, "GET", base + "/demand-signals")["items"][0]["value"] == 1000
    signal(0, observed, "PREORDER_COUNT")
    decision = request(api, "POST", base + "/recommendations", 201)
    assert decision["demand"] == {
        "conservative": 24,
        "balanced": 31,
        "aggressive": 38,
        "recommended": 31,
    }
    assert decision["confidence_level"] == "HIGH"
    assert (
        decision["recommendation_reason"] is None
        and decision["explanation_status"] == "UNAVAILABLE"
    )
    did = decision["decision_id"]
    final = request(
        api,
        "PATCH",
        f"/quantity-decisions/{did}/final-decision",
        body={"final_production_quantity": 0},
    )
    assert final["final_production_quantity"] == 0 and final["confirmed_at"]
    request(
        api,
        "PATCH",
        f"/quantity-decisions/{did}/final-decision",
        body={"final_production_quantity": 7, "decision_note": "manual"},
    )
    signal(999, observed, "WISHLIST_COUNT")
    second = request(api, "POST", base + "/recommendations", 201)
    assert second["decision_id"] != did and second["warnings"]
    request(api, "DELETE", f"/demand-signals/{latest['signal_id']}", 204)
    assert (
        request(api, "GET", f"/quantity-decisions/{did}")["demand"]
        == decision["demand"]
    )
    assert (
        request(api, "GET", f"/quantity-decisions/{second['decision_id']}")["warnings"]
        == second["warnings"]
    )
    assert len(request(api, "GET", base + "/recommendations")["items"]) == 2
    request(
        api,
        "POST",
        base + "/demand-signals",
        422,
        {
            "signal_type": "MANUAL_ESTIMATE",
            "value": True,
            "observed_at": observed.isoformat(),
        },
    )
    request(
        api,
        "POST",
        base + "/demand-signals",
        422,
        {
            "signal_type": "MANUAL_ESTIMATE",
            "value": 1,
            "observed_at": "2026-09-20T10:00:00",
        },
    )
    request(api, "DELETE", base, 409)


def test_events_tasks_prices_states_and_dashboard(api):
    empty = request(api, "GET", "/dashboard")
    assert empty["next_event"] is None and empty["recent_products"] == []
    e = event(api)
    eid = e["event_id"]
    other = event(api)
    p = product(api, default_selling_price="20.00", default_currency="CNY")
    plan1 = plan(api, eid, p["product_id"])
    pid = plan1["event_product_plan_id"]
    assert plan1["selling_price"] == "20.00"
    assert (
        request(api, "PATCH", f"/events/{eid}", 422, {"end_date": "2000-01-01"})["code"]
        == "INVALID_EVENT_DATE"
    )
    assert request(api, "GET", f"/events/{eid}")["end_date"] == e["end_date"]
    request(
        api,
        "POST",
        f"/events/{eid}/product-plans",
        409,
        {"product_id": p["product_id"]},
    )
    request(api, "PATCH", f"/event-product-plans/{pid}", 409, {"status": "SELLING"})
    request(api, "PATCH", f"/event-product-plans/{pid}", body={"status": "PREPARING"})
    request(api, "PATCH", f"/event-product-plans/{pid}", body={"status": "READY"})
    assert (
        request(
            api,
            "PATCH",
            f"/event-product-plans/{pid}",
            422,
            {"selling_price": None, "currency": None},
        )["code"]
        == "PRICE_REQUIRED"
    )
    assert request(api, "GET", f"/events/{eid}")["summary"]["ready_product_count"] == 1
    assert (
        request(api, "GET", f"/event-product-plans/{pid}")["progress"]["demand"]
        == "MISSING"
    )
    request(api, "GET", f"/events/{eid}/product-plans")
    task = request(
        api,
        "POST",
        f"/events/{eid}/tasks",
        201,
        {
            "title": "print",
            "task_type": "PRODUCTION",
            "event_product_plan_id": pid,
            "due_at": "2020-01-01T10:00:00+08:00",
        },
    )
    tid = task["task_id"]
    assert task["display_status"] == "OVERDUE" and task["due_at"].startswith(
        "2020-01-01T02:00:00"
    )
    assert (
        request(
            api,
            "POST",
            f"/events/{other['event_id']}/tasks",
            422,
            {"title": "wrong", "task_type": "OTHER", "event_product_plan_id": pid},
        )["code"]
        == "TASK_EVENT_MISMATCH"
    )
    request(api, "PATCH", f"/tasks/{tid}", 422, {"status": "OVERDUE"})
    assert (
        request(api, "PATCH", f"/tasks/{tid}", body={"status": "CANCELLED"})[
            "display_status"
        ]
        == "CANCELLED"
    )
    request(api, "PATCH", f"/tasks/{tid}", body={"status": "TODO"})
    assert (
        request(api, "PATCH", f"/tasks/{tid}", body={"status": "DONE"})["completed_at"]
        is not None
    )
    assert (
        request(api, "PATCH", f"/tasks/{tid}", body={"status": "IN_PROGRESS"})[
            "completed_at"
        ]
        is None
    )
    assert (
        request(api, "GET", f"/event-product-plans/{pid}/tasks")["items"][0][
            "product_name"
        ]
        == p["name"]
    )
    request(api, "GET", f"/events/{eid}/tasks?status=IN_PROGRESS&task_type=PRODUCTION")
    dash = request(api, "GET", "/dashboard")
    assert (
        dash["next_event"]
        and dash["upcoming_tasks"]
        and dash["recent_products"]
        and dash["attention_items"]
    )
    request(api, "GET", "/events?upcoming=true&status=PLANNING")
    request(api, "DELETE", f"/tasks/{tid}", 204)
    request(api, "DELETE", f"/event-product-plans/{pid}", 204)
    request(api, "DELETE", f"/events/{eid}", 204)


def test_production_sample_and_vendor_rules(api):
    p = product(api)
    pid = p["product_id"]
    vendor = request(api, "POST", "/vendors", 201, {"name": "factory"})
    vid = vendor["vendor_id"]
    batch = request(
        api,
        "POST",
        f"/products/{pid}/production-batches",
        201,
        {"ordered_quantity": 100},
    )
    bid = batch["batch_id"]
    request(api, "PATCH", f"/production-batches/{bid}", 422, {"status": "ORDERED"})
    sample = request(
        api,
        "POST",
        f"/production-batches/{bid}/sample-rounds",
        201,
        {"round_number": 1, "sample_cost": "0.00", "currency": "CNY"},
    )
    sid = sample["sample_id"]
    request(
        api,
        "POST",
        f"/production-batches/{bid}/sample-rounds",
        409,
        {"round_number": 1},
    )
    request(api, "DELETE", f"/production-batches/{bid}", 409)
    request(api, "PATCH", f"/sample-rounds/{sid}", body={"status": "APPROVED"})
    assert request(api, "GET", f"/production-batches/{bid}")["status"] == "PLANNED"
    request(api, "GET", f"/production-batches/{bid}/sample-rounds")
    request(api, "DELETE", f"/sample-rounds/{sid}", 204)
    request(
        api,
        "PATCH",
        f"/production-batches/{bid}",
        body={
            "status": "ORDERED",
            "vendor_id": vid,
            "unit_cost": "1.50",
            "currency": "CNY",
            "ordered_at": utcnow().isoformat(),
        },
    )
    request(api, "PATCH", f"/production-batches/{bid}", body={"status": "SHIPPED"})
    assert (
        request(api, "GET", f"/products/{pid}")["inventory_summary"]["current_stock"]
        == 0
    )
    request(
        api,
        "PATCH",
        f"/production-batches/{bid}",
        body={
            "status": "RECEIVED",
            "received_quantity": 98,
            "received_at": utcnow().isoformat(),
        },
    )
    assert (
        request(api, "GET", f"/products/{pid}")["inventory_summary"]["current_stock"]
        == 98
    )
    request(api, "PATCH", f"/production-batches/{bid}", 409, {"status": "CANCELLED"})
    request(api, "GET", f"/products/{pid}/production-batches")
    request(api, "DELETE", f"/vendors/{vid}", 409)
    request(api, "PATCH", f"/vendors/{vid}", body={"status": "ARCHIVED"})
    request(api, "GET", f"/vendors/{vid}")
    request(api, "GET", "/vendors?status=ARCHIVED")
    spare = request(
        api, "POST", f"/products/{pid}/production-batches", 201, {"ordered_quantity": 1}
    )
    request(api, "DELETE", f"/production-batches/{spare['batch_id']}", 204)
    sparevendor = request(api, "POST", "/vendors", 201, {"name": "unused"})
    request(api, "DELETE", f"/vendors/{sparevendor['vendor_id']}", 204)


def test_real_listing_snapshot_and_duplicate(api, db):
    day = business_today() + timedelta(days=40)
    listing = m.EventListing(
        name="真实来源测试数据",
        location="上海场馆",
        city="上海",
        start_date=day,
        end_date=day,
        registration_status="OPEN",
        source_name="test fixture",
    )
    db.add(listing)
    db.flush()
    db.add(m.EventListingTag(event_listing_id=listing.event_listing_id, tag="TestIP"))
    db.flush()
    ident = listing.event_listing_id
    assert request(api, "GET", "/event-listings?city=上海")["total"] == 1
    assert request(api, "GET", f"/event-listings/{ident}")["tags"] == ["TestIP"]
    assert (
        request(
            api,
            "POST",
            "/event-recommendations",
            body={"ip": " testip ", "preferred_cities": ["上海"]},
        )["recommendations"][0]["event_listing"]["event_listing_id"]
        == ident
    )
    assert (
        request(api, "POST", "/event-recommendations", body={"ip": "different"})[
            "recommendations"
        ]
        == []
    )
    e = request(api, "POST", f"/event-listings/{ident}/add-to-plan", 201)
    duplicate = request(api, "POST", f"/event-listings/{ident}/add-to-plan", 409)
    assert duplicate["details"]["existing_event_id"] == e["event_id"]
    listing.name = "changed"
    db.flush()
    assert request(api, "GET", f"/events/{e['event_id']}")["name"] == "真实来源测试数据"
    request(api, "PATCH", f"/events/{e['event_id']}", body={"status": "CANCELLED"})
    request(api, "POST", f"/event-listings/{ident}/add-to-plan", 201)

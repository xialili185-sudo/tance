import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine, text
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session
from app.config import get_settings
from app.db.session import get_db
from app.main import app


def test_liveness_and_local_cors():
    with TestClient(app) as client:
        response = client.get(
            "/api/health", headers={"Origin": "http://localhost:5173"}
        )
        assert response.status_code == 200
        assert response.json()["status"] == "ok"
        assert (
            response.headers["access-control-allow-origin"] == "http://localhost:5173"
        )


def test_unavailable_database_is_503_without_credentials():
    class UnavailableDB:
        def execute(self, _statement):
            raise OperationalError(
                "SELECT 1", {}, Exception("internal password should not leak")
            )

    app.dependency_overrides[get_db] = lambda: UnavailableDB()
    try:
        with TestClient(app) as client:
            response = client.get("/api/health/ready")
            assert response.status_code == 503
            assert "internal password" not in response.text
    finally:
        app.dependency_overrides.clear()


@pytest.mark.integration
def test_mysql_test_database_and_api_readiness():
    settings = get_settings()
    assert settings.test_database_name.endswith("_test")
    assert settings.test_database_name != settings.database_name
    engine = create_engine(
        settings.database_url(test=True), connect_args={"connect_timeout": 3}
    )

    def test_db():
        with Session(engine) as session:
            yield session

    app.dependency_overrides[get_db] = test_db
    try:
        with engine.connect() as connection:
            assert (
                connection.execute(text("SELECT DATABASE()")).scalar_one()
                == settings.test_database_name
            )
            connection.execute(
                text(
                    "CREATE TEMPORARY TABLE tance_environment_probe (label VARCHAR(80)) CHARACTER SET utf8mb4"
                )
            )
            connection.execute(
                text("INSERT INTO tance_environment_probe VALUES (:label)"),
                {"label": "摊策 🎨"},
            )
            assert (
                connection.execute(
                    text("SELECT label FROM tance_environment_probe")
                ).scalar_one()
                == "摊策 🎨"
            )
        with TestClient(app) as client:
            response = client.get("/api/health/ready")
            assert response.status_code == 200
            assert response.json()["database"] == "connected"
    finally:
        app.dependency_overrides.clear()
        engine.dispose()

from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from threading import Barrier
from types import SimpleNamespace

import pytest
from sqlalchemy import select, delete
from sqlalchemy.orm import Session

from app import models as m
from app.core.errors import BusinessError
from app.db.types import utcnow
from app.services.inventory import InventoryService
from app.services.recommendations import RecommendationService, quantity_options
from app.services.sales import SalesService
from app.schemas.resources import InventoryAllocationUpsert, SalesRecordCreate
from app.ai.recommendation_explainer import RecommendationExplainer
from test_v1 import request, product, event, plan, received


def test_zero_evidence_stock_deduction_and_resale_confidence(api):
    p = product(api)
    eid = event(api, start_date="2020-01-01", end_date="2020-01-01")["event_id"]
    previous = plan(api, eid, p["product_id"])["event_product_plan_id"]
    received(api, p["product_id"], 100)
    request(
        api,
        "PUT",
        f"/event-product-plans/{previous}/inventory-allocation",
        body={"allocated_quantity": 50},
    )
    request(
        api,
        "POST",
        f"/event-product-plans/{previous}/sales-records",
        201,
        {"sale_date": "2020-01-01", "sold_quantity": 50},
    )
    current = plan(api, event(api)["event_id"], p["product_id"])[
        "event_product_plan_id"
    ]
    base = f"/event-product-plans/{current}"
    readiness = request(api, "GET", base + "/demand-readiness")
    assert (
        readiness["is_resale"]
        and readiness["sale_round"] == 2
        and readiness["level"] == "LOW"
    )
    decision = request(api, "POST", base + "/recommendations", 201)
    assert decision["current_stock_snapshot"] == 50
    assert decision["demand"]["balanced"] == 40
    assert decision["production"]["balanced"] == 0
    assert any(x["code"] == "NEW_SURVEY_RECOMMENDED" for x in decision["warnings"])
    freshp = product(api)
    freshplan = plan(api, event(api)["event_id"], freshp["product_id"])[
        "event_product_plan_id"
    ]
    base = f"/event-product-plans/{freshplan}"
    request(
        api,
        "POST",
        base + "/demand-signals",
        201,
        {
            "signal_type": "MANUAL_ESTIMATE",
            "value": 0,
            "observed_at": utcnow().isoformat(),
        },
    )
    zero = request(api, "POST", base + "/recommendations", 201)
    assert set(zero["demand"].values()) == {0} and set(zero["production"].values()) == {
        0
    }


@pytest.mark.parametrize(
    "result",
    [
        "timeout",
        {"recommendation_reason": "解释", "quantity": 999},
        {},
        {"recommendation_reason": "  "},
    ],
)
def test_llm_failure_preserves_numeric_decision(api, db, result):
    pid = plan(api, event(api)["event_id"], product(api)["product_id"])[
        "event_product_plan_id"
    ]
    request(
        api,
        "POST",
        f"/event-product-plans/{pid}/demand-signals",
        201,
        {
            "signal_type": "MANUAL_ESTIMATE",
            "value": 100,
            "observed_at": utcnow().isoformat(),
        },
    )

    class Client:
        def explain(self, context, *, timeout_seconds):
            assert timeout_seconds == 10
            context["demand"][
                "balanced"
            ] = 999  # Client cannot mutate the numeric source.
            if result == "timeout":
                raise TimeoutError()
            return result

    decision = RecommendationService(
        db, RecommendationExplainer(Client())
    ).generate_recommendation(pid)
    assert decision["demand"]["balanced"] == 100
    assert decision["recommendation_reason"] is None
    assert (
        RecommendationService(db).get_decision(decision["decision_id"])["production"][
            "balanced"
        ]
        == 100
    )


def test_valid_explanation_is_text_only(api, db):
    pid = plan(api, event(api)["event_id"], product(api)["product_id"])[
        "event_product_plan_id"
    ]
    request(
        api,
        "POST",
        f"/event-product-plans/{pid}/demand-signals",
        201,
        {
            "signal_type": "MANUAL_ESTIMATE",
            "value": 12,
            "observed_at": utcnow().isoformat(),
        },
    )

    class Client:
        def explain(self, context, *, timeout_seconds):
            return {"recommendation_reason": "仅根据手工估计生成，仍需校准。"}

    value = RecommendationService(
        db, RecommendationExplainer(Client())
    ).generate_recommendation(pid)
    assert (
        value["explanation_status"] == "AVAILABLE" and value["demand"]["balanced"] == 12
    )


def test_old_preorder_remains_lower_bound_and_sources_do_not_add():
    now = utcnow()
    old = now - timedelta(days=45)
    signal = lambda n, t: SimpleNamespace(value=n, observed_at=t)
    result = quantity_options(
        {
            "PREORDER_COUNT": signal(100, old),
            "WISHLIST_COUNT": signal(1000, now),
            "EVENT_INTEREST_SURVEY": signal(100, now),
        },
        None,
        now,
    )
    assert result == {"conservative": 100, "balanced": 100, "aggressive": 120}


@pytest.mark.parametrize(
    "model,old,new",
    [
        (m.EventPlan, "COMPLETED", "PREPARING"),
        (m.EventPlan, "PLANNING", "COMPLETED"),
        (m.EventProductPlan, "CANCELLED", "PLANNING"),
        (m.EventProductPlan, "SELLING", "CANCELLED"),
        (m.ProductionBatch, "RECEIVED", "CANCELLED"),
        (m.ProductionBatch, "RECEIVED", "ORDERED"),
        (m.ProductionBatch, "CANCELLED", "PLANNED"),
        (m.SampleRound, "APPROVED", "REJECTED"),
        (m.Task, "CANCELLED", "DONE"),
    ],
)
def test_disallowed_transitions(model, old, new):
    from app.services.states import transition

    with pytest.raises(BusinessError, match="Invalid state transition"):
        transition(model(status=old), {"status": new})


@pytest.fixture
def committed_stock(mysql_engine):
    """Own only these rows; commit for genuine independent-connection race tests."""
    with Session(mysql_engine) as s:
        p = m.Product(name="concurrency fixture", product_type="OTHER")
        v = m.Vendor(name="concurrency fixture")
        e1 = m.EventPlan(
            name="race1",
            location="test",
            start_date=utcnow().date(),
            end_date=utcnow().date(),
        )
        e2 = m.EventPlan(
            name="race2",
            location="test",
            start_date=utcnow().date(),
            end_date=utcnow().date(),
        )
        s.add_all([p, v, e1, e2])
        s.flush()
        plans = [
            m.EventProductPlan(event_id=e.event_id, product_id=p.product_id)
            for e in [e1, e2]
        ]
        s.add_all(plans)
        s.add(
            m.ProductionBatch(
                product_id=p.product_id,
                vendor_id=v.vendor_id,
                ordered_quantity=100,
                received_quantity=100,
                unit_cost=1,
                currency="CNY",
                status="RECEIVED",
                ordered_at=utcnow(),
                received_at=utcnow(),
            )
        )
        s.flush()
        ids = (
            p.product_id,
            v.vendor_id,
            [e1.event_id, e2.event_id],
            [x.event_product_plan_id for x in plans],
        )
        s.commit()
    try:
        yield ids
    finally:
        pid, vid, events, plans = ids
        with Session(mysql_engine) as s:
            for cls in [m.SalesRecord, m.InventoryAllocation]:
                s.execute(delete(cls).where(cls.event_product_plan_id.in_(plans)))
            s.execute(
                delete(m.EventProductPlan).where(
                    m.EventProductPlan.event_product_plan_id.in_(plans)
                )
            )
            s.execute(
                delete(m.ProductionBatch).where(m.ProductionBatch.product_id == pid)
            )
            s.execute(delete(m.EventPlan).where(m.EventPlan.event_id.in_(events)))
            s.execute(delete(m.Product).where(m.Product.product_id == pid))
            s.execute(delete(m.Vendor).where(m.Vendor.vendor_id == vid))
            s.commit()


def test_concurrent_allocations_do_not_oversubscribe(mysql_engine, committed_stock):
    _, _, _, plans = committed_stock
    barrier = Barrier(2)

    def run(pid):
        with Session(mysql_engine, autoflush=False, expire_on_commit=False) as s:
            barrier.wait(timeout=5)
            try:
                InventoryService(s).upsert_allocation(
                    pid, InventoryAllocationUpsert(allocated_quantity=70)
                )
                return "ok"
            except BusinessError as e:
                return e.code

    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(run, plans))
    assert sorted(results) == ["ALLOCATION_EXCEEDS_AVAILABLE_STOCK", "ok"]


def test_concurrent_sales_do_not_exceed_allocation(mysql_engine, committed_stock):
    _, _, _, plans = committed_stock
    pid = plans[0]
    with Session(mysql_engine, autoflush=False) as s:
        InventoryService(s).upsert_allocation(
            pid, InventoryAllocationUpsert(allocated_quantity=100)
        )
    barrier = Barrier(2)

    def run(day):
        with Session(mysql_engine, autoflush=False, expire_on_commit=False) as s:
            barrier.wait(timeout=5)
            try:
                SalesService(s).create_sales_record(
                    pid, SalesRecordCreate(sale_date=day, sold_quantity=70)
                )
                return "ok"
            except BusinessError as e:
                return e.code

    today = utcnow().date()
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(run, [today, today + timedelta(days=1)]))
    assert sorted(results) == ["SALES_EXCEED_ALLOCATION", "ok"]


def test_migration_metadata_and_datetime_precision(mysql_engine):
    from alembic.autogenerate import compare_metadata
    from alembic.migration import MigrationContext
    from app.db.base import Base
    from sqlalchemy import inspect

    with mysql_engine.connect() as connection:
        context = MigrationContext.configure(connection, opts={"compare_type": True})
        assert compare_metadata(context, Base.metadata) == []
    observed = next(
        x
        for x in inspect(mysql_engine).get_columns("demand_signals")
        if x["name"] == "observed_at"
    )
    assert observed["type"].fsp == 6


def test_nullable_price_pair_zero_allocation_and_bad_timestamps(api):
    p = product(api, default_selling_price="12.00", default_currency="CNY")
    e = event(api)
    pid = plan(api, e["event_id"], p["product_id"], selling_price=None, currency=None)[
        "event_product_plan_id"
    ]
    detail = request(api, "GET", f"/event-product-plans/{pid}")
    assert detail["selling_price"] is None and detail["currency"] is None
    request(
        api,
        "PATCH",
        f"/products/{p['product_id']}",
        body={"default_selling_price": "20.00"},
    )
    assert request(api, "GET", f"/event-product-plans/{pid}")["selling_price"] is None
    state = request(api, "GET", f"/event-product-plans/{pid}/inventory-allocation")
    assert state["current_stock"] == state["allocated_quantity"] == 0
    assert (
        request(
            api,
            "POST",
            f"/event-product-plans/{pid}/sales-records",
            409,
            {"sale_date": "2026-09-21", "sold_quantity": 0},
        )["code"]
        == "INVENTORY_NOT_ALLOCATED"
    )
    request(
        api,
        "PUT",
        f"/event-product-plans/{pid}/inventory-allocation",
        body={"allocated_quantity": 0},
    )
    request(
        api,
        "POST",
        f"/event-product-plans/{pid}/sales-records",
        201,
        {"sale_date": "2026-09-21", "sold_quantity": 0},
    )
    assert (
        request(api, "GET", f"/event-product-plans/{pid}/sales-summary")[
            "sell_through_rate"
        ]
        is None
    )
    for bad in [123, True, "2026-09-21T00:00:00"]:
        response = request(
            api,
            "POST",
            f"/event-product-plans/{pid}/demand-signals",
            422,
            {"signal_type": "MANUAL_ESTIMATE", "value": 1, "observed_at": bad},
        )
        assert response["code"] == "VALIDATION_ERROR"
    request(
        api,
        "POST",
        f"/event-product-plans/{pid}/sales-records",
        422,
        {"sale_date": 123, "sold_quantity": 0},
    )

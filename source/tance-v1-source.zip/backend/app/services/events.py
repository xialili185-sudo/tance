from sqlalchemy import select
from app import models as m
from app.core.errors import BusinessError
from app.core.policy import business_today
from app.services.common import Service, atomic, envelope, event_dates
from app.services.states import transition, TERMINAL
from app.services.event_products import EventProductService
from app.services.inventory import InventoryService
from app.services.tasks import TaskService


class EventService(Service):
    @atomic
    def create_event(self, data):
        obj = m.EventPlan(**data.model_dump())
        event_dates(obj)
        return self.save(obj)

    def list_events(self, status=None, upcoming=None):
        q = select(m.EventPlan).order_by(m.EventPlan.start_date, m.EventPlan.event_id)
        if status is not None:
            q = q.where(m.EventPlan.status == status)
        result = []
        for obj in self.db.scalars(q):
            future = obj.end_date >= business_today() and obj.status not in TERMINAL
            if upcoming is not None and future != upcoming:
                continue
            result.append(
                {
                    **self.dump(
                        obj,
                        [
                            "event_id",
                            "name",
                            "location",
                            "start_date",
                            "end_date",
                            "status",
                        ],
                    ),
                    "product_count": self.count(
                        m.EventProductPlan, m.EventProductPlan.event_id == obj.event_id
                    ),
                }
            )
        return envelope(result, True)

    def attention(self, event_id):
        event = self.get(m.EventPlan, event_id)
        if event.status in TERMINAL:
            return []
        items = []
        plans = EventProductService(self.db)
        for plan in self.db.scalars(
            select(m.EventProductPlan)
            .where(m.EventProductPlan.event_id == event_id)
            .order_by(m.EventProductPlan.event_product_plan_id)
        ):
            name = self.get(m.Product, plan.product_id).name
            items.extend(
                {
                    **x,
                    "event_id": event_id,
                    "event_product_plan_id": plan.event_product_plan_id,
                    "product_name": name,
                }
                for x in plans.get_attention_items(plan.event_product_plan_id)
            )
        for task in self.db.scalars(
            select(m.Task)
            .where(m.Task.event_id == event_id, m.Task.event_product_plan_id.is_(None))
            .order_by(m.Task.task_id)
        ):
            if TaskService.get_display_status(task) == "OVERDUE":
                items.append(
                    {
                        "type": "TASK_OVERDUE",
                        "severity": "WARNING",
                        "message": f"任务已逾期：{task.title}（{task.task_id}）",
                        "event_id": event_id,
                        "event_product_plan_id": None,
                        "product_name": None,
                    }
                )
        return items

    def get_event(self, event_id):
        obj = self.get(m.EventPlan, event_id)
        summary = {
            "product_count": 0,
            "ready_product_count": 0,
            "demand_checked_count": 0,
            "production_ready_count": 0,
        }
        service = EventProductService(self.db)
        for plan in self.db.scalars(
            select(m.EventProductPlan).where(m.EventProductPlan.event_id == event_id)
        ):
            summary["product_count"] += 1
            summary["ready_product_count"] += plan.status in {"READY", "SELLING"}
            summary["demand_checked_count"] += (
                service.get_progress(plan.event_product_plan_id)["demand"] == "READY"
            )
            allocation = InventoryService(self.db).allocation(
                plan.event_product_plan_id
            )
            summary["production_ready_count"] += bool(
                allocation and allocation.allocated_quantity > 0
            )
        fields = [
            "event_id",
            "name",
            "location",
            "start_date",
            "end_date",
            "application_deadline",
            "status",
            "notes",
            "created_at",
            "updated_at",
        ]
        return {
            **self.dump(obj, fields),
            "summary": summary,
            "attention_count": len(self.attention(event_id)),
        }

    @atomic
    def update_event(self, event_id, data):
        obj = self.get(m.EventPlan, event_id, lock=True)
        product_ids = sorted(
            set(
                self.db.scalars(
                    select(m.EventProductPlan.product_id).where(
                        m.EventProductPlan.event_id == event_id
                    )
                )
            )
        )
        for ident in product_ids:
            self.get(m.Product, ident, lock=True)
        values = data.model_dump(exclude_unset=True)
        transition(obj, values)
        self.changes(obj, values)
        event_dates(obj)
        self.db.flush()
        for ident in product_ids:
            InventoryService(self.db).validate_stock(ident)
        return self.dump(obj)

    @atomic
    def delete_event(self, event_id):
        obj = self.get(m.EventPlan, event_id, lock=True)
        if self.count(
            m.EventProductPlan, m.EventProductPlan.event_id == event_id
        ) or self.count(m.Task, m.Task.event_id == event_id):
            raise BusinessError("EVENT_HAS_DEPENDENCIES", 409)
        self.db.delete(obj)

from decimal import Decimal, ROUND_FLOOR, ROUND_CEILING
from datetime import timedelta
from sqlalchemy import select
from app import models as m
from app.core.errors import BusinessError
from app.core.policy import RULES
from app.db.types import utcnow
from app.services.common import Service, atomic, envelope
from app.services.demand import DemandService
from app.services.products import ProductService
from app.ai.recommendation_explainer import RecommendationExplainer


def quantity_options(signals, previous_sales, now, rules=RULES):
    weights = {
        "EVENT_INTEREST_SURVEY": rules.survey,
        "PREORDER_COUNT": rules.preorder,
        "MANUAL_ESTIMATE": rules.manual,
        "SOCIAL_ENGAGEMENT": rules.social,
        "WISHLIST_COUNT": rules.wishlist,
        "EXTERNAL_HISTORY": rules.history,
    }
    candidates = []
    for kind, signal in signals.items():
        value = Decimal(signal.value) * weights[kind]
        if kind in {
            "EVENT_INTEREST_SURVEY",
            "PREORDER_COUNT",
            "SOCIAL_ENGAGEMENT",
        } and now - signal.observed_at > timedelta(days=rules.fresh_days):
            value *= rules.stale_multiplier
        candidates.append(value)
    if previous_sales is not None:
        candidates.append(Decimal(previous_sales) * rules.history)
    if not candidates:
        raise BusinessError("INSUFFICIENT_DEMAND_DATA")
    base = int(max(candidates).to_integral_value(rounding=ROUND_CEILING))
    preorder = signals["PREORDER_COUNT"].value if "PREORDER_COUNT" in signals else 0
    result = {
        "conservative": max(
            preorder,
            int(
                (Decimal(base) * rules.conservative).to_integral_value(
                    rounding=ROUND_FLOOR
                )
            ),
        ),
        "balanced": max(preorder, base),
        "aggressive": max(
            preorder,
            int(
                (Decimal(base) * rules.aggressive).to_integral_value(
                    rounding=ROUND_CEILING
                )
            ),
        ),
    }
    if result["aggressive"] > 9223372036854775807:
        raise BusinessError(
            "VALIDATION_ERROR", message="Recommended quantity exceeds supported range"
        )
    return result


class RecommendationService(Service):
    def __init__(self, db, explainer=None):
        super().__init__(db)
        self.explainer = explainer or RecommendationExplainer()

    @atomic
    def generate_recommendation(self, plan_id):
        demand = DemandService(self.db)
        now, plan, lifecycle, signals = demand.context(plan_id)
        readiness = demand.get_readiness(plan_id, now)
        quantities = quantity_options(signals, lifecycle["previous_event_sales"], now)
        stock = ProductService(self.db).get_current_stock(plan.product_id)
        production = {k: max(v - stock, 0) for k, v in quantities.items()}
        strategy = "CONSERVATIVE" if readiness["level"] == "LOW" else "BALANCED"
        values = {
            "event_product_plan_id": plan_id,
            "current_stock_snapshot": stock,
            "recommended_strategy": strategy,
            "recommended_demand": quantities[strategy.lower()],
            "recommended_production": production[strategy.lower()],
            "confidence_level": readiness["level"],
            "warnings": readiness["warnings"],
        }
        values.update({"demand_" + k: v for k, v in quantities.items()})
        values.update({"production_" + k: v for k, v in production.items()})
        # End the read transaction before optional network I/O; no inventory lock is held.
        self.db.rollback()
        reason = self.explainer.explain(
            {
                "demand": quantities,
                "production": production,
                "current_stock": stock,
                "confidence": readiness["level"],
                "warnings": readiness["warnings"],
            }
        )
        self.get(m.EventProductPlan, plan_id, lock=True)
        obj = m.QuantityDecision(**values, recommendation_reason=reason, created_at=now)
        self.db.add(obj)
        self.db.flush()
        return self.decision_response(obj)

    def decision_response(self, obj):
        return {
            "decision_id": obj.decision_id,
            "event_product_plan_id": obj.event_product_plan_id,
            "created_at": obj.created_at,
            "current_stock_snapshot": obj.current_stock_snapshot,
            "confidence_level": obj.confidence_level,
            "recommended_strategy": obj.recommended_strategy,
            "demand": {
                **{
                    k: getattr(obj, "demand_" + k)
                    for k in ["conservative", "balanced", "aggressive"]
                },
                "recommended": obj.recommended_demand,
            },
            "production": {
                **{
                    k: getattr(obj, "production_" + k)
                    for k in ["conservative", "balanced", "aggressive"]
                },
                "recommended": obj.recommended_production,
            },
            "warnings": obj.warnings,
            "recommendation_reason": obj.recommendation_reason,
            "explanation_status": (
                "AVAILABLE" if obj.recommendation_reason else "UNAVAILABLE"
            ),
            "final_production_quantity": obj.final_production_quantity,
            "confirmed_at": obj.confirmed_at,
        }

    def get_decision(self, decision_id):
        return self.decision_response(self.get(m.QuantityDecision, decision_id))

    def get_recommendation_history(self, plan_id):
        self.get(m.EventProductPlan, plan_id)
        q = (
            select(m.QuantityDecision)
            .where(m.QuantityDecision.event_product_plan_id == plan_id)
            .order_by(
                m.QuantityDecision.created_at.desc(),
                m.QuantityDecision.decision_id.desc(),
            )
        )
        fields = [
            "decision_id",
            "created_at",
            "recommended_strategy",
            "recommended_demand",
            "recommended_production",
            "final_production_quantity",
            "confidence_level",
        ]
        return envelope([self.dump(x, fields) for x in self.db.scalars(q)])

    @atomic
    def confirm_final_quantity(self, decision_id, data):
        obj = self.get(m.QuantityDecision, decision_id, lock=True)
        self.changes(obj, data)
        obj.confirmed_at = utcnow()
        self.db.flush()
        return self.dump(
            obj,
            [
                "decision_id",
                "recommended_production",
                "final_production_quantity",
                "confirmed_at",
            ],
        )

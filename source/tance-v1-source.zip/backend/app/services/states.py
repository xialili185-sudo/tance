"""Approved SC-04 transitions. Same-state writes still validate final fields."""

from app.core.errors import BusinessError

TRANSITIONS = {
    "EventPlan": {
        "PLANNING": "PREPARING CANCELLED",
        "PREPARING": "PLANNING READY CANCELLED",
        "READY": "PREPARING COMPLETED CANCELLED",
    },
    "EventProductPlan": {
        "PLANNING": "PREPARING CANCELLED",
        "PREPARING": "PLANNING READY CANCELLED",
        "READY": "PREPARING SELLING CANCELLED",
        "SELLING": "COMPLETED",
    },
    "ProductionBatch": {
        "PLANNED": "SAMPLING ORDERED CANCELLED",
        "SAMPLING": "PLANNED ORDERED CANCELLED",
        "ORDERED": "PRODUCING SHIPPED RECEIVED CANCELLED",
        "PRODUCING": "SHIPPED RECEIVED CANCELLED",
        "SHIPPED": "RECEIVED CANCELLED",
    },
    "SampleRound": {
        "PENDING": "APPROVED REVISION_REQUIRED REJECTED",
        "APPROVED": "PENDING",
        "REVISION_REQUIRED": "PENDING",
        "REJECTED": "PENDING",
    },
    "Task": {
        "TODO": "IN_PROGRESS DONE CANCELLED",
        "IN_PROGRESS": "TODO DONE CANCELLED",
        "DONE": "TODO IN_PROGRESS",
        "CANCELLED": "TODO",
    },
}
ASSETS = {"ACTIVE": "ARCHIVED", "ARCHIVED": "ACTIVE"}
TERMINAL = {"COMPLETED", "CANCELLED"}


def transition(obj, values):
    target = values.get("status", obj.status)
    if target == obj.status:
        return
    table = TRANSITIONS.get(type(obj).__name__, ASSETS)
    if target not in table.get(obj.status, "").split():
        raise BusinessError(
            "INVALID_STATE_TRANSITION", 409, details={"from": obj.status, "to": target}
        )

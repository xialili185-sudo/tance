from sqlalchemy import select
from app import models as m
from app.core.errors import BusinessError
from app.services.common import Service, atomic, envelope
from app.services.states import transition


class ContentService(Service):
    @atomic
    def create_content(self, data):
        return self.save(m.Content(**data.model_dump()))

    def uses(self, content_id):
        return self.count(m.ProductContent, m.ProductContent.content_id == content_id)

    def list_contents(self, status=None, content_type=None):
        q = select(m.Content).order_by(m.Content.content_id)
        if status is not None:
            q = q.where(m.Content.status == status)
        if content_type is not None:
            q = q.where(m.Content.content_type == content_type)
        return envelope(
            [
                {
                    **self.dump(
                        x,
                        [
                            "content_id",
                            "title",
                            "content_type",
                            "thumbnail_url",
                            "status",
                        ],
                    ),
                    "used_in_product_count": self.uses(x.content_id),
                }
                for x in self.db.scalars(q)
            ],
            True,
        )

    def get_content(self, content_id):
        return {
            **self.dump(self.get(m.Content, content_id)),
            "used_in_product_count": self.uses(content_id),
        }

    @atomic
    def update_content(self, content_id, data):
        obj = self.get(m.Content, content_id, lock=True)
        values = data.model_dump(exclude_unset=True)
        transition(obj, values)
        self.changes(obj, values)
        return self.save(obj)

    @atomic
    def delete_content(self, content_id):
        obj = self.get(m.Content, content_id, lock=True)
        if self.uses(content_id):
            raise BusinessError("CONTENT_IN_USE", 409)
        self.db.delete(obj)

    def get_content_products(self, content_id):
        self.get(m.Content, content_id)
        q = (
            select(m.Product)
            .join(m.ProductContent)
            .where(m.ProductContent.content_id == content_id)
            .order_by(m.Product.product_id)
        )
        return envelope(
            [
                self.dump(x, ["product_id", "name", "product_type"])
                for x in self.db.scalars(q)
            ]
        )

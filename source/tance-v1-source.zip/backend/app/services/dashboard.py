from sqlalchemy import select
from app import models as m
from app.core.policy import business_today
from app.services.common import Service
from app.services.states import TERMINAL
from app.services.events import EventService
from app.services.products import ProductService


class DashboardService(Service):
    def get_dashboard(self):
        events = list(
            self.db.scalars(
                select(m.EventPlan)
                .where(m.EventPlan.status.not_in(TERMINAL))
                .order_by(m.EventPlan.start_date, m.EventPlan.event_id)
            )
        )
        next_event = next((x for x in events if x.end_date >= business_today()), None)
        tasks = self.db.scalars(
            select(m.Task)
            .join(m.EventPlan)
            .where(
                m.EventPlan.status.not_in(TERMINAL),
                m.Task.status.in_(["TODO", "IN_PROGRESS"]),
                m.Task.due_at.is_not(None),
            )
            .order_by(m.Task.due_at, m.Task.task_id)
            .limit(10)
        )
        products = self.db.scalars(
            select(m.Product)
            .order_by(m.Product.created_at.desc(), m.Product.product_id.desc())
            .limit(5)
        )
        return {
            "next_event": (
                {
                    **self.dump(
                        next_event, ["event_id", "name", "start_date", "status"]
                    ),
                    "days_remaining": (next_event.start_date - business_today()).days,
                }
                if next_event
                else None
            ),
            "attention_items": [
                item
                for e in events
                for item in EventService(self.db).attention(e.event_id)
            ],
            "upcoming_tasks": [
                self.dump(x, ["task_id", "title", "due_at"]) for x in tasks
            ],
            "production_summary": {
                key: self.count(
                    m.ProductionBatch, m.ProductionBatch.status == key.upper()
                )
                for key in ["sampling", "producing", "shipped"]
            },
            "recent_products": [ProductService(self.db).summary(x) for x in products],
        }

"""Shared transaction, existence and serialization helpers; no business storage layer."""

from functools import wraps
from decimal import Decimal

from sqlalchemy import select, func, inspect
from sqlalchemy.exc import IntegrityError

from app import models as m
from app.core.errors import BusinessError

NOT_FOUND = {
    m.EventPlan: "EVENT",
    m.EventListing: "EVENT_LISTING",
    m.Product: "PRODUCT",
    m.Content: "CONTENT",
    m.EventProductPlan: "PLAN",
    m.DemandSignal: "SIGNAL",
    m.QuantityDecision: "DECISION",
    m.Vendor: "VENDOR",
    m.ProductionBatch: "BATCH",
    m.SampleRound: "SAMPLE",
    m.Task: "TASK",
    m.SalesRecord: "SALES_RECORD",
}


def atomic(fn):
    @wraps(fn)
    def operation(self, *args, **kwargs):
        try:
            result = fn(self, *args, **kwargs)
            self.db.commit()
            return result
        except IntegrityError as exc:
            self.db.rollback()
            # Constraint names are inspected internally, never returned to clients.
            text = str(exc.orig)
            names = {
                "uq_event_product_plans_event_id_product_id": "PRODUCT_ALREADY_IN_EVENT",
                "uq_sample_rounds_batch_id_round_number": "SAMPLE_ROUND_ALREADY_EXISTS",
                "uq_sales_records_event_product_plan_id_sale_date": "SALES_RECORD_ALREADY_EXISTS",
            }
            code = next((v for k, v in names.items() if k in text), "STOCK_CONFLICT")
            raise BusinessError(code, 409) from None
        except Exception:
            self.db.rollback()
            raise

    return operation


class Service:
    def __init__(self, db):
        self.db = db

    def get(self, cls, ident, *, lock=False):
        pk = inspect(cls).primary_key[0]
        q = select(cls).where(pk == ident)
        if lock:
            q = q.with_for_update().execution_options(populate_existing=True)
        obj = self.db.scalar(q)
        if obj is None:
            raise BusinessError(NOT_FOUND[cls] + "_NOT_FOUND", 404)
        return obj

    def count(self, cls, *conditions):
        return self.db.scalar(select(func.count()).select_from(cls).where(*conditions))

    @staticmethod
    def dump(obj, fields=None):
        names = fields or [c.key for c in inspect(type(obj)).columns]
        return {
            k: format(v, ".2f") if isinstance(v := getattr(obj, k), Decimal) else v
            for k in names
        }

    @staticmethod
    def changes(obj, data):
        values = (
            data.model_dump(exclude_unset=True) if hasattr(data, "model_dump") else data
        )
        for key, value in values.items():
            setattr(obj, key, value)
        return obj

    def save(self, obj):
        self.db.add(obj)
        self.db.flush()
        return self.dump(obj)

    def lock_plan_stock(self, plan_id):
        plan = self.get(m.EventProductPlan, plan_id)
        self.get(m.EventPlan, plan.event_id, lock=True)
        self.get(m.Product, plan.product_id, lock=True)
        return self.get(m.EventProductPlan, plan_id, lock=True)


def money_pair(obj, amount, currency):
    if (getattr(obj, amount) is None) != (getattr(obj, currency) is None):
        raise BusinessError("INVALID_MONEY_PAIR")


def event_dates(obj):
    if obj.end_date < obj.start_date:
        raise BusinessError("INVALID_EVENT_DATE")


def envelope(items, total=False):
    return {"items": items, **({"total": len(items)} if total else {})}

from sqlalchemy import select, func
from app import models as m
from app.core.errors import BusinessError
from app.services.common import Service, atomic, envelope, money_pair
from app.services.states import transition


class ProductService(Service):
    @atomic
    def create_product(self, data):
        obj = m.Product(**data.model_dump())
        money_pair(obj, "default_selling_price", "default_currency")
        return self.save(obj)

    def inventory(self, product_id):
        self.get(m.Product, product_id)
        received = self.db.scalar(
            select(
                func.coalesce(func.sum(m.ProductionBatch.received_quantity), 0)
            ).where(
                m.ProductionBatch.product_id == product_id,
                m.ProductionBatch.status == "RECEIVED",
            )
        )
        sold = self.db.scalar(
            select(func.coalesce(func.sum(m.SalesRecord.sold_quantity), 0))
            .join(
                m.EventProductPlan,
                m.EventProductPlan.event_product_plan_id
                == m.SalesRecord.event_product_plan_id,
            )
            .where(m.EventProductPlan.product_id == product_id)
        )
        stock = int(received - sold)
        if stock < 0:
            raise BusinessError("STOCK_CONFLICT", 409)
        return {
            "total_received": int(received),
            "total_sold": int(sold),
            "current_stock": stock,
        }

    def get_current_stock(self, product_id):
        return self.inventory(product_id)["current_stock"]

    def get_sales_history(self, product_id):
        self.get(m.Product, product_id)
        q = (
            select(m.EventPlan, func.sum(m.SalesRecord.sold_quantity))
            .join(
                m.EventProductPlan, m.EventProductPlan.event_id == m.EventPlan.event_id
            )
            .join(
                m.SalesRecord,
                m.SalesRecord.event_product_plan_id
                == m.EventProductPlan.event_product_plan_id,
            )
            .where(m.EventProductPlan.product_id == product_id)
            .group_by(m.EventPlan.event_id)
            .order_by(m.EventPlan.start_date, m.EventPlan.event_id)
        )
        return {
            "product_id": product_id,
            "items": [
                {
                    "event_id": e.event_id,
                    "event_name": e.name,
                    "event_start_date": e.start_date,
                    "total_sold": int(n),
                }
                for e, n in self.db.execute(q)
            ],
        }

    def summary(self, obj):
        return {
            **self.dump(
                obj,
                [
                    "product_id",
                    "name",
                    "product_type",
                    "default_selling_price",
                    "default_currency",
                    "status",
                ],
            ),
            "current_stock": self.get_current_stock(obj.product_id),
            "event_count": self.count(
                m.EventProductPlan, m.EventProductPlan.product_id == obj.product_id
            ),
            "content_count": self.count(
                m.ProductContent, m.ProductContent.product_id == obj.product_id
            ),
        }

    def list_products(self, status=None, product_type=None):
        q = select(m.Product).order_by(m.Product.product_id)
        if status is not None:
            q = q.where(m.Product.status == status)
        if product_type is not None:
            q = q.where(m.Product.product_type == product_type)
        return envelope([self.summary(x) for x in self.db.scalars(q)], True)

    def get_product(self, product_id):
        obj = self.get(m.Product, product_id)
        history = self.get_sales_history(product_id)["items"]
        return {
            **self.dump(obj),
            "inventory_summary": self.inventory(product_id),
            "sales_summary": {
                "event_count": self.count(
                    m.EventProductPlan, m.EventProductPlan.product_id == product_id
                ),
                "latest_event_sales": history[-1]["total_sold"] if history else None,
            },
        }

    @atomic
    def update_product(self, product_id, data):
        obj = self.get(m.Product, product_id, lock=True)
        values = data.model_dump(exclude_unset=True)
        transition(obj, values)
        self.changes(obj, values)
        money_pair(obj, "default_selling_price", "default_currency")
        return self.save(obj)

    @atomic
    def delete_product(self, product_id):
        obj = self.get(m.Product, product_id, lock=True)
        if self.count(
            m.EventProductPlan, m.EventProductPlan.product_id == product_id
        ) or self.count(m.ProductionBatch, m.ProductionBatch.product_id == product_id):
            raise BusinessError("PRODUCT_HAS_DEPENDENCIES", 409)
        self.db.delete(obj)

    @atomic
    def link_content(self, product_id, content_id):
        self.get(m.Product, product_id, lock=True)
        self.get(m.Content, content_id, lock=True)
        if self.db.get(m.ProductContent, (product_id, content_id)):
            raise BusinessError("PRODUCT_CONTENT_ALREADY_LINKED", 409)
        self.db.add(m.ProductContent(product_id=product_id, content_id=content_id))

    @atomic
    def unlink_content(self, product_id, content_id):
        self.get(m.Product, product_id, lock=True)
        self.get(m.Content, content_id, lock=True)
        obj = self.db.get(m.ProductContent, (product_id, content_id))
        if obj:
            self.db.delete(obj)

    def get_product_contents(self, product_id):
        self.get(m.Product, product_id)
        q = (
            select(m.Content)
            .join(m.ProductContent)
            .where(m.ProductContent.product_id == product_id)
            .order_by(m.Content.content_id)
        )
        return envelope(
            [
                self.dump(x, ["content_id", "title", "content_type", "thumbnail_url"])
                for x in self.db.scalars(q)
            ]
        )

    def lifecycle(self, plan):
        event = self.get(m.EventPlan, plan.event_id)
        past = [
            x
            for x in self.get_sales_history(plan.product_id)["items"]
            if (x["event_start_date"], x["event_id"])
            < (event.start_date, event.event_id)
        ]
        return {
            "is_resale": bool(past),
            "sale_round": len(past) + 1,
            "previous_event_sales": past[-1]["total_sold"] if past else None,
        }

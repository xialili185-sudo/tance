from datetime import timedelta
from sqlalchemy import select
from app import models as m
from app.db.types import utcnow
from app.core.policy import RULES
from app.services.common import Service, atomic, envelope
from app.services.products import ProductService


class DemandService(Service):
    @atomic
    def add_signal(self, plan_id, data):
        self.lock_plan_stock(plan_id)
        return self.save(
            m.DemandSignal(event_product_plan_id=plan_id, **data.model_dump())
        )

    def list_signals(self, plan_id, signal_type=None):
        self.get(m.EventProductPlan, plan_id)
        q = select(m.DemandSignal).where(
            m.DemandSignal.event_product_plan_id == plan_id
        )
        if signal_type is not None:
            q = q.where(m.DemandSignal.signal_type == signal_type)
        return envelope(
            [
                self.dump(x)
                for x in self.db.scalars(
                    q.order_by(
                        m.DemandSignal.observed_at.desc(),
                        m.DemandSignal.signal_id.desc(),
                    )
                )
            ]
        )

    @atomic
    def delete_signal(self, signal_id):
        obj = self.get(m.DemandSignal, signal_id)
        self.lock_plan_stock(obj.event_product_plan_id)
        obj = self.get(m.DemandSignal, signal_id, lock=True)
        self.db.delete(obj)

    def get_latest_signals_by_type(self, plan_id, now=None):
        self.get(m.EventProductPlan, plan_id)
        q = select(m.DemandSignal).where(
            m.DemandSignal.event_product_plan_id == plan_id
        )
        if now is not None:
            q = q.where(m.DemandSignal.observed_at <= now)
        result = {}
        for obj in self.db.scalars(
            q.order_by(
                m.DemandSignal.observed_at.desc(), m.DemandSignal.signal_id.desc()
            )
        ):
            result.setdefault(obj.signal_type, obj)
        return result

    def get_latest_signal(self, plan_id, signal_type):
        return self.get_latest_signals_by_type(plan_id).get(signal_type)

    def context(self, plan_id, now=None):
        now = now or utcnow()
        plan = self.get(m.EventProductPlan, plan_id)
        lifecycle = ProductService(self.db).lifecycle(plan)
        signals = self.get_latest_signals_by_type(plan_id, now)
        return now, plan, lifecycle, signals

    def get_readiness(self, plan_id, now=None):
        now, plan, lifecycle, signals = self.context(plan_id, now)
        fresh = lambda kind: kind in signals and now - signals[
            kind
        ].observed_at <= timedelta(days=RULES.fresh_days)
        checks = {
            "historical_sales": lifecycle["previous_event_sales"] is not None,
            "current_event_survey": fresh("EVENT_INTEREST_SURVEY"),
            "wishlist": "WISHLIST_COUNT" in signals,
            "preorder": fresh("PREORDER_COUNT"),
            "recent_social_signal": fresh("SOCIAL_ENGAGEMENT"),
        }
        if checks["current_event_survey"] and checks["preorder"]:
            level = "HIGH"
        elif (
            checks["current_event_survey"]
            or "MANUAL_ESTIMATE" in signals
            or checks["historical_sales"]
        ):
            level = "MEDIUM"
        else:
            level = "LOW"
        warnings = []
        if lifecycle["is_resale"] and not checks["current_event_survey"]:
            level = {"HIGH": "MEDIUM", "MEDIUM": "LOW", "LOW": "LOW"}[level]
            warnings.append(
                {
                    "code": "NEW_SURVEY_RECOMMENDED",
                    "message": "再贩缺少新鲜的本轮印调，已降低置信度。",
                }
            )
        if "WISHLIST_COUNT" in signals:
            warnings.append(
                {
                    "code": "CUMULATIVE_WISHLIST",
                    "message": "累计心愿仅作辅助证据，不代表本轮购买承诺。",
                }
            )
        if "EXTERNAL_HISTORY" in signals:
            warnings.append(
                {
                    "code": "EXTERNAL_HISTORY_ESTIMATE",
                    "message": "系统外历史仅按手工记录估算。",
                }
            )
        if any(
            not fresh(k)
            for k in ["EVENT_INTEREST_SURVEY", "PREORDER_COUNT", "SOCIAL_ENGAGEMENT"]
            if k in signals
        ):
            warnings.append(
                {
                    "code": "STALE_SIGNALS",
                    "message": "超过30天的本轮需求信号已降低权重。",
                }
            )
        return {
            "level": level,
            "is_resale": lifecycle["is_resale"],
            "sale_round": lifecycle["sale_round"],
            "checks": checks,
            "latest_signals": {
                k: {"value": v.value, "observed_at": v.observed_at}
                for k, v in signals.items()
            },
            "warnings": warnings,
        }

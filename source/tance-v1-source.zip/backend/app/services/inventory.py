from sqlalchemy import select, func
from app import models as m
from app.core.errors import BusinessError
from app.services.common import Service, atomic
from app.services.products import ProductService
from app.services.states import TERMINAL


class InventoryService(Service):
    def sold(self, plan_id):
        return int(
            self.db.scalar(
                select(func.coalesce(func.sum(m.SalesRecord.sold_quantity), 0)).where(
                    m.SalesRecord.event_product_plan_id == plan_id
                )
            )
        )

    def allocation(self, plan_id):
        return self.db.scalar(
            select(m.InventoryAllocation).where(
                m.InventoryAllocation.event_product_plan_id == plan_id
            )
        )

    def get_reserved_stock(self, product_id, exclude_plan=None):
        q = (
            select(m.InventoryAllocation, m.EventProductPlan)
            .join(m.EventProductPlan)
            .join(m.EventPlan)
            .where(
                m.EventProductPlan.product_id == product_id,
                m.EventProductPlan.status.not_in(TERMINAL),
                m.EventPlan.status.not_in(TERMINAL),
            )
        )
        if exclude_plan is not None:
            q = q.where(m.EventProductPlan.event_product_plan_id != exclude_plan)
        return sum(
            a.allocated_quantity - self.sold(p.event_product_plan_id)
            for a, p in self.db.execute(q)
        )

    def validate_stock(self, product_id):
        self.db.flush()
        current = ProductService(self.db).get_current_stock(product_id)
        reserved = self.get_reserved_stock(product_id)
        if reserved < 0 or reserved > current:
            raise BusinessError("STOCK_CONFLICT", 409)

    def get_allocation(self, plan_id):
        plan = self.get(m.EventProductPlan, plan_id)
        current = ProductService(self.db).get_current_stock(plan.product_id)
        other = self.get_reserved_stock(plan.product_id, plan_id)
        allocation = self.allocation(plan_id)
        allocated = allocation.allocated_quantity if allocation else 0
        sold = self.sold(plan_id)
        return {
            "current_stock": current,
            "reserved_by_other_events": other,
            "max_allocatable_quantity": current - other + sold,
            "allocated_quantity": allocated,
            "event_sold_quantity": sold,
            "event_remaining_quantity": allocated - sold,
            "unallocated_available_stock": current
            - self.get_reserved_stock(plan.product_id),
        }

    @atomic
    def upsert_allocation(self, plan_id, data):
        plan = self.lock_plan_stock(plan_id)
        facts = self.get_allocation(plan_id)
        if data.allocated_quantity < facts["event_sold_quantity"]:
            raise BusinessError("ALLOCATION_BELOW_SALES")
        if data.allocated_quantity > facts["max_allocatable_quantity"]:
            raise BusinessError("ALLOCATION_EXCEEDS_AVAILABLE_STOCK")
        allocation = self.allocation(plan_id)
        if allocation is None:
            allocation = m.InventoryAllocation(event_product_plan_id=plan_id)
        self.changes(allocation, data)
        self.db.add(allocation)
        self.validate_stock(plan.product_id)
        return self.get_allocation(plan_id)

    @atomic
    def delete_allocation(self, plan_id):
        plan = self.lock_plan_stock(plan_id)
        if self.count(m.SalesRecord, m.SalesRecord.event_product_plan_id == plan_id):
            raise BusinessError("ALLOCATION_HAS_SALES", 409)
        allocation = self.allocation(plan_id)
        if allocation:
            self.db.delete(allocation)
        self.validate_stock(plan.product_id)

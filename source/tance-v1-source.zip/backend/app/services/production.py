from sqlalchemy import select
from app import models as m
from app.core.errors import BusinessError
from app.services.common import Service, atomic, envelope, money_pair
from app.services.states import transition
from app.services.inventory import InventoryService


class ProductionService(Service):
    @atomic
    def create_vendor(self, data):
        return self.save(m.Vendor(**data.model_dump()))

    def list_vendors(self, status=None):
        q = select(m.Vendor).order_by(m.Vendor.vendor_id)
        if status is not None:
            q = q.where(m.Vendor.status == status)
        return envelope([self.dump(x) for x in self.db.scalars(q)], True)

    def get_vendor(self, vendor_id):
        return self.dump(self.get(m.Vendor, vendor_id))

    @atomic
    def update_vendor(self, vendor_id, data):
        obj = self.get(m.Vendor, vendor_id, lock=True)
        values = data.model_dump(exclude_unset=True)
        transition(obj, values)
        self.changes(obj, values)
        return self.save(obj)

    @atomic
    def delete_vendor(self, vendor_id):
        obj = self.get(m.Vendor, vendor_id, lock=True)
        if self.count(m.ProductionBatch, m.ProductionBatch.vendor_id == vendor_id):
            raise BusinessError("VENDOR_HAS_DEPENDENCIES", 409)
        self.db.delete(obj)

    def validate_batch(self, obj):
        if obj.vendor_id is not None:
            self.get(m.Vendor, obj.vendor_id, lock=True)
        money_pair(obj, "unit_cost", "currency")
        required = []
        if obj.status in {"ORDERED", "PRODUCING", "SHIPPED", "RECEIVED"}:
            required = ["vendor_id", "unit_cost", "currency", "ordered_at"]
        if obj.status == "RECEIVED":
            required += ["received_quantity", "received_at"]
        missing = [x for x in required if getattr(obj, x) is None]
        if missing:
            raise BusinessError(
                "BATCH_STATE_REQUIREMENTS_NOT_MET", details={"fields": missing}
            )

    @atomic
    def create_batch(self, product_id, data):
        self.get(m.Product, product_id, lock=True)
        obj = m.ProductionBatch(product_id=product_id, **data.model_dump())
        self.validate_batch(obj)
        return self.save(obj)

    def get_batch(self, batch_id):
        return self.dump(self.get(m.ProductionBatch, batch_id))

    def list_product_batches(self, product_id):
        self.get(m.Product, product_id)
        fields = [
            "batch_id",
            "ordered_quantity",
            "received_quantity",
            "unit_cost",
            "currency",
            "status",
            "ordered_at",
            "expected_at",
            "received_at",
        ]
        q = (
            select(m.ProductionBatch)
            .where(m.ProductionBatch.product_id == product_id)
            .order_by(
                m.ProductionBatch.created_at.desc(), m.ProductionBatch.batch_id.desc()
            )
        )
        return envelope(
            [
                {
                    **self.dump(x, fields),
                    "vendor_name": (
                        self.get(m.Vendor, x.vendor_id).name
                        if x.vendor_id is not None
                        else None
                    ),
                }
                for x in self.db.scalars(q)
            ]
        )

    @atomic
    def update_batch(self, batch_id, data):
        obj = self.get(m.ProductionBatch, batch_id)
        self.get(m.Product, obj.product_id, lock=True)
        obj = self.get(m.ProductionBatch, batch_id, lock=True)
        values = data.model_dump(exclude_unset=True)
        transition(obj, values)
        self.changes(obj, values)
        self.validate_batch(obj)
        self.db.flush()
        InventoryService(self.db).validate_stock(obj.product_id)
        return self.dump(obj)

    @atomic
    def delete_batch(self, batch_id):
        obj = self.get(m.ProductionBatch, batch_id)
        self.get(m.Product, obj.product_id, lock=True)
        obj = self.get(m.ProductionBatch, batch_id, lock=True)
        if obj.status != "PLANNED" or self.count(
            m.SampleRound, m.SampleRound.batch_id == batch_id
        ):
            raise BusinessError("BATCH_NOT_DELETABLE", 409)
        self.db.delete(obj)

    def lock_batch(self, batch_id):
        obj = self.get(m.ProductionBatch, batch_id)
        self.get(m.Product, obj.product_id, lock=True)
        return self.get(m.ProductionBatch, batch_id, lock=True)

    @atomic
    def create_sample_round(self, batch_id, data):
        self.lock_batch(batch_id)
        if self.count(
            m.SampleRound,
            m.SampleRound.batch_id == batch_id,
            m.SampleRound.round_number == data.round_number,
        ):
            raise BusinessError("SAMPLE_ROUND_ALREADY_EXISTS", 409)
        obj = m.SampleRound(batch_id=batch_id, **data.model_dump())
        money_pair(obj, "sample_cost", "currency")
        return self.save(obj)

    def list_sample_rounds(self, batch_id):
        self.get(m.ProductionBatch, batch_id)
        return envelope(
            [
                self.dump(x)
                for x in self.db.scalars(
                    select(m.SampleRound)
                    .where(m.SampleRound.batch_id == batch_id)
                    .order_by(m.SampleRound.round_number)
                )
            ]
        )

    @atomic
    def update_sample_round(self, sample_id, data):
        obj = self.get(m.SampleRound, sample_id)
        self.lock_batch(obj.batch_id)
        obj = self.get(m.SampleRound, sample_id, lock=True)
        values = data.model_dump(exclude_unset=True)
        transition(obj, values)
        self.changes(obj, values)
        if self.count(
            m.SampleRound,
            m.SampleRound.batch_id == obj.batch_id,
            m.SampleRound.round_number == obj.round_number,
            m.SampleRound.sample_id != sample_id,
        ):
            raise BusinessError("SAMPLE_ROUND_ALREADY_EXISTS", 409)
        money_pair(obj, "sample_cost", "currency")
        return self.save(obj)

    @atomic
    def delete_sample_round(self, sample_id):
        obj = self.get(m.SampleRound, sample_id)
        self.lock_batch(obj.batch_id)
        obj = self.get(m.SampleRound, sample_id, lock=True)
        self.db.delete(obj)

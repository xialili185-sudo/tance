from sqlalchemy import select
from app import models as m
from app.core.errors import BusinessError
from app.core.policy import business_today
from app.db.types import utcnow
from app.services.common import Service, atomic, envelope


class EventRecommendationService(Service):
    def tags(self, ident):
        return list(
            self.db.scalars(
                select(m.EventListingTag.tag)
                .where(m.EventListingTag.event_listing_id == ident)
                .order_by(m.EventListingTag.tag)
            )
        )

    def selected(
        self,
        city=None,
        registration_status=None,
        available_from=None,
        available_to=None,
    ):
        if available_from and available_to and available_to < available_from:
            raise BusinessError("INVALID_EVENT_DATE")
        q = select(m.EventListing).order_by(
            m.EventListing.start_date, m.EventListing.event_listing_id
        )
        if registration_status is not None:
            q = q.where(m.EventListing.registration_status == registration_status)
        if available_from:
            q = q.where(m.EventListing.start_date >= available_from)
        if available_to:
            q = q.where(m.EventListing.end_date <= available_to)
        return [
            x
            for x in self.db.scalars(q)
            if city is None or x.city is not None and x.city.strip() == city.strip()
        ]

    def list_event_listings(self, **filters):
        fields = [
            "event_listing_id",
            "name",
            "city",
            "location",
            "start_date",
            "end_date",
            "application_deadline",
            "registration_status",
            "theme",
            "source_name",
        ]
        return envelope(
            [
                {**self.dump(x, fields), "tags": self.tags(x.event_listing_id)}
                for x in self.selected(**filters)
            ],
            True,
        )

    def get_event_listing(self, event_listing_id):
        obj = self.get(m.EventListing, event_listing_id)
        fields = [
            "event_listing_id",
            "name",
            "location",
            "city",
            "start_date",
            "end_date",
            "application_deadline",
            "theme",
            "description",
            "registration_status",
            "source_name",
            "source_url",
        ]
        return {**self.dump(obj, fields), "tags": self.tags(event_listing_id)}

    def recommend_events(self, data):
        choices = []
        now = utcnow()
        for obj in self.selected(
            available_from=data.available_from, available_to=data.available_to
        ):
            if (
                obj.end_date < business_today()
                or obj.registration_status == "CLOSED"
                or obj.application_deadline
                and obj.application_deadline < now
            ):
                continue
            if data.preferred_cities and (
                obj.city is None
                or obj.city.strip() not in [x.strip() for x in data.preferred_cities]
            ):
                continue
            if data.ip is not None and data.ip.strip().casefold() not in [
                x.strip().casefold() for x in self.tags(obj.event_listing_id)
            ]:
                continue
            reasons = ["展期符合可用时间，展会尚未结束。"]
            if data.ip is not None:
                reasons.append("展会标签符合指定 IP。")
            if data.preferred_cities:
                reasons.append("举办城市符合偏好。")
            reasons.append(
                {
                    "OPEN": "当前开放报名。",
                    "UPCOMING": "报名尚未开放，请关注来源信息。",
                    "UNKNOWN": "报名状态未知，请核验来源。",
                }[obj.registration_status]
            )
            choices.append((obj, reasons))
        choices.sort(
            key=lambda x: (
                {"OPEN": 0, "UPCOMING": 1, "UNKNOWN": 2}[x[0].registration_status],
                x[0].start_date,
                x[0].event_listing_id,
            )
        )
        fields = [
            "event_listing_id",
            "name",
            "city",
            "start_date",
            "end_date",
            "application_deadline",
            "registration_status",
        ]
        return {
            "recommendations": [
                {"event_listing": self.dump(x, fields), "match_reasons": reasons}
                for x, reasons in choices
            ]
        }

    @atomic
    def add_listing_to_plan(self, event_listing_id):
        obj = self.get(m.EventListing, event_listing_id, lock=True)
        existing = self.db.scalar(
            select(m.EventPlan).where(
                m.EventPlan.source_event_listing_id == event_listing_id,
                m.EventPlan.status != "CANCELLED",
            )
        )
        if existing:
            raise BusinessError(
                "EVENT_ALREADY_IN_PLAN",
                409,
                details={"existing_event_id": existing.event_id},
            )
        fields = ["name", "location", "start_date", "end_date", "application_deadline"]
        return self.save(
            m.EventPlan(
                **self.dump(obj, fields), source_event_listing_id=event_listing_id
            )
        )

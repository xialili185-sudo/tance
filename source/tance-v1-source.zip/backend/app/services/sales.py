from sqlalchemy import select
from app import models as m
from app.core.errors import BusinessError
from app.services.common import Service, atomic, envelope
from app.services.inventory import InventoryService


class SalesService(Service):
    def validate_sale(self, plan):
        inventory = InventoryService(self.db)
        allocation = inventory.allocation(plan.event_product_plan_id)
        if allocation is None:
            raise BusinessError("INVENTORY_NOT_ALLOCATED", 409)
        self.db.flush()
        if inventory.sold(plan.event_product_plan_id) > allocation.allocated_quantity:
            raise BusinessError("SALES_EXCEED_ALLOCATION")
        inventory.validate_stock(plan.product_id)

    @atomic
    def create_sales_record(self, plan_id, data):
        plan = self.lock_plan_stock(plan_id)
        if self.count(
            m.SalesRecord,
            m.SalesRecord.event_product_plan_id == plan_id,
            m.SalesRecord.sale_date == data.sale_date,
        ):
            raise BusinessError("SALES_RECORD_ALREADY_EXISTS", 409)
        obj = m.SalesRecord(event_product_plan_id=plan_id, **data.model_dump())
        self.db.add(obj)
        self.validate_sale(plan)
        return self.dump(obj)

    def list_sales_records(self, plan_id):
        self.get(m.EventProductPlan, plan_id)
        a = InventoryService(self.db).allocation(plan_id)
        remaining = a.allocated_quantity if a else 0
        items = []
        for obj in self.db.scalars(
            select(m.SalesRecord)
            .where(m.SalesRecord.event_product_plan_id == plan_id)
            .order_by(m.SalesRecord.sale_date, m.SalesRecord.sales_record_id)
        ):
            remaining -= obj.sold_quantity
            items.append(
                {
                    **self.dump(obj, ["sales_record_id", "sale_date", "sold_quantity"]),
                    "remaining_after_sale": remaining,
                }
            )
        return envelope(items)

    @atomic
    def update_sales_record(self, sales_record_id, data):
        obj = self.get(m.SalesRecord, sales_record_id)
        plan = self.lock_plan_stock(obj.event_product_plan_id)
        obj = self.get(m.SalesRecord, sales_record_id, lock=True)
        self.changes(obj, data)
        if self.count(
            m.SalesRecord,
            m.SalesRecord.event_product_plan_id == obj.event_product_plan_id,
            m.SalesRecord.sale_date == obj.sale_date,
            m.SalesRecord.sales_record_id != sales_record_id,
        ):
            raise BusinessError("SALES_RECORD_ALREADY_EXISTS", 409)
        self.validate_sale(plan)
        return self.dump(obj)

    @atomic
    def delete_sales_record(self, sales_record_id):
        obj = self.get(m.SalesRecord, sales_record_id)
        plan = self.lock_plan_stock(obj.event_product_plan_id)
        obj = self.get(m.SalesRecord, sales_record_id, lock=True)
        self.db.delete(obj)
        InventoryService(self.db).validate_stock(plan.product_id)

    def get_sales_summary(self, plan_id):
        state = InventoryService(self.db).get_allocation(plan_id)
        decision = self.db.scalar(
            select(m.QuantityDecision)
            .where(m.QuantityDecision.event_product_plan_id == plan_id)
            .order_by(
                m.QuantityDecision.created_at.desc(),
                m.QuantityDecision.decision_id.desc(),
            )
            .limit(1)
        )
        allocated = state["allocated_quantity"]
        sold = state["event_sold_quantity"]
        return {
            "allocated_quantity": allocated,
            "total_sold": sold,
            "event_remaining": allocated - sold,
            "sell_through_rate": sold / allocated if allocated else None,
            "planning_vs_actual": {
                "balanced_demand_estimate": (
                    decision.demand_balanced if decision else None
                ),
                "final_user_allocation": allocated,
                "actual_sales": sold,
            },
        }

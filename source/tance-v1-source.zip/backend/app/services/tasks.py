from sqlalchemy import select
from app import models as m
from app.core.errors import BusinessError
from app.db.types import utcnow
from app.services.common import Service, atomic, envelope
from app.services.states import transition


class TaskService(Service):
    @staticmethod
    def get_display_status(obj, now=None):
        return (
            "OVERDUE"
            if obj.status in {"TODO", "IN_PROGRESS"}
            and obj.due_at is not None
            and obj.due_at < (now or utcnow())
            else obj.status
        )

    def validate_plan(self, obj):
        if obj.event_product_plan_id is not None:
            plan = self.get(m.EventProductPlan, obj.event_product_plan_id)
            if plan.event_id != obj.event_id:
                raise BusinessError("TASK_EVENT_MISMATCH")

    def response(self, obj):
        return {**self.dump(obj), "display_status": self.get_display_status(obj)}

    @atomic
    def create_task(self, event_id, data):
        self.get(m.EventPlan, event_id, lock=True)
        obj = m.Task(event_id=event_id, **data.model_dump())
        self.validate_plan(obj)
        self.db.add(obj)
        self.db.flush()
        return self.response(obj)

    def list_items(self, q):
        result = []
        for x in self.db.scalars(q.order_by(m.Task.task_id)):
            product = None
            if x.event_product_plan_id is not None:
                plan = self.get(m.EventProductPlan, x.event_product_plan_id)
                product = self.get(m.Product, plan.product_id).name
            result.append(
                {
                    **self.dump(
                        x,
                        [
                            "task_id",
                            "title",
                            "task_type",
                            "status",
                            "due_at",
                            "event_product_plan_id",
                        ],
                    ),
                    "display_status": self.get_display_status(x),
                    "product_name": product,
                }
            )
        return envelope(result)

    def list_event_tasks(self, event_id, status=None, task_type=None):
        self.get(m.EventPlan, event_id)
        q = select(m.Task).where(m.Task.event_id == event_id)
        if status is not None:
            q = q.where(m.Task.status == status)
        if task_type is not None:
            q = q.where(m.Task.task_type == task_type)
        return self.list_items(q)

    def list_plan_tasks(self, plan_id):
        self.get(m.EventProductPlan, plan_id)
        return self.list_items(
            select(m.Task).where(m.Task.event_product_plan_id == plan_id)
        )

    @atomic
    def update_task(self, task_id, data):
        obj = self.get(m.Task, task_id)
        self.get(m.EventPlan, obj.event_id, lock=True)
        obj = self.get(m.Task, task_id, lock=True)
        values = data.model_dump(exclude_unset=True)
        transition(obj, values)
        old = obj.status
        self.changes(obj, values)
        self.validate_plan(obj)
        if obj.status == "DONE" and old != "DONE":
            obj.completed_at = utcnow()
        elif obj.status != "DONE":
            obj.completed_at = None
        self.db.flush()
        return self.response(obj)

    @atomic
    def delete_task(self, task_id):
        obj = self.get(m.Task, task_id)
        self.get(m.EventPlan, obj.event_id, lock=True)
        self.db.delete(self.get(m.Task, task_id, lock=True))

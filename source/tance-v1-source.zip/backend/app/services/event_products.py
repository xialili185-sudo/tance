from sqlalchemy import select
from app import models as m
from app.core.errors import BusinessError
from app.services.common import Service, atomic, envelope, money_pair
from app.services.states import transition, TERMINAL
from app.services.products import ProductService
from app.services.demand import DemandService
from app.services.inventory import InventoryService
from app.services.tasks import TaskService


class EventProductService(Service):
    @staticmethod
    def validate_price(obj):
        money_pair(obj, "selling_price", "currency")
        if obj.status in {"READY", "SELLING"} and obj.selling_price is None:
            raise BusinessError("PRICE_REQUIRED")

    @atomic
    def create_plan(self, event_id, data):
        self.get(m.EventPlan, event_id, lock=True)
        product = self.get(m.Product, data.product_id, lock=True)
        if self.count(
            m.EventProductPlan,
            m.EventProductPlan.event_id == event_id,
            m.EventProductPlan.product_id == data.product_id,
        ):
            raise BusinessError("PRODUCT_ALREADY_IN_EVENT", 409)
        values = data.model_dump(exclude_unset=True)
        if not {"selling_price", "currency"} & values.keys():
            values.update(
                selling_price=product.default_selling_price,
                currency=product.default_currency,
            )
        obj = m.EventProductPlan(event_id=event_id, **values)
        self.validate_price(obj)
        return self.save(obj)

    @atomic
    def update_plan(self, plan_id, data):
        obj = self.lock_plan_stock(plan_id)
        values = data.model_dump(exclude_unset=True)
        transition(obj, values)
        self.changes(obj, values)
        self.validate_price(obj)
        InventoryService(self.db).validate_stock(obj.product_id)
        return self.dump(obj)

    @atomic
    def delete_plan(self, plan_id):
        obj = self.lock_plan_stock(plan_id)
        for cls in [
            m.DemandSignal,
            m.QuantityDecision,
            m.InventoryAllocation,
            m.SalesRecord,
            m.Task,
        ]:
            if self.count(cls, cls.event_product_plan_id == plan_id):
                raise BusinessError("EVENT_PRODUCT_PLAN_HAS_DEPENDENCIES", 409)
        self.db.delete(obj)

    def latest_decision(self, plan_id):
        return self.db.scalar(
            select(m.QuantityDecision)
            .where(m.QuantityDecision.event_product_plan_id == plan_id)
            .order_by(
                m.QuantityDecision.created_at.desc(),
                m.QuantityDecision.decision_id.desc(),
            )
            .limit(1)
        )

    def latest_batch(self, product_id):
        return self.db.scalar(
            select(m.ProductionBatch)
            .where(
                m.ProductionBatch.product_id == product_id,
                m.ProductionBatch.status != "CANCELLED",
            )
            .order_by(
                m.ProductionBatch.created_at.desc(), m.ProductionBatch.batch_id.desc()
            )
            .limit(1)
        )

    def get_progress(self, plan_id):
        plan = self.get(m.EventProductPlan, plan_id)
        _, _, life, signals = DemandService(self.db).context(plan_id)
        decision = self.latest_decision(plan_id)
        batch = self.latest_batch(plan.product_id)
        return {
            "demand": (
                "READY"
                if signals or life["previous_event_sales"] is not None
                else "MISSING"
            ),
            "recommendation": "GENERATED" if decision else "NOT_GENERATED",
            "final_quantity": (
                "CONFIRMED"
                if decision and decision.final_production_quantity is not None
                else "UNCONFIRMED"
            ),
            "production": batch.status if batch else "NOT_STARTED",
            "inventory": (
                "ALLOCATED"
                if InventoryService(self.db).allocation(plan_id)
                else "NOT_ALLOCATED"
            ),
            "sales": (
                "RECORDED"
                if self.count(
                    m.SalesRecord, m.SalesRecord.event_product_plan_id == plan_id
                )
                else "NOT_STARTED"
            ),
        }

    def get_attention_items(self, plan_id):
        plan = self.get(m.EventProductPlan, plan_id)
        event = self.get(m.EventPlan, plan.event_id)
        if plan.status in TERMINAL or event.status in TERMINAL:
            return []
        progress = self.get_progress(plan_id)
        items = []
        for field, value, kind, message in [
            ("demand", "MISSING", "DEMAND_MISSING", "尚未录入需求证据。"),
            (
                "recommendation",
                "NOT_GENERATED",
                "RECOMMENDATION_MISSING",
                "尚未生成数量建议。",
            ),
            (
                "final_quantity",
                "UNCONFIRMED",
                "FINAL_QUANTITY_UNCONFIRMED",
                "尚未确认追加生产量。",
            ),
            (
                "inventory",
                "NOT_ALLOCATED",
                "INVENTORY_NOT_ALLOCATED",
                "尚未分配参展库存。",
            ),
        ]:
            if progress[field] == value:
                items.append({"type": kind, "severity": "WARNING", "message": message})
        for task in self.db.scalars(
            select(m.Task)
            .where(m.Task.event_product_plan_id == plan_id)
            .order_by(m.Task.task_id)
        ):
            if TaskService.get_display_status(task) == "OVERDUE":
                items.append(
                    {
                        "type": "TASK_OVERDUE",
                        "severity": "WARNING",
                        "message": f"任务已逾期：{task.title}（{task.task_id}）",
                    }
                )
        return items

    def list_event_products(self, event_id):
        self.get(m.EventPlan, event_id)
        items = []
        for plan in self.db.scalars(
            select(m.EventProductPlan)
            .where(m.EventProductPlan.event_id == event_id)
            .order_by(m.EventProductPlan.event_product_plan_id)
        ):
            product = self.get(m.Product, plan.product_id)
            decision = self.latest_decision(plan.event_product_plan_id)
            batch = self.latest_batch(plan.product_id)
            readiness = DemandService(self.db).get_readiness(plan.event_product_plan_id)
            items.append(
                {
                    **self.dump(
                        plan,
                        [
                            "event_product_plan_id",
                            "product_id",
                            "selling_price",
                            "currency",
                            "status",
                        ],
                    ),
                    "product_name": product.name,
                    "product_type": product.product_type,
                    "current_stock": ProductService(self.db).get_current_stock(
                        product.product_id
                    ),
                    "demand_readiness": readiness["level"],
                    "latest_recommended_production": (
                        decision.recommended_production if decision else None
                    ),
                    "recommendation_confidence": (
                        decision.confidence_level if decision else None
                    ),
                    "production_status": batch.status if batch else None,
                    "warnings": [x["message"] for x in readiness["warnings"]],
                }
            )
        return envelope(items, True)

    def get_plan(self, plan_id):
        plan = self.get(m.EventProductPlan, plan_id)
        event = self.get(m.EventPlan, plan.event_id)
        product = self.get(m.Product, plan.product_id)
        return {
            **self.dump(
                plan, ["event_product_plan_id", "selling_price", "currency", "status"]
            ),
            "event": self.dump(event, ["event_id", "name", "start_date", "end_date"]),
            "product": self.dump(product, ["product_id", "name", "product_type"]),
            "lifecycle": ProductService(self.db).lifecycle(plan),
            "current_stock": ProductService(self.db).get_current_stock(plan.product_id),
            "progress": self.get_progress(plan_id),
            "attention_items": self.get_attention_items(plan_id),
        }

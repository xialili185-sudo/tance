class BusinessError(Exception):
    def __init__(
        self,
        code: str,
        status: int = 422,
        message: str | None = None,
        details: dict | None = None,
    ):
        self.code = code
        self.status = status
        self.message = message or code.replace("_", " ").capitalize()
        self.details = details
        super().__init__(self.message)

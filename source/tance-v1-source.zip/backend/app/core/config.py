from functools import lru_cache
from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import URL

PROJECT_ROOT = Path(__file__).resolve().parents[3]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=PROJECT_ROOT / ".env", env_file_encoding="utf-8", extra="ignore"
    )
    business_timezone: str = "Asia/Shanghai"
    app_env: str = "development"
    database_host: str = "127.0.0.1"
    database_port: int = 3306
    database_user: str = "tance"
    database_password: SecretStr = SecretStr("")
    database_name: str = "tance_dev"
    test_database_name: str = "tance_test"
    cors_origins: list[str] = ["http://127.0.0.1:5173", "http://localhost:5173"]
    llm_enabled: bool = False
    llm_provider: str = ""
    llm_base_url: str = ""
    llm_model: str = ""
    llm_api_key: SecretStr = SecretStr("")

    def database_url(self, *, test: bool = False) -> URL:
        # URL.create handles special characters without leaking credentials.
        return URL.create(
            "mysql+pymysql",
            username=self.database_user,
            password=self.database_password.get_secret_value(),
            host=self.database_host,
            port=self.database_port,
            database=self.test_database_name if test else self.database_name,
            query={"charset": "utf8mb4"},
        )


@lru_cache
def get_settings() -> Settings:
    return Settings()

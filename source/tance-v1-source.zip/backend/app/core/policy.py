"""Approved SC-05 starting parameters, not statistically calibrated estimates."""

from dataclasses import dataclass
from decimal import Decimal
from datetime import datetime
from zoneinfo import ZoneInfo
from app.core.config import get_settings


@dataclass(frozen=True)
class RecommendationRules:
    survey: Decimal = Decimal("0.8")
    preorder: Decimal = Decimal("1")
    manual: Decimal = Decimal("1")
    social: Decimal = Decimal("0.05")
    wishlist: Decimal = Decimal("0.1")
    history: Decimal = Decimal("0.8")
    stale_multiplier: Decimal = Decimal("0.5")
    conservative: Decimal = Decimal("0.8")
    aggressive: Decimal = Decimal("1.2")
    fresh_days: int = 30


RULES = RecommendationRules()


def business_today():
    return datetime.now(ZoneInfo(get_settings().business_timezone)).date()

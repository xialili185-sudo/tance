"""Frozen V1 relational entities. Derived inventory and progress are never stored."""

from datetime import date, datetime
from decimal import Decimal

from sqlalchemy import (
    JSON,
    BigInteger,
    CHAR,
    Date,
    Index,
    Integer,
    Numeric,
    String,
    Text,
    ForeignKey,
    UniqueConstraint,
)
from sqlalchemy.orm import Mapped, mapped_column

from app.db.base import Base
from app.db.types import UTCDateTime, utcnow


class EventListing(Base):
    __tablename__ = "event_listings"
    event_listing_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    location: Mapped[str] = mapped_column(String(255), nullable=False)
    city: Mapped[str | None] = mapped_column(String(100), nullable=True)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)
    application_deadline: Mapped[datetime | None] = mapped_column(
        UTCDateTime(), nullable=True
    )
    theme: Mapped[str | None] = mapped_column(String(255), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    registration_status: Mapped[str] = mapped_column(
        String(30), nullable=False, default="UNKNOWN"
    )
    source_name: Mapped[str | None] = mapped_column(String(100), nullable=True)
    source_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow, onupdate=utcnow
    )


class EventListingTag(Base):
    __tablename__ = "event_listing_tags"
    __table_args__ = (Index("ix_event_listing_tags_tag", "tag"),)
    event_listing_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("event_listings.event_listing_id", ondelete="CASCADE"),
        primary_key=True,
    )
    tag: Mapped[str] = mapped_column(String(100), primary_key=True)


class EventPlan(Base):
    __tablename__ = "event_plans"
    __table_args__ = (
        Index("ix_event_plans_source_event_listing_id", "source_event_listing_id"),
    )
    event_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    location: Mapped[str] = mapped_column(String(255), nullable=False)
    start_date: Mapped[date] = mapped_column(Date, nullable=False)
    end_date: Mapped[date] = mapped_column(Date, nullable=False)
    application_deadline: Mapped[datetime | None] = mapped_column(
        UTCDateTime(), nullable=True
    )
    source_event_listing_id: Mapped[int | None] = mapped_column(
        BigInteger,
        ForeignKey("event_listings.event_listing_id", ondelete="SET NULL"),
        nullable=True,
    )
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="PLANNING")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow, onupdate=utcnow
    )


class Content(Base):
    __tablename__ = "contents"
    content_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    title: Mapped[str] = mapped_column(String(150), nullable=False)
    content_type: Mapped[str] = mapped_column(String(50), nullable=False)
    file_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    thumbnail_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="ACTIVE")
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow, onupdate=utcnow
    )


class ProductContent(Base):
    __tablename__ = "product_contents"
    __table_args__ = (Index("ix_product_contents_content_id", "content_id"),)
    product_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("products.product_id", ondelete="CASCADE"),
        primary_key=True,
    )
    content_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("contents.content_id", ondelete="CASCADE"),
        primary_key=True,
    )


class EventProductPlan(Base):
    __tablename__ = "event_product_plans"
    __table_args__ = (
        UniqueConstraint(
            "event_id", "product_id", name="uq_event_product_plans_event_id_product_id"
        ),
        Index("ix_event_product_plans_product_id", "product_id"),
    )
    event_product_plan_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    event_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("event_plans.event_id", ondelete="RESTRICT"),
        nullable=False,
    )
    product_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("products.product_id", ondelete="RESTRICT"),
        nullable=False,
    )
    selling_price: Mapped[Decimal | None] = mapped_column(Numeric(10, 2), nullable=True)
    currency: Mapped[str | None] = mapped_column(CHAR(3), nullable=True)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="PLANNING")
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow, onupdate=utcnow
    )


class DemandSignal(Base):
    __tablename__ = "demand_signals"
    __table_args__ = (
        Index(
            "ix_demand_signals_event_product_plan_id_signal_type_observed_at",
            "event_product_plan_id",
            "signal_type",
            "observed_at",
        ),
    )
    signal_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    event_product_plan_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("event_product_plans.event_product_plan_id", ondelete="RESTRICT"),
        nullable=False,
    )
    signal_type: Mapped[str] = mapped_column(String(50), nullable=False)
    value: Mapped[int] = mapped_column(BigInteger, nullable=False)
    source: Mapped[str | None] = mapped_column(String(100), nullable=True)
    observed_at: Mapped[datetime] = mapped_column(UTCDateTime(), nullable=False)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )


class QuantityDecision(Base):
    __tablename__ = "quantity_decisions"
    __table_args__ = (
        Index(
            "ix_quantity_decisions_event_product_plan_id_created_at",
            "event_product_plan_id",
            "created_at",
        ),
    )
    decision_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    event_product_plan_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("event_product_plans.event_product_plan_id", ondelete="RESTRICT"),
        nullable=False,
    )
    current_stock_snapshot: Mapped[int] = mapped_column(BigInteger, nullable=False)
    demand_conservative: Mapped[int] = mapped_column(BigInteger, nullable=False)
    demand_balanced: Mapped[int] = mapped_column(BigInteger, nullable=False)
    demand_aggressive: Mapped[int] = mapped_column(BigInteger, nullable=False)
    recommended_strategy: Mapped[str] = mapped_column(String(20), nullable=False)
    recommended_demand: Mapped[int] = mapped_column(BigInteger, nullable=False)
    production_conservative: Mapped[int] = mapped_column(BigInteger, nullable=False)
    production_balanced: Mapped[int] = mapped_column(BigInteger, nullable=False)
    production_aggressive: Mapped[int] = mapped_column(BigInteger, nullable=False)
    recommended_production: Mapped[int] = mapped_column(BigInteger, nullable=False)
    final_production_quantity: Mapped[int | None] = mapped_column(
        BigInteger, nullable=True
    )
    confidence_level: Mapped[str] = mapped_column(String(20), nullable=False)
    warnings: Mapped[list[dict[str, str]]] = mapped_column(
        JSON, nullable=False, default=list
    )
    recommendation_reason: Mapped[str | None] = mapped_column(Text, nullable=True)
    decision_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    confirmed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)


class Vendor(Base):
    __tablename__ = "vendors"
    vendor_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    name: Mapped[str] = mapped_column(String(150), nullable=False)
    contact: Mapped[str | None] = mapped_column(String(255), nullable=True)
    website: Mapped[str | None] = mapped_column(String(500), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    status: Mapped[str] = mapped_column(String(20), nullable=False, default="ACTIVE")
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow, onupdate=utcnow
    )


class ProductionBatch(Base):
    __tablename__ = "production_batches"
    __table_args__ = (
        Index("ix_production_batches_product_id", "product_id"),
        Index("ix_production_batches_vendor_id", "vendor_id"),
    )
    batch_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    product_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("products.product_id", ondelete="RESTRICT"),
        nullable=False,
    )
    vendor_id: Mapped[int | None] = mapped_column(
        BigInteger, ForeignKey("vendors.vendor_id", ondelete="RESTRICT"), nullable=True
    )
    ordered_quantity: Mapped[int] = mapped_column(BigInteger, nullable=False)
    received_quantity: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    unit_cost: Mapped[Decimal | None] = mapped_column(Numeric(10, 2), nullable=True)
    currency: Mapped[str | None] = mapped_column(CHAR(3), nullable=True)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="PLANNED")
    ordered_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    expected_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    received_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow, onupdate=utcnow
    )


class SampleRound(Base):
    __tablename__ = "sample_rounds"
    __table_args__ = (
        UniqueConstraint(
            "batch_id", "round_number", name="uq_sample_rounds_batch_id_round_number"
        ),
    )
    sample_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    batch_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("production_batches.batch_id", ondelete="RESTRICT"),
        nullable=False,
    )
    round_number: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="PENDING")
    submitted_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    received_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    sample_cost: Mapped[Decimal | None] = mapped_column(Numeric(10, 2), nullable=True)
    currency: Mapped[str | None] = mapped_column(CHAR(3), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )


class InventoryAllocation(Base):
    __tablename__ = "inventory_allocations"
    __table_args__ = (
        UniqueConstraint(
            "event_product_plan_id",
            name="uq_inventory_allocations_event_product_plan_id",
        ),
    )
    allocation_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    event_product_plan_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("event_product_plans.event_product_plan_id", ondelete="RESTRICT"),
        nullable=False,
    )
    allocated_quantity: Mapped[int] = mapped_column(BigInteger, nullable=False)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow, onupdate=utcnow
    )


class SalesRecord(Base):
    __tablename__ = "sales_records"
    __table_args__ = (
        UniqueConstraint(
            "event_product_plan_id",
            "sale_date",
            name="uq_sales_records_event_product_plan_id_sale_date",
        ),
    )
    sales_record_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    event_product_plan_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("event_product_plans.event_product_plan_id", ondelete="RESTRICT"),
        nullable=False,
    )
    sale_date: Mapped[date] = mapped_column(Date, nullable=False)
    sold_quantity: Mapped[int] = mapped_column(BigInteger, nullable=False)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow, onupdate=utcnow
    )


class Task(Base):
    __tablename__ = "tasks"
    __table_args__ = (
        Index("ix_tasks_event_id_due_at", "event_id", "due_at"),
        Index("ix_tasks_event_product_plan_id", "event_product_plan_id"),
    )
    task_id: Mapped[int] = mapped_column(
        BigInteger, primary_key=True, autoincrement=True
    )
    event_id: Mapped[int] = mapped_column(
        BigInteger,
        ForeignKey("event_plans.event_id", ondelete="RESTRICT"),
        nullable=False,
    )
    event_product_plan_id: Mapped[int | None] = mapped_column(
        BigInteger,
        ForeignKey("event_product_plans.event_product_plan_id", ondelete="RESTRICT"),
        nullable=True,
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    task_type: Mapped[str] = mapped_column(String(50), nullable=False)
    status: Mapped[str] = mapped_column(String(30), nullable=False, default="TODO")
    due_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    completed_at: Mapped[datetime | None] = mapped_column(UTCDateTime(), nullable=True)
    notes: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(), nullable=False, default=utcnow, onupdate=utcnow
    )

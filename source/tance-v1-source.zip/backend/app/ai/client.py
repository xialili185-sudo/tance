"""LLM provider configuration boundary. No paid requests during environment checks."""

from typing import Literal
from app.config import Settings


def configuration_status(
    settings: Settings,
) -> Literal["disabled", "configured", "missing_configuration"]:
    if not settings.llm_enabled:
        return "disabled"
    fields = (
        settings.llm_provider,
        settings.llm_base_url,
        settings.llm_model,
        settings.llm_api_key.get_secret_value(),
    )
    return "configured" if all(fields) else "missing_configuration"

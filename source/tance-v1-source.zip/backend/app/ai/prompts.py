"""Versioned explanation prompts will be added when the AI feature is implemented."""

"""Inject a provider adapter after choosing one; explanations never own numbers."""

from copy import deepcopy
from typing import Protocol
from pydantic import BaseModel, ConfigDict, Field


class ExplanationClient(Protocol):
    def explain(self, context: dict, *, timeout_seconds: float) -> dict: ...


class Explanation(BaseModel):
    model_config = ConfigDict(extra="forbid")
    recommendation_reason: str = Field(min_length=1, max_length=8000)


class RecommendationExplainer:
    def __init__(self, client: ExplanationClient | None = None):
        self.client = client

    def explain(self, context: dict) -> str | None:
        if self.client is None:
            return None
        try:
            result = Explanation.model_validate(
                self.client.explain(deepcopy(context), timeout_seconds=10)
            )
            return result.recommendation_reason.strip() or None
        except Exception:
            # Provider and validation failures must not lose the numeric decision.
            return None

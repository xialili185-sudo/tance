"""Future structured explanation validation. LLM output must never modify quantities."""

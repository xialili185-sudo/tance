"""Provider-independent explanation layer; no quantity calculations."""

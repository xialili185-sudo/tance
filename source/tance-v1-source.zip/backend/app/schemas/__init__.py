"""Pydantic API schemas, separate from database models."""

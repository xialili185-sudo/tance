from decimal import Decimal
from datetime import date, datetime, timezone
from typing import Annotated, Generic, TypeVar

from pydantic import (
    BaseModel,
    BeforeValidator,
    ConfigDict,
    Field,
    PlainSerializer,
    field_serializer,
    field_validator,
)


def money_input(value):
    if not isinstance(value, (str, Decimal)):
        raise ValueError("Money must be a decimal string")
    return value


Money = Annotated[
    Decimal,
    BeforeValidator(money_input),
    Field(ge=0, max_digits=10, decimal_places=2),
    PlainSerializer(lambda v: format(v, ".2f"), return_type=str),
]
ID = Annotated[int, Field(strict=True, gt=0, le=9223372036854775807)]
Quantity = Annotated[int, Field(strict=True, ge=0, le=9223372036854775807)]
PositiveQuantity = Annotated[int, Field(strict=True, gt=0, le=9223372036854775807)]
RoundNumber = Annotated[int, Field(strict=True, gt=0, le=2147483647)]
Name = Annotated[str, Field(min_length=1, max_length=150)]
Location = Annotated[str, Field(min_length=1, max_length=255)]
ShortText = Annotated[str, Field(max_length=100)]
TaskTitle = Annotated[str, Field(min_length=1, max_length=200)]
URLString = Annotated[str, Field(max_length=500)]
Currency = Annotated[str, Field(pattern=r"^[A-Z]{3}$")]


class Input(BaseModel):
    model_config = ConfigDict(extra="forbid")

    @field_validator("*", mode="before", check_fields=False)
    @classmethod
    def temporal_input(cls, value, info):
        if value is None:
            return value
        datetime_fields = {
            "observed_at",
            "ordered_at",
            "expected_at",
            "received_at",
            "submitted_at",
            "due_at",
            "application_deadline",
        }
        date_fields = {
            "start_date",
            "end_date",
            "sale_date",
            "available_from",
            "available_to",
        }
        if info.field_name in datetime_fields and not isinstance(
            value, (str, datetime)
        ):
            raise ValueError("Datetime must be a timezone-aware ISO 8601 string")
        if info.field_name in date_fields:
            if isinstance(value, datetime) or not isinstance(value, (str, date)):
                raise ValueError("Date must use YYYY-MM-DD")
            if isinstance(value, str) and (
                len(value) != 10 or value[4] != "-" or value[7] != "-"
            ):
                raise ValueError("Date must use YYYY-MM-DD")
        return value


class Output(BaseModel):
    model_config = ConfigDict(from_attributes=True, extra="forbid")

    @field_serializer("*", when_used="json", check_fields=False)
    def serialize_values(self, value):
        if isinstance(value, Decimal):
            return format(value, ".2f")
        if isinstance(value, datetime):
            return value.astimezone(timezone.utc).isoformat().replace("+00:00", "Z")
        return value


T = TypeVar("T")


class Items(Output, Generic[T]):
    items: list[T]


class Listing(Items[T], Generic[T]):
    total: int

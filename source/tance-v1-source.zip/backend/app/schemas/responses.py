"""Typed response contracts; stored entities and read projections remain separate."""

from datetime import date, datetime
from typing import Literal
from app.schemas.common import Money, Output
from app.core.enums import (
    AssetStatus,
    BatchStatus,
    ConfidenceLevel,
    ContentType,
    EventProductStatus,
    EventStatus,
    ProductType,
    RecommendationStrategy,
    RegistrationStatus,
    SampleStatus,
    SignalType,
    TaskStatus,
    TaskType,
)


class EventResponse(Output):
    event_id: int
    name: str
    location: str
    start_date: date
    end_date: date
    application_deadline: datetime | None
    source_event_listing_id: int | None
    status: EventStatus
    notes: str | None
    created_at: datetime
    updated_at: datetime


class ProductResponse(Output):
    product_id: int
    name: str
    product_type: ProductType
    description: str | None
    default_selling_price: Money | None
    default_currency: str | None
    status: AssetStatus
    created_at: datetime
    updated_at: datetime


class ContentResponse(Output):
    content_id: int
    title: str
    content_type: ContentType
    file_url: str | None
    thumbnail_url: str | None
    description: str | None
    status: AssetStatus
    created_at: datetime
    updated_at: datetime


class EventProductPlanResponse(Output):
    event_product_plan_id: int
    event_id: int
    product_id: int
    selling_price: Money | None
    currency: str | None
    status: EventProductStatus
    notes: str | None
    created_at: datetime
    updated_at: datetime


class DemandSignalResponse(Output):
    signal_id: int
    event_product_plan_id: int
    signal_type: SignalType
    value: int
    source: str | None
    observed_at: datetime
    notes: str | None
    created_at: datetime


class VendorResponse(Output):
    vendor_id: int
    name: str
    contact: str | None
    website: str | None
    notes: str | None
    status: AssetStatus
    created_at: datetime
    updated_at: datetime


class ProductionBatchResponse(Output):
    batch_id: int
    product_id: int
    vendor_id: int | None
    ordered_quantity: int
    received_quantity: int | None
    unit_cost: Money | None
    currency: str | None
    status: BatchStatus
    ordered_at: datetime | None
    expected_at: datetime | None
    received_at: datetime | None
    notes: str | None
    created_at: datetime
    updated_at: datetime


class SampleRoundResponse(Output):
    sample_id: int
    batch_id: int
    round_number: int
    status: SampleStatus
    submitted_at: datetime | None
    received_at: datetime | None
    sample_cost: Money | None
    currency: str | None
    notes: str | None
    created_at: datetime


class SalesRecordResponse(Output):
    sales_record_id: int
    event_product_plan_id: int
    sale_date: date
    sold_quantity: int
    notes: str | None
    created_at: datetime
    updated_at: datetime


class TaskResponse(Output):
    task_id: int
    event_id: int
    event_product_plan_id: int | None
    title: str
    task_type: TaskType
    status: TaskStatus
    due_at: datetime | None
    completed_at: datetime | None
    notes: str | None
    created_at: datetime
    updated_at: datetime
    display_status: Literal["TODO", "IN_PROGRESS", "DONE", "CANCELLED", "OVERDUE"]


class InventorySummary(Output):
    total_received: int
    total_sold: int
    current_stock: int


class ProductSalesSummary(Output):
    event_count: int
    latest_event_sales: int | None


class ProductSummaryResponse(Output):
    product_id: int
    name: str
    product_type: ProductType
    default_selling_price: Money | None
    default_currency: str | None
    status: AssetStatus
    current_stock: int
    event_count: int
    content_count: int


class ProductDetailResponse(Output):
    product_id: int
    name: str
    product_type: ProductType
    description: str | None
    default_selling_price: Money | None
    default_currency: str | None
    status: AssetStatus
    inventory_summary: InventorySummary
    sales_summary: ProductSalesSummary
    created_at: datetime
    updated_at: datetime


class ProductSalesHistoryItem(Output):
    event_id: int
    event_name: str
    event_start_date: date
    total_sold: int


class ProductSalesHistoryResponse(Output):
    product_id: int
    items: list[ProductSalesHistoryItem]


class ContentSummaryResponse(Output):
    content_id: int
    title: str
    content_type: ContentType
    thumbnail_url: str | None
    status: AssetStatus
    used_in_product_count: int


class LinkedContentResponse(Output):
    content_id: int
    title: str
    content_type: ContentType
    thumbnail_url: str | None


class LinkedProductResponse(Output):
    product_id: int
    name: str
    product_type: ProductType


class EventSummaryResponse(Output):
    event_id: int
    name: str
    location: str
    start_date: date
    end_date: date
    status: EventStatus
    product_count: int


class EventCounts(Output):
    product_count: int
    ready_product_count: int
    demand_checked_count: int
    production_ready_count: int


class EventDetailResponse(Output):
    event_id: int
    name: str
    location: str
    start_date: date
    end_date: date
    application_deadline: datetime | None
    status: EventStatus
    notes: str | None
    summary: EventCounts
    attention_count: int
    created_at: datetime
    updated_at: datetime


class EventListingSummaryResponse(Output):
    event_listing_id: int
    name: str
    city: str | None
    location: str
    start_date: date
    end_date: date
    application_deadline: datetime | None
    registration_status: RegistrationStatus
    theme: str | None
    tags: list[str]
    source_name: str | None


class EventListingDetailResponse(Output):
    event_listing_id: int
    name: str
    location: str
    city: str | None
    start_date: date
    end_date: date
    application_deadline: datetime | None
    theme: str | None
    description: str | None
    registration_status: RegistrationStatus
    tags: list[str]
    source_name: str | None
    source_url: str | None


class EventRecommendationListing(Output):
    event_listing_id: int
    name: str
    city: str | None
    start_date: date
    end_date: date
    application_deadline: datetime | None
    registration_status: RegistrationStatus


class EventRecommendation(Output):
    event_listing: EventRecommendationListing
    match_reasons: list[str]


class EventRecommendationResponse(Output):
    recommendations: list[EventRecommendation]


class EventProductPlanSummaryResponse(Output):
    event_product_plan_id: int
    product_id: int
    product_name: str
    product_type: ProductType
    selling_price: Money | None
    currency: str | None
    status: EventProductStatus
    current_stock: int
    demand_readiness: ConfidenceLevel
    latest_recommended_production: int | None
    recommendation_confidence: ConfidenceLevel | None
    production_status: BatchStatus | None
    warnings: list[str]


class PlanEvent(Output):
    event_id: int
    name: str
    start_date: date
    end_date: date


class PlanProduct(Output):
    product_id: int
    name: str
    product_type: ProductType


class Lifecycle(Output):
    is_resale: bool
    sale_round: int
    previous_event_sales: int | None


class Progress(Output):
    demand: str
    recommendation: str
    final_quantity: str
    production: str
    inventory: str
    sales: str


class Attention(Output):
    type: str
    severity: str
    message: str


class EventProductPlanDetailResponse(Output):
    event_product_plan_id: int
    event: PlanEvent
    product: PlanProduct
    selling_price: Money | None
    currency: str | None
    status: EventProductStatus
    lifecycle: Lifecycle
    current_stock: int
    progress: Progress
    attention_items: list[Attention]


class Warning(Output):
    code: str
    message: str


class LatestSignal(Output):
    value: int
    observed_at: datetime


class DemandChecks(Output):
    historical_sales: bool
    current_event_survey: bool
    wishlist: bool
    preorder: bool
    recent_social_signal: bool


class DemandReadinessResponse(Output):
    level: ConfidenceLevel
    is_resale: bool
    sale_round: int
    checks: DemandChecks
    latest_signals: dict[SignalType, LatestSignal]
    warnings: list[Warning]


class QuantityRangeResponse(Output):
    conservative: int
    balanced: int
    aggressive: int
    recommended: int


class QuantityDecisionResponse(Output):
    decision_id: int
    event_product_plan_id: int
    created_at: datetime
    current_stock_snapshot: int
    confidence_level: ConfidenceLevel
    recommended_strategy: RecommendationStrategy
    demand: QuantityRangeResponse
    production: QuantityRangeResponse
    warnings: list[Warning]
    recommendation_reason: str | None
    explanation_status: Literal["AVAILABLE", "UNAVAILABLE"]
    final_production_quantity: int | None
    confirmed_at: datetime | None


class QuantityDecisionSummaryResponse(Output):
    decision_id: int
    created_at: datetime
    recommended_strategy: RecommendationStrategy
    recommended_demand: int
    recommended_production: int
    final_production_quantity: int | None
    confidence_level: ConfidenceLevel


class FinalDecisionResponse(Output):
    decision_id: int
    recommended_production: int
    final_production_quantity: int
    confirmed_at: datetime


class ProductionBatchSummaryResponse(Output):
    batch_id: int
    vendor_name: str | None
    ordered_quantity: int
    received_quantity: int | None
    unit_cost: Money | None
    currency: str | None
    status: BatchStatus
    ordered_at: datetime | None
    expected_at: datetime | None
    received_at: datetime | None


class InventoryAllocationResponse(Output):
    current_stock: int
    reserved_by_other_events: int
    max_allocatable_quantity: int
    allocated_quantity: int
    event_sold_quantity: int
    event_remaining_quantity: int
    unallocated_available_stock: int


class SalesRecordListItem(Output):
    sales_record_id: int
    sale_date: date
    sold_quantity: int
    remaining_after_sale: int


class PlanningVsActual(Output):
    balanced_demand_estimate: int | None
    final_user_allocation: int
    actual_sales: int


class SalesSummaryResponse(Output):
    allocated_quantity: int
    total_sold: int
    event_remaining: int
    sell_through_rate: float | None
    planning_vs_actual: PlanningVsActual


class TaskListItem(Output):
    task_id: int
    title: str
    task_type: TaskType
    status: TaskStatus
    display_status: Literal["TODO", "IN_PROGRESS", "DONE", "CANCELLED", "OVERDUE"]
    due_at: datetime | None
    event_product_plan_id: int | None
    product_name: str | None


class NextEvent(Output):
    event_id: int
    name: str
    start_date: date
    days_remaining: int
    status: EventStatus


class DashboardAttention(Output):
    type: str
    severity: str
    event_id: int
    event_product_plan_id: int | None
    product_name: str | None
    message: str


class UpcomingTask(Output):
    task_id: int
    title: str
    due_at: datetime | None


class ProductionSummary(Output):
    sampling: int
    producing: int
    shipped: int


class DashboardResponse(Output):
    next_event: NextEvent | None
    attention_items: list[DashboardAttention]
    upcoming_tasks: list[UpcomingTask]
    production_summary: ProductionSummary
    recent_products: list[ProductSummaryResponse]


class ContentDetailResponse(ContentResponse):
    used_in_product_count: int

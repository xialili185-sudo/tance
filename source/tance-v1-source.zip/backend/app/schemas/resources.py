"""Write contracts: omission is distinct from explicit null on every PATCH."""

from datetime import date
from pydantic import AwareDatetime, Field
from app.core.enums import (
    AssetStatus,
    BatchStatus,
    ContentType,
    EventProductStatus,
    EventStatus,
    ProductType,
    SampleStatus,
    SignalType,
    TaskStatus,
    TaskType,
)
from app.schemas.common import (
    Currency,
    ID,
    Input,
    Location,
    Money,
    Name,
    PositiveQuantity,
    Quantity,
    RoundNumber,
    ShortText,
    TaskTitle,
    URLString,
)


class EventCreate(Input):
    name: Name
    location: Location
    start_date: date
    end_date: date
    application_deadline: AwareDatetime | None = None
    notes: str | None = None


class EventUpdate(Input):
    name: Name = Field(default=None)
    location: Location = Field(default=None)
    start_date: date = Field(default=None)
    end_date: date = Field(default=None)
    application_deadline: AwareDatetime | None = Field(default=None)
    notes: str | None = Field(default=None)
    status: EventStatus = Field(default=None)


class ProductCreate(Input):
    name: Name
    product_type: ProductType
    description: str | None = None
    default_selling_price: Money | None = None
    default_currency: Currency | None = None


class ProductUpdate(Input):
    name: Name = Field(default=None)
    product_type: ProductType = Field(default=None)
    description: str | None = Field(default=None)
    default_selling_price: Money | None = Field(default=None)
    default_currency: Currency | None = Field(default=None)
    status: AssetStatus = Field(default=None)


class ContentCreate(Input):
    title: Name
    content_type: ContentType
    file_url: URLString | None = None
    thumbnail_url: URLString | None = None
    description: str | None = None


class ContentUpdate(Input):
    title: Name = Field(default=None)
    content_type: ContentType = Field(default=None)
    file_url: URLString | None = Field(default=None)
    thumbnail_url: URLString | None = Field(default=None)
    description: str | None = Field(default=None)
    status: AssetStatus = Field(default=None)


class EventProductPlanCreate(Input):
    product_id: ID
    selling_price: Money | None = None
    currency: Currency | None = None
    notes: str | None = None


class EventProductPlanUpdate(Input):
    selling_price: Money | None = Field(default=None)
    currency: Currency | None = Field(default=None)
    notes: str | None = Field(default=None)
    status: EventProductStatus = Field(default=None)


class DemandSignalCreate(Input):
    signal_type: SignalType
    value: Quantity
    source: ShortText | None = None
    observed_at: AwareDatetime
    notes: str | None = None


class VendorCreate(Input):
    name: Name
    contact: Location | None = None
    website: URLString | None = None
    notes: str | None = None


class VendorUpdate(Input):
    name: Name = Field(default=None)
    contact: Location | None = Field(default=None)
    website: URLString | None = Field(default=None)
    notes: str | None = Field(default=None)
    status: AssetStatus = Field(default=None)


class ProductionBatchCreate(Input):
    vendor_id: ID | None = None
    ordered_quantity: PositiveQuantity
    unit_cost: Money | None = None
    currency: Currency | None = None
    status: BatchStatus = BatchStatus.PLANNED
    expected_at: AwareDatetime | None = None
    notes: str | None = None


class ProductionBatchUpdate(Input):
    vendor_id: ID | None = Field(default=None)
    ordered_quantity: PositiveQuantity = Field(default=None)
    unit_cost: Money | None = Field(default=None)
    currency: Currency | None = Field(default=None)
    status: BatchStatus = Field(default=None)
    expected_at: AwareDatetime | None = Field(default=None)
    notes: str | None = Field(default=None)
    received_quantity: Quantity | None = Field(default=None)
    ordered_at: AwareDatetime | None = Field(default=None)
    received_at: AwareDatetime | None = Field(default=None)


class SampleRoundCreate(Input):
    round_number: RoundNumber
    status: SampleStatus = SampleStatus.PENDING
    submitted_at: AwareDatetime | None = None
    sample_cost: Money | None = None
    currency: Currency | None = None
    notes: str | None = None


class SampleRoundUpdate(Input):
    round_number: RoundNumber = Field(default=None)
    status: SampleStatus = Field(default=None)
    submitted_at: AwareDatetime | None = Field(default=None)
    sample_cost: Money | None = Field(default=None)
    currency: Currency | None = Field(default=None)
    notes: str | None = Field(default=None)
    received_at: AwareDatetime | None = Field(default=None)


class SalesRecordCreate(Input):
    sale_date: date
    sold_quantity: Quantity
    notes: str | None = None


class SalesRecordUpdate(Input):
    sale_date: date = Field(default=None)
    sold_quantity: Quantity = Field(default=None)
    notes: str | None = Field(default=None)


class TaskCreate(Input):
    title: TaskTitle
    task_type: TaskType
    event_product_plan_id: ID | None = None
    due_at: AwareDatetime | None = None
    notes: str | None = None


class TaskUpdate(Input):
    title: TaskTitle = Field(default=None)
    task_type: TaskType = Field(default=None)
    event_product_plan_id: ID | None = Field(default=None)
    due_at: AwareDatetime | None = Field(default=None)
    notes: str | None = Field(default=None)
    status: TaskStatus = Field(default=None)


class InventoryAllocationUpsert(Input):
    allocated_quantity: Quantity
    notes: str | None = None


class FinalDecisionUpdate(Input):
    final_production_quantity: Quantity
    decision_note: str | None = None


class EventRecommendationRequest(Input):
    ip: ShortText | None = None
    preferred_cities: list[ShortText] = Field(default_factory=list)
    available_from: date | None = None
    available_to: date | None = None


class EmptyRequest(Input):
    pass

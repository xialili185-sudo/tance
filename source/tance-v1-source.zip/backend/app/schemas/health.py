from typing import Literal
from pydantic import BaseModel


class HealthResponse(BaseModel):
    status: Literal["ok", "error"]
    service: str
    database: Literal["not_checked", "connected", "unavailable"] = "not_checked"
    llm: Literal["disabled", "configured", "missing_configuration"] = "disabled"

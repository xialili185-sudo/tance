from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.enums import SignalType
from app.schemas.resources import DemandSignalCreate
from app.schemas.common import Items
from app.schemas.responses import DemandReadinessResponse, DemandSignalResponse
from app.services.demand import DemandService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["demand"])


@router.post(
    "/event-product-plans/{plan_id}/demand-signals",
    response_model=DemandSignalResponse,
    status_code=201,
)
def add_signal(db: DB, plan_id: PathID, data: DemandSignalCreate):
    return DemandService(db).add_signal(plan_id, data)


@router.get(
    "/event-product-plans/{plan_id}/demand-signals",
    response_model=Items[DemandSignalResponse],
    status_code=200,
)
def list_signals(db: DB, plan_id: PathID, signal_type: SignalType | None = None):
    return DemandService(db).list_signals(plan_id, signal_type)


@router.delete("/demand-signals/{signal_id}", response_model=None, status_code=204)
def delete_signal(db: DB, signal_id: PathID):
    DemandService(db).delete_signal(signal_id)
    return Response(status_code=204)


@router.get(
    "/event-product-plans/{plan_id}/demand-readiness",
    response_model=DemandReadinessResponse,
    status_code=200,
)
def get_readiness(db: DB, plan_id: PathID):
    return DemandService(db).get_readiness(plan_id)

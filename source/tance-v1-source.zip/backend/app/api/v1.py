from fastapi import APIRouter

router = APIRouter(prefix="/api/v1")
from app.api.events import router as events_router

router.include_router(events_router)
from app.api.products import router as products_router

router.include_router(products_router)
from app.api.contents import router as contents_router

router.include_router(contents_router)
from app.api.production import router as production_router

router.include_router(production_router)
from app.api.event_products import router as event_products_router

router.include_router(event_products_router)
from app.api.demand import router as demand_router

router.include_router(demand_router)
from app.api.recommendations import router as recommendations_router

router.include_router(recommendations_router)
from app.api.inventory import router as inventory_router

router.include_router(inventory_router)
from app.api.sales import router as sales_router

router.include_router(sales_router)
from app.api.tasks import router as tasks_router

router.include_router(tasks_router)
from app.api.event_listings import router as event_listings_router

router.include_router(event_listings_router)
from app.api.dashboard import router as dashboard_router

router.include_router(dashboard_router)

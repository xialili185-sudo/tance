from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from app.ai.client import configuration_status
from app.config import get_settings
from app.db.session import get_db
from app.schemas.health import HealthResponse

router = APIRouter(tags=["Environment"])


@router.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(
        status="ok", service="tance-api", llm=configuration_status(get_settings())
    )


@router.get("/health/ready", response_model=HealthResponse)
def ready(db: Session = Depends(get_db)) -> HealthResponse:
    try:
        db.execute(text("SELECT 1"))
    except SQLAlchemyError:
        raise HTTPException(
            status_code=503, detail="MySQL unavailable; check local service and .env."
        ) from None
    return HealthResponse(
        status="ok",
        service="tance-api",
        database="connected",
        llm=configuration_status(get_settings()),
    )

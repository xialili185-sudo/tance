from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.enums import RegistrationStatus
from app.schemas.resources import EmptyRequest, EventRecommendationRequest
from app.schemas.common import Listing
from app.schemas.responses import (
    EventListingDetailResponse,
    EventListingSummaryResponse,
    EventRecommendationResponse,
    EventResponse,
)
from app.services.event_listings import EventRecommendationService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["event_listings"])


@router.get(
    "/event-listings",
    response_model=Listing[EventListingSummaryResponse],
    status_code=200,
)
def list_event_listings(
    db: DB,
    city: str | None = None,
    registration_status: RegistrationStatus | None = None,
    available_from: date | None = None,
    available_to: date | None = None,
):
    return EventRecommendationService(db).list_event_listings(
        city=city,
        registration_status=registration_status,
        available_from=available_from,
        available_to=available_to,
    )


@router.get(
    "/event-listings/{event_listing_id}",
    response_model=EventListingDetailResponse,
    status_code=200,
)
def get_event_listing(db: DB, event_listing_id: PathID):
    return EventRecommendationService(db).get_event_listing(event_listing_id)


@router.post(
    "/event-recommendations",
    response_model=EventRecommendationResponse,
    status_code=200,
)
def recommend_events(db: DB, data: EventRecommendationRequest):
    return EventRecommendationService(db).recommend_events(data)


@router.post(
    "/event-listings/{event_listing_id}/add-to-plan",
    response_model=EventResponse,
    status_code=201,
)
def add_listing_to_plan(
    db: DB, event_listing_id: PathID, data: EmptyRequest | None = None
):
    return EventRecommendationService(db).add_listing_to_plan(event_listing_id)

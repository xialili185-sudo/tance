from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.enums import AssetStatus, ContentType
from app.schemas.resources import ContentCreate, ContentUpdate
from app.schemas.common import Items, Listing
from app.schemas.responses import (
    ContentDetailResponse,
    ContentResponse,
    ContentSummaryResponse,
    LinkedProductResponse,
)
from app.services.contents import ContentService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["contents"])


@router.post("/contents", response_model=ContentResponse, status_code=201)
def create_content(db: DB, data: ContentCreate):
    return ContentService(db).create_content(data)


@router.get(
    "/contents", response_model=Listing[ContentSummaryResponse], status_code=200
)
def list_contents(
    db: DB, status: AssetStatus | None = None, content_type: ContentType | None = None
):
    return ContentService(db).list_contents(status, content_type)


@router.get(
    "/contents/{content_id}", response_model=ContentDetailResponse, status_code=200
)
def get_content(db: DB, content_id: PathID):
    return ContentService(db).get_content(content_id)


@router.patch("/contents/{content_id}", response_model=ContentResponse, status_code=200)
def update_content(db: DB, content_id: PathID, data: ContentUpdate):
    return ContentService(db).update_content(content_id, data)


@router.delete("/contents/{content_id}", response_model=None, status_code=204)
def delete_content(db: DB, content_id: PathID):
    ContentService(db).delete_content(content_id)
    return Response(status_code=204)


@router.get(
    "/contents/{content_id}/products",
    response_model=Items[LinkedProductResponse],
    status_code=200,
)
def get_content_products(db: DB, content_id: PathID):
    return ContentService(db).get_content_products(content_id)

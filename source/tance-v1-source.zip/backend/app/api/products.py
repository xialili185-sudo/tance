from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.enums import AssetStatus, ProductType
from app.schemas.resources import ProductCreate, ProductUpdate
from app.schemas.common import Items, Listing
from app.schemas.responses import (
    LinkedContentResponse,
    ProductDetailResponse,
    ProductResponse,
    ProductSalesHistoryResponse,
    ProductSummaryResponse,
)
from app.services.products import ProductService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["products"])


@router.post("/products", response_model=ProductResponse, status_code=201)
def create_product(db: DB, data: ProductCreate):
    return ProductService(db).create_product(data)


@router.get(
    "/products", response_model=Listing[ProductSummaryResponse], status_code=200
)
def list_products(
    db: DB, status: AssetStatus | None = None, product_type: ProductType | None = None
):
    return ProductService(db).list_products(status, product_type)


@router.get(
    "/products/{product_id}", response_model=ProductDetailResponse, status_code=200
)
def get_product(db: DB, product_id: PathID):
    return ProductService(db).get_product(product_id)


@router.patch("/products/{product_id}", response_model=ProductResponse, status_code=200)
def update_product(db: DB, product_id: PathID, data: ProductUpdate):
    return ProductService(db).update_product(product_id, data)


@router.delete("/products/{product_id}", response_model=None, status_code=204)
def delete_product(db: DB, product_id: PathID):
    ProductService(db).delete_product(product_id)
    return Response(status_code=204)


@router.get(
    "/products/{product_id}/sales-history",
    response_model=ProductSalesHistoryResponse,
    status_code=200,
)
def get_sales_history(db: DB, product_id: PathID):
    return ProductService(db).get_sales_history(product_id)


@router.get(
    "/products/{product_id}/contents",
    response_model=Items[LinkedContentResponse],
    status_code=200,
)
def get_product_contents(db: DB, product_id: PathID):
    return ProductService(db).get_product_contents(product_id)


@router.post(
    "/products/{product_id}/contents/{content_id}", response_model=None, status_code=204
)
def link_content(db: DB, product_id: PathID, content_id: PathID):
    ProductService(db).link_content(product_id, content_id)
    return Response(status_code=204)


@router.delete(
    "/products/{product_id}/contents/{content_id}", response_model=None, status_code=204
)
def unlink_content(db: DB, product_id: PathID, content_id: PathID):
    ProductService(db).unlink_content(product_id, content_id)
    return Response(status_code=204)

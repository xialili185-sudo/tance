from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db

from app.schemas.resources import SalesRecordCreate, SalesRecordUpdate
from app.schemas.common import Items
from app.schemas.responses import (
    SalesRecordListItem,
    SalesRecordResponse,
    SalesSummaryResponse,
)
from app.services.sales import SalesService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["sales"])


@router.post(
    "/event-product-plans/{plan_id}/sales-records",
    response_model=SalesRecordResponse,
    status_code=201,
)
def create_sales_record(db: DB, plan_id: PathID, data: SalesRecordCreate):
    return SalesService(db).create_sales_record(plan_id, data)


@router.get(
    "/event-product-plans/{plan_id}/sales-records",
    response_model=Items[SalesRecordListItem],
    status_code=200,
)
def list_sales_records(db: DB, plan_id: PathID):
    return SalesService(db).list_sales_records(plan_id)


@router.patch(
    "/sales-records/{sales_record_id}",
    response_model=SalesRecordResponse,
    status_code=200,
)
def update_sales_record(db: DB, sales_record_id: PathID, data: SalesRecordUpdate):
    return SalesService(db).update_sales_record(sales_record_id, data)


@router.delete("/sales-records/{sales_record_id}", response_model=None, status_code=204)
def delete_sales_record(db: DB, sales_record_id: PathID):
    SalesService(db).delete_sales_record(sales_record_id)
    return Response(status_code=204)


@router.get(
    "/event-product-plans/{plan_id}/sales-summary",
    response_model=SalesSummaryResponse,
    status_code=200,
)
def get_sales_summary(db: DB, plan_id: PathID):
    return SalesService(db).get_sales_summary(plan_id)

from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db


from app.schemas.responses import DashboardResponse
from app.services.dashboard import DashboardService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["dashboard"])


@router.get("/dashboard", response_model=DashboardResponse, status_code=200)
def get_dashboard(db: DB):
    return DashboardService(db).get_dashboard()

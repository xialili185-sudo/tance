from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.enums import EventStatus
from app.schemas.resources import EventCreate, EventUpdate
from app.schemas.common import Listing
from app.schemas.responses import (
    EventDetailResponse,
    EventResponse,
    EventSummaryResponse,
)
from app.services.events import EventService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["events"])


@router.post("/events", response_model=EventResponse, status_code=201)
def create_event(db: DB, data: EventCreate):
    return EventService(db).create_event(data)


@router.get("/events", response_model=Listing[EventSummaryResponse], status_code=200)
def list_events(
    db: DB, status: EventStatus | None = None, upcoming: bool | None = None
):
    return EventService(db).list_events(status, upcoming)


@router.get("/events/{event_id}", response_model=EventDetailResponse, status_code=200)
def get_event(db: DB, event_id: PathID):
    return EventService(db).get_event(event_id)


@router.patch("/events/{event_id}", response_model=EventResponse, status_code=200)
def update_event(db: DB, event_id: PathID, data: EventUpdate):
    return EventService(db).update_event(event_id, data)


@router.delete("/events/{event_id}", response_model=None, status_code=204)
def delete_event(db: DB, event_id: PathID):
    EventService(db).delete_event(event_id)
    return Response(status_code=204)

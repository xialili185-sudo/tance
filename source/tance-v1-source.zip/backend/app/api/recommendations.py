from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db

from app.schemas.resources import EmptyRequest, FinalDecisionUpdate
from app.schemas.common import Items
from app.schemas.responses import (
    FinalDecisionResponse,
    QuantityDecisionResponse,
    QuantityDecisionSummaryResponse,
)
from app.services.recommendations import RecommendationService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["recommendations"])


@router.post(
    "/event-product-plans/{plan_id}/recommendations",
    response_model=QuantityDecisionResponse,
    status_code=201,
)
def generate_recommendation(db: DB, plan_id: PathID, data: EmptyRequest | None = None):
    return RecommendationService(db).generate_recommendation(plan_id)


@router.get(
    "/event-product-plans/{plan_id}/recommendations",
    response_model=Items[QuantityDecisionSummaryResponse],
    status_code=200,
)
def get_recommendation_history(db: DB, plan_id: PathID):
    return RecommendationService(db).get_recommendation_history(plan_id)


@router.get(
    "/quantity-decisions/{decision_id}",
    response_model=QuantityDecisionResponse,
    status_code=200,
)
def get_decision(db: DB, decision_id: PathID):
    return RecommendationService(db).get_decision(decision_id)


@router.patch(
    "/quantity-decisions/{decision_id}/final-decision",
    response_model=FinalDecisionResponse,
    status_code=200,
)
def confirm_final_quantity(db: DB, decision_id: PathID, data: FinalDecisionUpdate):
    return RecommendationService(db).confirm_final_quantity(decision_id, data)

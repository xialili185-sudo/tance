from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.enums import AssetStatus
from app.schemas.resources import (
    ProductionBatchCreate,
    ProductionBatchUpdate,
    SampleRoundCreate,
    SampleRoundUpdate,
    VendorCreate,
    VendorUpdate,
)
from app.schemas.common import Items, Listing
from app.schemas.responses import (
    ProductionBatchResponse,
    ProductionBatchSummaryResponse,
    SampleRoundResponse,
    VendorResponse,
)
from app.services.production import ProductionService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["production"])


@router.post("/vendors", response_model=VendorResponse, status_code=201)
def create_vendor(db: DB, data: VendorCreate):
    return ProductionService(db).create_vendor(data)


@router.get("/vendors", response_model=Listing[VendorResponse], status_code=200)
def list_vendors(db: DB, status: AssetStatus | None = None):
    return ProductionService(db).list_vendors(status)


@router.get("/vendors/{vendor_id}", response_model=VendorResponse, status_code=200)
def get_vendor(db: DB, vendor_id: PathID):
    return ProductionService(db).get_vendor(vendor_id)


@router.patch("/vendors/{vendor_id}", response_model=VendorResponse, status_code=200)
def update_vendor(db: DB, vendor_id: PathID, data: VendorUpdate):
    return ProductionService(db).update_vendor(vendor_id, data)


@router.delete("/vendors/{vendor_id}", response_model=None, status_code=204)
def delete_vendor(db: DB, vendor_id: PathID):
    ProductionService(db).delete_vendor(vendor_id)
    return Response(status_code=204)


@router.post(
    "/products/{product_id}/production-batches",
    response_model=ProductionBatchResponse,
    status_code=201,
)
def create_batch(db: DB, product_id: PathID, data: ProductionBatchCreate):
    return ProductionService(db).create_batch(product_id, data)


@router.get(
    "/products/{product_id}/production-batches",
    response_model=Items[ProductionBatchSummaryResponse],
    status_code=200,
)
def list_product_batches(db: DB, product_id: PathID):
    return ProductionService(db).list_product_batches(product_id)


@router.get(
    "/production-batches/{batch_id}",
    response_model=ProductionBatchResponse,
    status_code=200,
)
def get_batch(db: DB, batch_id: PathID):
    return ProductionService(db).get_batch(batch_id)


@router.patch(
    "/production-batches/{batch_id}",
    response_model=ProductionBatchResponse,
    status_code=200,
)
def update_batch(db: DB, batch_id: PathID, data: ProductionBatchUpdate):
    return ProductionService(db).update_batch(batch_id, data)


@router.delete("/production-batches/{batch_id}", response_model=None, status_code=204)
def delete_batch(db: DB, batch_id: PathID):
    ProductionService(db).delete_batch(batch_id)
    return Response(status_code=204)


@router.post(
    "/production-batches/{batch_id}/sample-rounds",
    response_model=SampleRoundResponse,
    status_code=201,
)
def create_sample_round(db: DB, batch_id: PathID, data: SampleRoundCreate):
    return ProductionService(db).create_sample_round(batch_id, data)


@router.get(
    "/production-batches/{batch_id}/sample-rounds",
    response_model=Items[SampleRoundResponse],
    status_code=200,
)
def list_sample_rounds(db: DB, batch_id: PathID):
    return ProductionService(db).list_sample_rounds(batch_id)


@router.patch(
    "/sample-rounds/{sample_id}", response_model=SampleRoundResponse, status_code=200
)
def update_sample_round(db: DB, sample_id: PathID, data: SampleRoundUpdate):
    return ProductionService(db).update_sample_round(sample_id, data)


@router.delete("/sample-rounds/{sample_id}", response_model=None, status_code=204)
def delete_sample_round(db: DB, sample_id: PathID):
    ProductionService(db).delete_sample_round(sample_id)
    return Response(status_code=204)

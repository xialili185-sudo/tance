from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db

from app.schemas.resources import EventProductPlanCreate, EventProductPlanUpdate
from app.schemas.common import Listing
from app.schemas.responses import (
    EventProductPlanDetailResponse,
    EventProductPlanResponse,
    EventProductPlanSummaryResponse,
)
from app.services.event_products import EventProductService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["event_products"])


@router.post(
    "/events/{event_id}/product-plans",
    response_model=EventProductPlanResponse,
    status_code=201,
)
def create_plan(db: DB, event_id: PathID, data: EventProductPlanCreate):
    return EventProductService(db).create_plan(event_id, data)


@router.get(
    "/events/{event_id}/product-plans",
    response_model=Listing[EventProductPlanSummaryResponse],
    status_code=200,
)
def list_event_products(db: DB, event_id: PathID):
    return EventProductService(db).list_event_products(event_id)


@router.get(
    "/event-product-plans/{plan_id}",
    response_model=EventProductPlanDetailResponse,
    status_code=200,
)
def get_plan(db: DB, plan_id: PathID):
    return EventProductService(db).get_plan(plan_id)


@router.patch(
    "/event-product-plans/{plan_id}",
    response_model=EventProductPlanResponse,
    status_code=200,
)
def update_plan(db: DB, plan_id: PathID, data: EventProductPlanUpdate):
    return EventProductService(db).update_plan(plan_id, data)


@router.delete("/event-product-plans/{plan_id}", response_model=None, status_code=204)
def delete_plan(db: DB, plan_id: PathID):
    EventProductService(db).delete_plan(plan_id)
    return Response(status_code=204)

from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db

from app.schemas.resources import InventoryAllocationUpsert
from app.schemas.responses import InventoryAllocationResponse
from app.services.inventory import InventoryService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["inventory"])


@router.get(
    "/event-product-plans/{plan_id}/inventory-allocation",
    response_model=InventoryAllocationResponse,
    status_code=200,
)
def get_allocation(db: DB, plan_id: PathID):
    return InventoryService(db).get_allocation(plan_id)


@router.put(
    "/event-product-plans/{plan_id}/inventory-allocation",
    response_model=InventoryAllocationResponse,
    status_code=200,
)
def upsert_allocation(db: DB, plan_id: PathID, data: InventoryAllocationUpsert):
    return InventoryService(db).upsert_allocation(plan_id, data)


@router.delete(
    "/event-product-plans/{plan_id}/inventory-allocation",
    response_model=None,
    status_code=204,
)
def delete_allocation(db: DB, plan_id: PathID):
    InventoryService(db).delete_allocation(plan_id)
    return Response(status_code=204)

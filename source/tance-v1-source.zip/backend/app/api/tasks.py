from datetime import date
from typing import Annotated
from fastapi import APIRouter, Depends, Path, Response
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.core.enums import TaskStatus, TaskType
from app.schemas.resources import TaskCreate, TaskUpdate
from app.schemas.common import Items
from app.schemas.responses import TaskListItem, TaskResponse
from app.services.tasks import TaskService

PathID = Annotated[int, Path(gt=0, le=9223372036854775807)]
DB = Annotated[Session, Depends(get_db)]
router = APIRouter(tags=["tasks"])


@router.post("/events/{event_id}/tasks", response_model=TaskResponse, status_code=201)
def create_task(db: DB, event_id: PathID, data: TaskCreate):
    return TaskService(db).create_task(event_id, data)


@router.get(
    "/events/{event_id}/tasks", response_model=Items[TaskListItem], status_code=200
)
def list_event_tasks(
    db: DB,
    event_id: PathID,
    status: TaskStatus | None = None,
    task_type: TaskType | None = None,
):
    return TaskService(db).list_event_tasks(event_id, status, task_type)


@router.get(
    "/event-product-plans/{plan_id}/tasks",
    response_model=Items[TaskListItem],
    status_code=200,
)
def list_plan_tasks(db: DB, plan_id: PathID):
    return TaskService(db).list_plan_tasks(plan_id)


@router.patch("/tasks/{task_id}", response_model=TaskResponse, status_code=200)
def update_task(db: DB, task_id: PathID, data: TaskUpdate):
    return TaskService(db).update_task(task_id, data)


@router.delete("/tasks/{task_id}", response_model=None, status_code=204)
def delete_task(db: DB, task_id: PathID):
    TaskService(db).delete_task(task_id)
    return Response(status_code=204)

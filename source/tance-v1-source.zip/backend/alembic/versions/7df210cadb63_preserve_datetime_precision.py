"""Preserve timezone-normalized instants without MySQL whole-second rounding.

Revision ID: 7df210cadb63
Revises: 2236f18de4de
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql

revision = "7df210cadb63"
down_revision = "2236f18de4de"
branch_labels = None
depends_on = None

# Explicit historical schema; migration does not import evolving application models.
TIMES = {
    "products": {"created_at": False, "updated_at": False},
    "contents": {"created_at": False, "updated_at": False},
    "event_listings": {
        "application_deadline": True,
        "created_at": False,
        "updated_at": False,
    },
    "event_plans": {
        "application_deadline": True,
        "created_at": False,
        "updated_at": False,
    },
    "event_product_plans": {"created_at": False, "updated_at": False},
    "demand_signals": {"observed_at": False, "created_at": False},
    "quantity_decisions": {"created_at": False, "confirmed_at": True},
    "vendors": {"created_at": False, "updated_at": False},
    "production_batches": {
        "ordered_at": True,
        "expected_at": True,
        "received_at": True,
        "created_at": False,
        "updated_at": False,
    },
    "sample_rounds": {"submitted_at": True, "received_at": True, "created_at": False},
    "inventory_allocations": {"created_at": False, "updated_at": False},
    "sales_records": {"created_at": False, "updated_at": False},
    "tasks": {
        "due_at": True,
        "completed_at": True,
        "created_at": False,
        "updated_at": False,
    },
}


def upgrade():
    for table, columns in TIMES.items():
        for name, nullable in columns.items():
            op.alter_column(
                table,
                name,
                existing_type=sa.DateTime(),
                type_=mysql.DATETIME(fsp=6),
                existing_nullable=nullable,
            )


def downgrade():
    # Downgrade intentionally loses subsecond precision; never run on user data casually.
    for table, columns in TIMES.items():
        for name, nullable in columns.items():
            op.alter_column(
                table,
                name,
                existing_type=mysql.DATETIME(fsp=6),
                type_=sa.DateTime(),
                existing_nullable=nullable,
            )

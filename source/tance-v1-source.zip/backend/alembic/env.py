from alembic import context
from sqlalchemy import create_engine, pool
from app.config import get_settings
from app.db.base import Base
import app.models  # noqa: F401 - registers finalized ORM metadata

target_metadata = Base.metadata

if context.is_offline_mode():
    context.configure(
        url=get_settings().database_url(),
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
    )
    with context.begin_transaction():
        context.run_migrations()
else:
    connection = context.config.attributes.get("connection")
    engine = None
    if connection is None:
        engine = create_engine(get_settings().database_url(), poolclass=pool.NullPool)
        connection = engine.connect()
    try:
        context.configure(
            connection=connection, target_metadata=target_metadata, compare_type=True
        )
        with context.begin_transaction():
            context.run_migrations()
    finally:
        if engine is not None:
            connection.close()
            engine.dispose()

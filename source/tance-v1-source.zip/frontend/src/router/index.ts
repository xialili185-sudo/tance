import {createRouter,createWebHistory} from 'vue-router'
import Dashboard from '../views/DashboardView.vue'
export default createRouter({history:createWebHistory(),routes:[
  {path:'/',redirect:'/dashboard'},
  {path:'/dashboard',component:Dashboard},
  {path:'/events',component:()=>import('../views/EventsView.vue')},
  {path:'/events/:eventId',component:()=>import('../views/EventDetailView.vue')},
  {path:'/events/:eventId/products/:planId',component:()=>import('../views/PlanDetailView.vue')},
  {path:'/products',component:()=>import('../views/ProductsView.vue')},
  {path:'/products/:productId',component:()=>import('../views/ProductsView.vue')},
  {path:'/contents',component:()=>import('../views/ContentsView.vue')},
  {path:'/production',component:()=>import('../views/ProductionView.vue')},
  {path:'/environment',component:()=>import('../views/EnvironmentView.vue')},
  {path:'/:pathMatch(.*)*',redirect:'/dashboard'},
]})

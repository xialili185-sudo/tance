<script setup lang="ts">
import {computed} from 'vue'
import {useWorkspace} from '../stores/workspace'
import {dateRange,daysBetween} from '../utils/format'
import PageHeader from '../components/common/PageHeader.vue'
import Icon from '../components/common/Icon.vue'
import Badge from '../components/common/Badge.vue'
import ProductArt from '../components/common/ProductArt.vue'
import AttentionList from '../components/AttentionList.vue'
import TaskList from '../components/TaskList.vue'
const s=useWorkspace(),event=computed(()=>s.nextEvent),stats=computed(()=>event.value?s.eventStats(event.value.id):null)
const productionCount=(status:string)=>s.data.batches.filter(b=>b.status===status).length
</script>
<template>
  <PageHeader eyebrow="YOUR CREATIVE WORKSPACE" :title="event?'每一份喜欢，都值得好好准备。':'你好，欢迎来到摊策。'" :description="event?'从灵感到出摊，一起把准备变得更从容。':'从一个参展计划开始，让创作与热爱慢慢落地。'"><button class="btn" @click="s.open({type:'event'})"><Icon name="plus" :size="16"/>新建参展计划</button></PageHeader>
  <template v-if="event&&stats">
    <div class="two-col dashboard-main">
      <div class="stack">
        <section class="hero-event" :class="{'completed-hero':event.status==='COMPLETED'}">
          <div><p class="hero-kicker"><Icon :name="event.status==='COMPLETED'?'circleCheck':'calendar'" :size="14"/>{{event.status==='COMPLETED'?'POST-EVENT REVIEW':'YOUR NEXT EVENT'}}</p><h2>{{event.name}}</h2><div class="hero-details"><span><Icon name="calendar" :size="13"/>{{dateRange(event.startDate,event.endDate)}}</span><span><Icon name="pin" :size="13"/>{{event.location}}</span></div><div class="hero-actions"><RouterLink :to="`/events/${event.id}`" class="btn primary">{{event.status==='COMPLETED'?'查看展会复盘':'进入参展计划'}}<Icon name="arrow" :size="15"/></RouterLink><Badge :status="event.status"/></div></div>
          <div class="countdown"><svg viewBox="0 0 120 120"><circle cx="60" cy="60" r="53" stroke="#cedcf3" stroke-width="3" fill="#ffffff55"/><circle cx="60" cy="60" r="53" stroke="#789ce0" stroke-width="3" fill="none" stroke-dasharray="225 333" stroke-linecap="round"/></svg><small>{{event.status==='COMPLETED'?'本场共售出':event.status==='IN_PROGRESS'?'正在开展':'距离开展还有'}}</small><strong>{{event.status==='COMPLETED'?stats.sold:event.status==='IN_PROGRESS'?'DAY 1':Math.max(0,daysBetween(event.startDate,s.today))}}</strong><small>{{event.status==='COMPLETED'?'件作品':'与你的热爱见面'}}</small></div>
        </section>
        <section v-if="event.status!=='COMPLETED'" class="panel"><div class="panel-header"><h2>现在，需要你留意 <span class="counter">{{s.issues(event.id).length}}</span></h2><span class="muted text-xs">一步一步，准备就绪</span></div><AttentionList :event-id="event.id"/></section>
        <section v-else class="panel panel-pad"><div class="row-between"><h2>这一次出摊，辛苦了</h2><Badge status="COMPLETED"/></div><div class="stat-grid section-gap" style="grid-template-columns:repeat(3,1fr)"><div class="stat-card"><label>售出作品</label><strong>{{stats.sold}}</strong></div><div class="stat-card"><label>本场余货</label><strong>{{stats.remaining}}</strong></div><div class="stat-card"><label>已录销量</label><strong>{{stats.recorded}} <small>/ {{stats.count}}</small></strong></div></div><p class="muted text-sm section-gap">已记录的销售结果会成为下一次再贩的参考。还有 {{stats.count-stats.recorded}} 件商品待补充销售记录。</p></section>
        <section class="panel"><div class="panel-header"><h2>最近的创作商品</h2><RouterLink class="text-link neutral" to="/products">查看全部<Icon name="arrow" :size="14"/></RouterLink></div><div class="recent-grid"><RouterLink v-for="p in s.data.products.slice(0,4)" :key="p.id" class="recent-card" :to="`/products/${p.id}`"><ProductArt :color="p.color" :mark="p.mark" :type="p.type"/><h3>{{p.name}}</h3><p><span>{{p.type}}</span><span>库存 {{s.stock(p.id)}}</span></p></RouterLink></div></section>
      </div>
      <div class="stack dashboard-side">
        <section class="panel"><div class="panel-header"><h2>{{event.status==='COMPLETED'?'本场记录':'筹备进度'}}</h2><Badge :status="event.status"/></div><div class="panel-pad" style="padding-top:0"><div class="row-between" style="align-items:end"><div class="text-large">{{stats.ready}}<span class="muted" style="font-size:16px;font-weight:400"> / {{stats.count}}</span></div><span class="muted text-xs">商品已准备就绪</span></div><div class="progress-bar" style="margin:17px 0 20px"><span :style="{width:`${stats.count?stats.ready/stats.count*100:0}%`}"></span></div><div class="definition-row"><span>需求数据已收集</span><strong>{{stats.demand}} / {{stats.count}}</strong></div><div class="definition-row" style="margin-bottom:0"><span>生产准备已完成</span><strong>{{stats.production}} / {{stats.count}}</strong></div></div></section>
        <section class="panel"><div class="panel-header"><h2>接下来的时间节点</h2><RouterLink class="text-link neutral" :to="`/events/${event.id}?tab=deadlines`"><Icon name="arrow" :size="16"/></RouterLink></div><TaskList :event-id="event.id" compact/><p v-if="!s.tasks(event.id).some(t=>t.status!=='DONE')" class="empty-inline muted">所有筹备任务已完成</p></section>
        <section class="panel"><div class="panel-header"><h2>生产进行时</h2><RouterLink to="/production" class="text-link neutral"><Icon name="arrow" :size="16"/></RouterLink></div><div class="production-mini"><div><strong>{{productionCount('SAMPLING')}}</strong><label>打样中</label></div><div><strong>{{productionCount('PRODUCING')+productionCount('ORDERED')}}</strong><label>生产中</label></div><div><strong>{{productionCount('SHIPPED')}}</strong><label>运输中</label></div></div><div class="production-caption"><Icon name="info" :size="13"/>商品确认收货后，才会计入可用库存</div></section>
      </div>
    </div>
    <section class="panel section-gap"><div class="panel-header"><h2>让下一步更简单</h2><span class="muted text-xs">QUICK ACTIONS</span></div><div class="quick-grid"><button class="quick-action" @click="s.open({type:'product'})"><Icon name="box"/>新建商品</button><button class="quick-action" @click="s.open({type:'content'})"><Icon name="image"/>记录新作品</button><button class="quick-action" @click="s.open({type:'recommend'})"><Icon name="sparkle"/>发现下一场展会</button></div></section>
  </template>
  <template v-else><section class="panel empty-state"><div class="empty-icon"><Icon name="calendar" :size="28"/></div><h2>下一次出摊，从这里开始</h2><p>已经有心仪的展会？创建一个计划。还在寻找？告诉摊策你的创作主题和目的地。</p><div class="inline-actions"><button class="btn primary" @click="s.open({type:'event'})"><Icon name="plus" :size="17"/>创建参展计划</button><button class="btn soft" @click="s.open({type:'recommend'})"><Icon name="sparkle" :size="17"/>帮我找一场展会</button></div></section><section class="panel section-gap"><div class="panel-header"><h2>你的创作，随时准备出发</h2><RouterLink class="text-link" to="/products">查看商品<Icon name="arrow" :size="15"/></RouterLink></div><div class="recent-grid"><RouterLink v-for="p in s.data.products.slice(0,4)" :key="p.id" :to="`/products/${p.id}`" class="recent-card"><ProductArt :color="p.color" :mark="p.mark" :type="p.type"/><h3>{{p.name}}</h3></RouterLink></div></section></template>
  <p class="page-footnote">把不确定留给灵感，把准备交给摊策。 · TANCE</p>
</template>

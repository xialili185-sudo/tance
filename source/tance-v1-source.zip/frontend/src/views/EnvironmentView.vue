<script setup lang="ts">
import { onMounted } from 'vue'
import { useEnvironmentStore } from '../stores/environment'
const env = useEnvironmentStore()
onMounted(env.refresh)
</script>
<template>
  <main>
    <header><span class="brand">TANCE <small>摊策</small></span><span class="pill">LOCAL DEVELOPMENT</span></header>
    <h1>开发环境检查</h1><p class="intro">检查 Vue → Axios → FastAPI → MySQL 的本地连接。</p>
    <section aria-live="polite">
      <div><h2>前端工作区</h2><span class="ok">✓ 已启动</span></div>
      <p>Vue 3 · TypeScript · Vite · Vue Router · Pinia · Axios</p>
      <hr><div><h2>后端与数据库</h2><span :class="env.result ? 'ok' : 'pending'">{{env.loading ? '检查中…' : env.result ? '✓ 已连通' : '未连接'}}</span></div>
      <p>{{env.error || (env.result ? 'FastAPI 已响应，MySQL 查询成功。' : '等待本地服务响应。')}}</p>
      <hr><div><h2>LLM 解释服务</h2><span class="pending">{{env.result?.llm === 'configured' ? '已填写配置，尚未验证调用' : env.result?.llm === 'missing_configuration' ? '配置未完整' : '暂未启用'}}</span></div>
      <p>选定供应商后，在项目 .env 中填写模型和密钥；核心开发不依赖 LLM。</p>
      <footer><button @click="env.refresh" :disabled="env.loading">{{env.loading ? '检查中…' : '重新检查连接'}}</button><a href="http://127.0.0.1:8000/docs" target="_blank" rel="noopener">打开 API 文档 ↗</a></footer>
    </section>
    <p class="note">这是环境连通检查页。业务页面将在此基础上开发。</p>
  </main>
</template>
<style scoped>
main{max-width:820px;margin:0 auto;padding:56px 24px}header{display:flex;justify-content:space-between;align-items:center;gap:16px}.brand{font-weight:850;font-size:24px;letter-spacing:.04em}.brand small{font-weight:500;font-size:15px;color:#5b6980;margin-left:12px}.pill{font-size:12px;letter-spacing:.08em;background:#e1eaff;color:#2e5aac;padding:5px 10px;border-radius:6px}h1{font-size:32px;margin:44px 0 6px}.intro{color:#5b6980;margin:0 0 28px}section{background:#fff;padding:30px;border:1px solid #e2e8f0;border-radius:16px;box-shadow:0 10px 36px #18345406}section>div{display:flex;align-items:center;justify-content:space-between;gap:14px}h2{font-size:17px;margin:0}section p{color:#66748b;margin:8px 0 18px;font-size:14px}hr{border:0;border-top:1px solid #e9edf4;margin:24px 0}.ok{color:#16734a;font-size:14px}.pending{color:#8c6529;font-size:14px}footer{display:flex;gap:22px;align-items:center;margin-top:30px}button{border:0;border-radius:8px;padding:11px 19px;background:#245dde;color:#fff}a{font-size:14px}.note{font-size:13px;color:#738095;margin-top:20px}@media(max-width:540px){main{padding:28px 18px}section{padding:22px}.pill{font-size:10px}footer{flex-wrap:wrap}section>div{align-items:flex-start}}
</style>

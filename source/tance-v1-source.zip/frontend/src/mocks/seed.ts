import type { Data, Scene, Listing } from '../types/domain'
export const scenes: {id:Scene;label:string}[] = [
  {id:'preparing',label:'筹备中 · 完整工作台'}, {id:'cold',label:'新用户 · 发现展会'},
  {id:'limited',label:'再贩 · 缺少新印调'}, {id:'recovery',label:'再贩 · 当前热度回升'},
  {id:'sufficient',label:'库存充足 · 无需生产'}, {id:'live',label:'开展中 · 记录销量'},
  {id:'completed',label:'已结束 · 销售复盘'}, {id:'fallback',label:'解释失败 · 数量可用'},
]
export const listings:Listing[] = [
  {id:'listing-1',name:'CP32 · COMICUP',location:'上海 · 国家会展中心',startDate:'2026-10-24',endDate:'2026-10-25',deadline:'2026-09-30',status:'OPEN',themes:['逆转裁判','原神','综合同人'],description:'综合同人创作交流展，适合徽章、亚克力与本子。所有日期、报名状态均为演示数据。'},
  {id:'listing-2',name:'星河 ONLY · 秋日场',location:'杭州 · 创意会展馆',startDate:'2026-11-14',endDate:'2026-11-15',deadline:'2026-09-24',status:'CLOSING_SOON',themes:['原神','崩坏：星穹铁道'],description:'面向游戏同人创作者的小型主题交流会。演示展会，不代表真实报名信息。'},
  {id:'listing-3',name:'逆转裁判 ONLY',location:'上海 · 静安创作空间',startDate:'2026-10-10',endDate:'2026-10-10',deadline:'2026-09-10',status:'CLOSED',themes:['逆转裁判'],description:'法庭主题同人交流活动。本示例已截止报名，不能直接加入参展计划。'},
]
export function seed(scene:Scene):Data {
  const data:Data = {
    events:[
      {id:'e1',name:'CP32 · COMICUP',location:'上海 · 国家会展中心',startDate:'2026-10-24',endDate:'2026-10-25',deadline:'2026-09-30',status:'PREPARING',notes:'综合同人展 · 日期及报名信息均为演示数据'},
      {id:'e2',name:'星河 ONLY · 秋日场',location:'杭州 · 创意会展馆',startDate:'2026-11-14',endDate:'2026-11-15',deadline:'2026-09-24',status:'PLANNING',notes:'演示展会'},
      ...['CP29','CP30','CP31'].map((name,i)=>({id:`h${i}`,name,location:'上海',startDate:['2026-02-14','2026-05-16','2026-08-15'][i]!,endDate:['2026-02-15','2026-05-17','2026-08-16'][i]!,deadline:'',status:'COMPLETED' as const,notes:'历史销售示例'})),
    ],
    products:[
      {id:'p1',name:'御剑怜侍 · 午后红茶',type:'徽章',fandom:'逆转裁判',description:'75mm 镭射徽章，午后红茶系列。第三轮销售后，继续观察本场兴趣变化。',price:25,color:'rose',mark:'御剑',status:'ACTIVE',contentIds:['c1']},
      {id:'p2',name:'成步堂龙一 · 蓝色时刻',type:'亚克力',fandom:'逆转裁判',description:'15cm 双面亚克力立牌，含透明底座。',price:45,color:'blue',mark:'蓝调',status:'ACTIVE',contentIds:['c2']},
      {id:'p3',name:'提瓦特来信 · 风之诗',type:'明信片',fandom:'原神',description:'300g 特种纸明信片，四张一组。',price:15,color:'green',mark:'风起',status:'ACTIVE',contentIds:['c3']},
      {id:'p4',name:'星穹漫游 · 晚安银河',type:'色纸',fandom:'崩坏：星穹铁道',description:'迷你色纸，珠光工艺。',price:20,color:'violet',mark:'星河',status:'ACTIVE',contentIds:['c4']},
      {id:'p5',name:'法庭日常 · 异议あり',type:'贴纸',fandom:'逆转裁判',description:'原创对白与小物件主题贴纸包。',price:12,color:'orange',mark:'异议',status:'ACTIVE',contentIds:['c1']},
      {id:'p6',name:'旅途手记 · 夏日终章',type:'本子',fandom:'原神',description:'A5 插画小册，20 页彩色内页。',price:35,color:'yellow',mark:'夏日',status:'ACTIVE',contentIds:['c3']},
    ],
    contents:[
      {id:'c1',title:'午后红茶',type:'插画',tags:'逆转裁判 / 御剑怜侍',color:'rose',mark:'TEA TIME',notes:'暖色午后系列插画'},
      {id:'c2',title:'蓝色时刻',type:'角色设计',tags:'逆转裁判 / 成步堂龙一',color:'blue',mark:'BLUE HOUR',notes:'角色立牌原稿'},
      {id:'c3',title:'风写的信',type:'插画',tags:'原神 / 旅行',color:'green',mark:'DEAR WIND',notes:'旅途风景系列'},
      {id:'c4',title:'晚安，银河',type:'插画',tags:'崩坏：星穹铁道',color:'violet',mark:'GOOD NIGHT',notes:'星空主题创作'},
    ],
    plans:[
      ...[25,45,15,20,12,35].map((price,i)=>({id:`plan${i+1}`,eventId:'e1',productId:`p${i+1}`,price,allocated:[0,0,50,40,30,60][i]!,notes:'',...(i>=2?{finalQuantity:i===2?0:[40,30,60][i-3]}:{})})),
      ...[100,68,45].map((_,i)=>({id:`hp${i}`,eventId:`h${i}`,productId:'p1',price:25,allocated:[100,68,45][i]!,finalQuantity:0,notes:'历史销售'})),
      {id:'hp-acrylic',eventId:'h2',productId:'p2',price:45,allocated:32,finalQuantity:32,notes:''},
    ],
    signals:[
      ...[21,29,38].map((value,i)=>({id:`sig${i}`,planId:'plan1',type:'survey' as const,value,source:'本场印调 · 问卷',observedAt:['2026-09-01','2026-09-10','2026-09-20'][i]!,createdAt:`2026-09-${['01','10','20'][i]}T08:00:00.000Z`,notes:'累计有效意向人数，非新增人数'})),
      {id:'wish1',planId:'plan1',type:'wishlist',value:142,source:'CPP 心愿单',observedAt:'2026-09-20',createdAt:'2026-09-20T08:00:00.000Z',notes:'跨展会累计，可能包含已购买的用户'},
      {id:'social1',planId:'plan1',type:'social',value:86,source:'社媒互动',observedAt:'2026-09-20',createdAt:'2026-09-20T08:00:00.000Z',notes:'只作为辅助证据'},
      {id:'wish2',planId:'plan2',type:'wishlist',value:78,source:'CPP 心愿单',observedAt:'2026-09-18',createdAt:'2026-09-18T08:00:00.000Z',notes:'累计心愿数'},
      ...[3,4,5,6].map((n,i)=>({id:`survey${n}`,planId:`plan${n}`,type:'survey' as const,value:[38,26,20,40][i]!,source:'本场印调',observedAt:'2026-09-19',createdAt:'2026-09-19T08:00:00.000Z',notes:''})),
    ],
    decisions:[{id:'decision1',planId:'plan1',demand:[40,60,80],production:[20,40,60],stock:20,confidence:'MEDIUM',createdAt:'2026-09-21T00:00:00.000Z',notes:'',explanation:'READY',evidenceIds:['sig0','sig1','sig2','wish1','social1'],history:[100,68,45],survey:[21,29,38]},
      ...[3,4,5,6].map((n,i)=>({id:`decision${n}`,planId:`plan${n}`,demand:[40,60,80] as [number,number,number],production:[0,0,10] as [number,number,number],stock:[70,40,30,60][i]!,confidence:'MEDIUM' as const,finalQuantity:[0,40,30,60][i]!,notes:'用户已确认',createdAt:'2026-09-20T00:00:00.000Z',explanation:'READY' as const,evidenceIds:[`survey${n}`],history:[],survey:[[38],[26],[20],[40]][i]!})),
    ],
    batches:[
      ...[233,32,70,40,32,65].map((quantity,i)=>({id:`stock${i+1}`,productId:`p${i+1}`,name:`TC-260${i+1}`,planId:i>=3?`plan${i+1}`:undefined,vendor:'纸间造物',quantity,cost:quantity*5,status:'RECEIVED' as const,expectedAt:'2026-08-01',receivedAt:'2026-08-01',notes:'已到货批次',samples:[]})),
      {id:'batch2',productId:'p2',planId:'plan2',name:'TC-2607',vendor:'蓝鲸工坊',quantity:30,cost:480,status:'SAMPLING',expectedAt:'2026-10-12',notes:'确认色差后下单',samples:[{round:1,date:'2026-09-18',result:'需修改',notes:'底座颜色偏深，已沟通调整'}]},
    ],
    sales:[...[100,68,45].map((quantity,i)=>({id:`sale${i}`,planId:`hp${i}`,date:['2026-02-15','2026-05-17','2026-08-16'][i]!,quantity,notes:'历史展会总销量'})),{id:'sale-acrylic',planId:'hp-acrylic',date:'2026-08-16',quantity:32,notes:''}],
    tasks:[
      {id:'t1',eventId:'e1',planId:'plan2',title:'确认亚克力二次打样',dueAt:'2026-09-24',status:'IN_PROGRESS',notes:'核对底座颜色'},
      {id:'t2',eventId:'e1',planId:'plan1',title:'确认徽章数量并送印',dueAt:'2026-09-28',status:'TODO',notes:''},
      {id:'t3',eventId:'e1',title:'完成摊位申请',dueAt:'2026-09-30',status:'TODO',notes:''},
      {id:'t4',eventId:'e1',title:'核对出摊清单',dueAt:'2026-10-20',status:'TODO',notes:''},
    ],
  }
  // Keep seeded decision arithmetic internally consistent.
  data.decisions.forEach(d=>{ d.production=d.demand.map(v=>Math.max(0,v-d.stock)) as [number,number,number] })
  if(scene==='cold') {
    data.events=[];data.plans=[];data.signals=[];data.decisions=[];data.sales=[];data.tasks=[]
    data.batches=data.batches.filter(b=>b.status==='RECEIVED');data.batches[0]!.quantity=20;data.batches[1]!.quantity=0
  }
  if(scene==='limited') {data.signals=data.signals.filter(s=>s.planId!=='plan1'||s.type==='wishlist');data.decisions=data.decisions.filter(d=>d.planId!=='plan1')}
  if(scene==='sufficient'){data.batches[0]!.quantity+=50;data.decisions[0]!.stock=70;data.decisions[0]!.production=[0,0,10]}
  if(scene==='fallback')data.decisions[0]!.explanation='UNAVAILABLE'
  if(scene==='live'||scene==='completed') {
    data.events[0]!.status=scene==='live'?'IN_PROGRESS':'COMPLETED'
    data.plans[0]!.allocated=50;data.plans[0]!.finalQuantity=40;data.decisions[0]!.finalQuantity=40
    data.batches.push({id:'live-stock',productId:'p1',planId:'plan1',name:'TC-2608',vendor:'纸间造物',quantity:40,cost:200,status:'RECEIVED',expectedAt:'2026-10-15',receivedAt:'2026-10-15',notes:'本轮追加生产',samples:[]})
    data.sales.push({id:'live-sale',planId:'plan1',date:'2026-10-24',quantity:28,notes:'Day 1'})
    if(scene==='completed') {
      data.sales.push({id:'live-sale2',planId:'plan1',date:'2026-10-25',quantity:17,notes:'Day 2'})
      data.plans.filter(p=>p.eventId==='e1'&&p.id!=='plan1').forEach(p=>{if(p.allocated)data.sales.push({id:`finished-${p.id}`,planId:p.id,date:'2026-10-25',quantity:Math.max(0,p.allocated-5),notes:'展会总销量'})})
      data.tasks.forEach(t=>t.status='DONE')
    }
  }
  return data
}

export const money=(n:number)=>`¥${n.toLocaleString('zh-CN')}`
export const shortDate=(v:string)=>v?`${Number(v.slice(5,7))}月${Number(v.slice(8,10))}日`:'未设置'
export const dateRange=(a:string,b:string)=>`${shortDate(a)}${a!==b?' – '+shortDate(b):''}`
export const daysBetween=(a:string,b:string)=>Math.ceil((Date.parse(a+'T12:00:00')-Date.parse(b+'T12:00:00'))/86400000)
export const timeLabel=(v:string)=>new Date(v).toLocaleString('zh-CN',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hour12:false})
export const signalLabels={survey:'本场兴趣印调',wishlist:'累计心愿单',preorder:'预订数量',social:'社媒互动',manual:'人工估计',external:'系统外历史销量'}
export const statusLabels:Record<string,string>={PLANNING:'计划中',PREPARING:'筹备中',IN_PROGRESS:'进行中',COMPLETED:'已结束',PLANNED:'待生产',SAMPLING:'打样中',ORDERED:'已下单',PRODUCING:'生产中',SHIPPED:'已发货',RECEIVED:'已到货',ACTIVE:'使用中',ARCHIVED:'已归档',TODO:'待完成',DONE:'已完成',LOW:'低置信度',MEDIUM:'中置信度',HIGH:'高置信度',OPEN:'可报名',CLOSING_SOON:'即将截止',CLOSED:'报名已结束',READY:'准备就绪',WARNING:'需留意',INCOMPLETE:'待完善',LIMITED:'有限证据',INSUFFICIENT:'数据不足'}

import { api, apiError } from './api'
import { seed } from '../mocks/seed'
import type { Batch, Content, Data, Decision, EventPlan, Plan, Product, Sale, Scene, Signal, Task } from '../types/domain'

type Envelope<T> = { items: T[]; total?: number }
type ApiRecord = Record<string, any>

const productTypeToUi: Record<string, string> = {
  BADGE: '徽章', ACRYLIC_STAND: '亚克力', POSTCARD: '明信片', BOOK: '本子', STICKER: '贴纸', PRINT: '色纸', OTHER: '其他',
}
const productTypeToApi = Object.fromEntries(Object.entries(productTypeToUi).map(([key, value]) => [value, key])) as Record<string, string>
const contentTypeToUi: Record<string, string> = { ILLUSTRATION: '插画', DESIGN: '角色设计', COVER: '封面设计', LOGO: '标识', OTHER: '其他' }
const contentTypeToApi: Record<string, string> = { 插画: 'ILLUSTRATION', 角色设计: 'DESIGN', 平面设计: 'DESIGN', 文本: 'OTHER', 其他: 'OTHER' }
const signalTypeToUi: Record<string, Signal['type']> = {
  EVENT_INTEREST_SURVEY: 'survey', WISHLIST_COUNT: 'wishlist', PREORDER_COUNT: 'preorder', SOCIAL_ENGAGEMENT: 'social', MANUAL_ESTIMATE: 'manual', EXTERNAL_HISTORY: 'external',
}
const signalTypeToApi = Object.fromEntries(Object.entries(signalTypeToUi).map(([key, value]) => [value, key])) as Record<Signal['type'], string>
const colors = ['blue', 'rose', 'green', 'violet', 'orange', 'yellow']

const ident = (value: unknown) => String(value)
const date = (value?: string | null) => value ? value.slice(0, 10) : ''
const at = (value: string) => `${value}T12:00:00.000Z`
const money = (value: unknown) => Number(value ?? 0)
const color = (value: unknown) => colors[Number(value) % colors.length]!
const list = async <T = ApiRecord>(url: string) => (await api.get<Envelope<T>>(url)).data.items

function uiEventStatus(status: string): EventPlan['status'] {
  if (status === 'READY') return 'IN_PROGRESS'
  if (status === 'CANCELLED') return 'COMPLETED'
  return status as EventPlan['status']
}
function apiEventStatus(status: EventPlan['status']) { return status === 'IN_PROGRESS' ? 'READY' : status }
function uiTaskStatus(status: string): Task['status'] { return status === 'OVERDUE' || status === 'CANCELLED' ? 'TODO' : status as Task['status'] }
function uiSampleStatus(status: string) { return ({ APPROVED: '通过', REVISION_REQUIRED: '需修改', REJECTED: '未通过', PENDING: '待确认' } as Record<string, string>)[status] || '待确认' }
function apiSampleStatus(status: string) { return ({ 通过: 'APPROVED', 需修改: 'REVISION_REQUIRED', 未通过: 'REJECTED', 待确认: 'PENDING' } as Record<string, string>)[status] || 'PENDING' }

export interface WorkspaceDataSource { initialData(scene: Scene): Data }
export const mockWorkspaceSource: WorkspaceDataSource = { initialData: seed }

export const backendWorkspaceSource = {
  enabled: import.meta.env.VITE_WORKSPACE_SOURCE === 'api',
  async load(): Promise<Data> {
    try {
      const [eventRows, productRows, contentRows] = await Promise.all([list('/events'), list('/products'), list('/contents')])
      const [eventDetails, productDetails, contentDetails, productContentRows, batchRows] = await Promise.all([
        Promise.all(eventRows.map(row => api.get<ApiRecord>(`/events/${row.event_id}`).then(r => r.data))),
        Promise.all(productRows.map(row => api.get<ApiRecord>(`/products/${row.product_id}`).then(r => r.data))),
        Promise.all(contentRows.map(row => api.get<ApiRecord>(`/contents/${row.content_id}`).then(r => r.data))),
        Promise.all(productRows.map(row => list(`/products/${row.product_id}/contents`))),
        Promise.all(productRows.map(row => list(`/products/${row.product_id}/production-batches`))),
      ])
      const contents: Content[] = contentDetails.map((row, index) => ({ id: ident(row.content_id), title: row.title, type: contentTypeToUi[row.content_type] || '其他', tags: '', color: color(index), mark: row.title.slice(0, 20), notes: row.description || '' }))
      const products: Product[] = productDetails.map((row, index) => ({ id: ident(row.product_id), name: row.name, type: productTypeToUi[row.product_type] || '其他', fandom: '', description: row.description || '', price: money(row.default_selling_price), color: color(index), mark: row.name.slice(0, 6), status: row.status, contentIds: productContentRows[index]!.map((content: ApiRecord) => ident(content.content_id)) }))
      const events: EventPlan[] = eventDetails.map(row => ({ id: ident(row.event_id), name: row.name, location: row.location, startDate: date(row.start_date), endDate: date(row.end_date), deadline: date(row.application_deadline), status: uiEventStatus(row.status), notes: row.notes || '' }))
      const batches: Batch[] = []
      for (let productIndex = 0; productIndex < batchRows.length; productIndex += 1) {
        const productId = products[productIndex]!.id
        const rows = batchRows[productIndex]!
        const samples = await Promise.all(rows.map((row: ApiRecord) => list(`/production-batches/${row.batch_id}/sample-rounds`)))
        rows.forEach((row: ApiRecord, index: number) => batches.push({
          id: ident(row.batch_id), productId, name: `批次 #${row.batch_id}`, vendor: row.vendor_name || '', quantity: Number(row.received_quantity ?? row.ordered_quantity), cost: money(row.unit_cost) * Number(row.ordered_quantity), status: row.status, expectedAt: date(row.expected_at), receivedAt: date(row.received_at) || undefined, notes: '',
          samples: samples[index]!.map((sample: ApiRecord) => ({ round: sample.round_number, date: date(sample.submitted_at || sample.created_at), result: uiSampleStatus(sample.status), notes: sample.notes || '' })),
        }))
      }
      const plansByEvent = await Promise.all(events.map(event => list(`/events/${event.id}/product-plans`)))
      const planRows = plansByEvent.flat()
      const [planDetails, taskRows, signalRows, recommendationRows, allocations, salesRows] = await Promise.all([
        Promise.all(planRows.map((row: ApiRecord) => api.get<ApiRecord>(`/event-product-plans/${row.event_product_plan_id}`).then(r => r.data))),
        Promise.all(events.map(event => list(`/events/${event.id}/tasks`))),
        Promise.all(planRows.map((row: ApiRecord) => list(`/event-product-plans/${row.event_product_plan_id}/demand-signals`))),
        Promise.all(planRows.map((row: ApiRecord) => list(`/event-product-plans/${row.event_product_plan_id}/recommendations`))),
        Promise.all(planRows.map((row: ApiRecord) => api.get<ApiRecord>(`/event-product-plans/${row.event_product_plan_id}/inventory-allocation`).then(r => r.data))),
        Promise.all(planRows.map((row: ApiRecord) => list(`/event-product-plans/${row.event_product_plan_id}/sales-records`))),
      ])
      const decisionDetails = await Promise.all(recommendationRows.flatMap(rows => rows.map((row: ApiRecord) => api.get<ApiRecord>(`/quantity-decisions/${row.decision_id}`).then(r => r.data))))
      const decisionsByPlan = new Map<string, ApiRecord[]>()
      decisionDetails.forEach(row => { const key = ident(row.event_product_plan_id); decisionsByPlan.set(key, [...(decisionsByPlan.get(key) || []), row]) })
      const plans: Plan[] = planRows.map((row: ApiRecord, index: number) => {
        const decision = decisionsByPlan.get(ident(row.event_product_plan_id))?.at(-1)
        return { id: ident(row.event_product_plan_id), eventId: ident(planDetails[index]!.event.event_id), productId: ident(row.product_id), price: money(row.selling_price), allocated: Number(allocations[index]!.allocated_quantity), finalQuantity: decision?.final_production_quantity ?? undefined, notes: row.notes || '' }
      })
      const signals: Signal[] = signalRows.flatMap((rows, index) => rows.map((row: ApiRecord) => ({ id: ident(row.signal_id), planId: ident(planRows[index]!.event_product_plan_id), type: signalTypeToUi[row.signal_type] || 'manual', value: Number(row.value), source: row.source || '', observedAt: date(row.observed_at), createdAt: row.created_at, notes: row.notes || '' })))
      const decisions: Decision[] = decisionDetails.map(row => ({ id: ident(row.decision_id), planId: ident(row.event_product_plan_id), demand: [row.demand.conservative, row.demand.balanced, row.demand.aggressive], production: [row.production.conservative, row.production.balanced, row.production.aggressive], stock: Number(row.current_stock_snapshot), confidence: row.confidence_level, finalQuantity: row.final_production_quantity ?? undefined, notes: row.recommendation_reason || '', createdAt: row.created_at, explanation: row.explanation_status === 'AVAILABLE' ? 'READY' : 'UNAVAILABLE', evidenceIds: signals.filter(signal => signal.planId === ident(row.event_product_plan_id)).map(signal => signal.id), history: [], survey: signals.filter(signal => signal.planId === ident(row.event_product_plan_id) && signal.type === 'survey').map(signal => signal.value) }))
      const sales: Sale[] = salesRows.flatMap((rows, index) => rows.map((row: ApiRecord) => ({ id: ident(row.sales_record_id), planId: ident(planRows[index]!.event_product_plan_id), date: date(row.sale_date), quantity: Number(row.sold_quantity), notes: '' })))
      const tasks: Task[] = taskRows.flatMap((rows, index) => rows.map((row: ApiRecord) => ({ id: ident(row.task_id), eventId: events[index]!.id, planId: row.event_product_plan_id ? ident(row.event_product_plan_id) : undefined, title: row.title, dueAt: date(row.due_at), status: uiTaskStatus(row.display_status || row.status), notes: '' })))
      return { events, products, contents, plans, signals, decisions, batches, sales, tasks }
    } catch (error) { throw apiError(error) }
  },
  async saveEvent(value: Omit<EventPlan, 'id'>, eventId?: string) {
    const payload = { name: value.name, location: value.location, start_date: value.startDate, end_date: value.endDate, application_deadline: value.deadline ? at(value.deadline) : null, notes: value.notes || null }
    if (eventId) await api.patch(`/events/${eventId}`, { ...payload, status: apiEventStatus(value.status) }); else await api.post('/events', payload)
  },
  async saveProduct(value: Omit<Product, 'id'>, productId?: string) {
    const payload = { name: value.name, product_type: productTypeToApi[value.type] || 'OTHER', description: value.description || null, default_selling_price: value.price.toFixed(2), default_currency: 'CNY' }
    const saved = productId ? (await api.patch<ApiRecord>(`/products/${productId}`, { ...payload, status: value.status })).data : (await api.post<ApiRecord>('/products', payload)).data
    const id = ident(saved.product_id); const previous = productId ? (await list(`/products/${id}/contents`)).map((content: ApiRecord) => ident(content.content_id)) : []
    await Promise.all([...previous.filter(contentId => !value.contentIds.includes(contentId)).map(contentId => api.delete(`/products/${id}/contents/${contentId}`)), ...value.contentIds.filter(contentId => !previous.includes(contentId)).map(contentId => api.post(`/products/${id}/contents/${contentId}`))])
    return id
  },
  async saveContent(value: Omit<Content, 'id'>, linkedProductIds: string[], contentId?: string) {
    const payload = { title: value.title, content_type: contentTypeToApi[value.type] || 'OTHER', description: value.notes || null }
    const saved = contentId ? (await api.patch<ApiRecord>(`/contents/${contentId}`, { ...payload, status: 'ACTIVE' })).data : (await api.post<ApiRecord>('/contents', payload)).data
    const id = ident(saved.content_id); const previous = contentId ? (await list(`/contents/${id}/products`)).map((product: ApiRecord) => ident(product.product_id)) : []
    await Promise.all([...previous.filter(productId => !linkedProductIds.includes(productId)).map(productId => api.delete(`/products/${productId}/contents/${id}`)), ...linkedProductIds.filter(productId => !previous.includes(productId)).map(productId => api.post(`/products/${productId}/contents/${id}`))])
  },
  async savePlan(value: Omit<Plan, 'id' | 'allocated'>) { return ident((await api.post<ApiRecord>(`/events/${value.eventId}/product-plans`, { product_id: Number(value.productId), selling_price: value.price.toFixed(2), currency: 'CNY', notes: value.notes || null })).data.event_product_plan_id) },
  async saveSignal(value: Omit<Signal, 'id' | 'createdAt'>) { await api.post(`/event-product-plans/${value.planId}/demand-signals`, { signal_type: signalTypeToApi[value.type], value: value.value, source: value.source || null, observed_at: at(value.observedAt), notes: value.notes || null }) },
  async removeSignal(signalId: string) { await api.delete(`/demand-signals/${signalId}`) },
  async generate(planId: string) { await api.post(`/event-product-plans/${planId}/recommendations`, {}) },
  async confirmQuantity(decisionId: string, quantity: number, notes: string) { await api.patch(`/quantity-decisions/${decisionId}/final-decision`, { final_production_quantity: quantity, decision_note: notes || null }) },
  async allocate(planId: string, quantity: number) { await api.put(`/event-product-plans/${planId}/inventory-allocation`, { allocated_quantity: quantity }) },
  async saveSale(value: Omit<Sale, 'id'>, saleId?: string) { const payload = { sale_date: value.date, sold_quantity: value.quantity, notes: value.notes || null }; if (saleId) await api.patch(`/sales-records/${saleId}`, payload); else await api.post(`/event-product-plans/${value.planId}/sales-records`, payload) },
  async removeSale(saleId: string) { await api.delete(`/sales-records/${saleId}`) },
  async saveTask(value: Omit<Task, 'id'>, taskId?: string) { const payload = { title: value.title, task_type: 'OTHER', event_product_plan_id: value.planId ? Number(value.planId) : null, due_at: value.dueAt ? at(value.dueAt) : null, notes: value.notes || null }; if (taskId) await api.patch(`/tasks/${taskId}`, { ...payload, status: value.status }); else await api.post(`/events/${value.eventId}/tasks`, payload) },
  async removeTask(taskId: string) { await api.delete(`/tasks/${taskId}`) },
  async saveBatch(value: Omit<Batch, 'id' | 'samples'>, batchId?: string) {
    const vendors = await list('/vendors'); let vendorId = vendors.find((vendor: ApiRecord) => vendor.name === value.vendor)?.vendor_id
    if (!vendorId && value.vendor) vendorId = (await api.post<ApiRecord>('/vendors', { name: value.vendor })).data.vendor_id
    const patch = { vendor_id: vendorId || null, ordered_quantity: value.quantity, unit_cost: (value.cost / value.quantity).toFixed(2), currency: 'CNY', expected_at: value.expectedAt ? at(value.expectedAt) : null, notes: value.notes || null }
    if (batchId) { await api.patch(`/production-batches/${batchId}`, { ...patch, status: value.status, ...(value.status === 'RECEIVED' ? { received_quantity: value.quantity, received_at: at(value.receivedAt || value.expectedAt) } : {}) }); return }
    const created = (await api.post<ApiRecord>(`/products/${value.productId}/production-batches`, { ...patch, status: 'PLANNED' })).data; const id = ident(created.batch_id)
    if (value.status === 'SAMPLING') await api.patch(`/production-batches/${id}`, { status: 'SAMPLING' })
    if (['ORDERED', 'PRODUCING', 'SHIPPED', 'RECEIVED'].includes(value.status)) {
      await api.patch(`/production-batches/${id}`, { ...patch, status: 'ORDERED', ordered_at: at(value.expectedAt) })
      if (value.status === 'PRODUCING') await api.patch(`/production-batches/${id}`, { status: 'PRODUCING' })
      if (value.status === 'SHIPPED') await api.patch(`/production-batches/${id}`, { status: 'SHIPPED' })
      if (value.status === 'RECEIVED') await api.patch(`/production-batches/${id}`, { status: 'RECEIVED', received_quantity: value.quantity, received_at: at(value.receivedAt || value.expectedAt) })
    }
  },
  async addSample(batchId: string, sample: { round: number; date: string; result: string; notes: string }) { await api.post(`/production-batches/${batchId}/sample-rounds`, { round_number: sample.round, status: apiSampleStatus(sample.result), submitted_at: at(sample.date), notes: sample.notes || null }) },
}

import axios from 'axios'
import type { HealthResponse } from '../types/api'

const timeout = 8000

// The platform readiness endpoint intentionally remains outside versioned business APIs.
const platformApi = axios.create({ baseURL: import.meta.env.VITE_PLATFORM_API_BASE_URL || '/api', timeout })
export const api = axios.create({ baseURL: import.meta.env.VITE_API_BASE_URL || '/api/v1', timeout })

export const checkReadiness = () => platformApi.get<HealthResponse>('/health/ready')

export function apiError(error: unknown): Error {
  if (axios.isAxiosError(error)) {
    const body = error.response?.data
    const detail = body?.error?.message || body?.detail?.message || body?.detail
    if (typeof detail === 'string') return Error(detail)
    return Error(error.message || '无法连接后端服务')
  }
  return error instanceof Error ? error : Error('请求失败')
}

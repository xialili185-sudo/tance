import { computed, reactive, ref } from 'vue'
import { acceptHMRUpdate, defineStore } from 'pinia'
import { backendWorkspaceSource, mockWorkspaceSource } from '../services/workspace'
import type { Scene, Drawer, Signal, Decision, Plan, Batch, Sale, Product, Content, EventPlan, Task } from '../types/domain'
import { daysBetween } from '../utils/format'

export const useWorkspace = defineStore('workspace',()=>{
  const scene=ref<Scene>('preparing')
  const data=ref(mockWorkspaceSource.initialData(scene.value))
  const apiMode=backendWorkspaceSource.enabled
  const loading=ref(false)
  const loadError=ref('')
  const drawer=ref<Drawer>({type:''})
  const toast=ref('')
  let toastTimer:ReturnType<typeof setTimeout>
  let tick=0
  const busy=reactive<Record<string,boolean>>({})
  const today=computed(()=>scene.value==='live'?'2026-10-24':scene.value==='completed'?'2026-10-26':'2026-09-21')
  const stamp=()=>new Date(Date.parse(today.value+'T12:00:00.000Z')+(++tick)*1000).toISOString()
  const id=(prefix:string)=>`${prefix}-${crypto.randomUUID().slice(0,8)}`
  const notify=(message:string)=>{toast.value=message;clearTimeout(toastTimer);toastTimer=setTimeout(()=>toast.value='',3500)}
  async function refresh(){
    if(!apiMode)return
    loading.value=true;loadError.value=''
    try{data.value=await backendWorkspaceSource.load()}catch(error){loadError.value=(error as Error).message;notify(`后端数据加载失败：${loadError.value}`)}finally{loading.value=false}
  }
  const open=(value:Drawer)=>drawer.value=value
  const close=()=>drawer.value={type:''}
  const product=(productId:string)=>data.value.products.find(p=>p.id===productId)!
  const event=(eventId:string)=>data.value.events.find(e=>e.id===eventId)!
  const plan=(planId:string)=>data.value.plans.find(p=>p.id===planId)!
  const eventPlans=(eventId:string)=>data.value.plans.filter(p=>p.eventId===eventId)
  const planSales=(planId:string)=>data.value.sales.filter(s=>s.planId===planId).sort((a,b)=>a.date.localeCompare(b.date))
  const sold=(planId:string)=>planSales(planId).reduce((s,v)=>s+v.quantity,0)
  const produced=(productId:string)=>data.value.batches.filter(b=>b.productId===productId&&b.status==='RECEIVED').reduce((s,b)=>s+b.quantity,0)
  const totalSold=(productId:string)=>data.value.plans.filter(p=>p.productId===productId).reduce((s,p)=>s+sold(p.id),0)
  const stock=(productId:string)=>produced(productId)-totalSold(productId)
  const incoming=(productId:string)=>data.value.batches.filter(b=>b.productId===productId&&b.status!=='RECEIVED').reduce((s,b)=>s+b.quantity,0)
  const available=(planId:string)=>{
    const p=plan(planId)
    const other=data.value.plans.filter(x=>x.productId===p.productId&&x.id!==planId&&event(x.eventId).status!=='COMPLETED').reduce((s,x)=>s+Math.max(0,x.allocated-sold(x.id)),0)
    return Math.max(0,stock(p.productId)-other)
  }
  const remaining=(planId:string)=>Math.max(0,plan(planId).allocated-sold(planId))
  const signals=(planId:string)=>data.value.signals.filter(s=>s.planId===planId).sort((a,b)=>a.observedAt.localeCompare(b.observedAt)||a.createdAt.localeCompare(b.createdAt))
  const latestSignal=(planId:string,type:Signal['type'])=>signals(planId).filter(s=>s.type===type).at(-1)
  const history=(planId:string)=>{
    const p=plan(planId)
    return data.value.plans.filter(x=>x.productId===p.productId&&x.id!==p.id&&event(x.eventId).status==='COMPLETED'&&event(x.eventId).startDate<event(p.eventId).startDate&&planSales(x.id).length>0)
      .sort((a,b)=>event(a.eventId).startDate.localeCompare(event(b.eventId).startDate)).map(x=>({plan:x,event:event(x.eventId),sold:sold(x.id)}))
  }
  const latest=(planId:string)=>data.value.decisions.filter(d=>d.planId===planId).at(-1)
  const stale=(planId:string)=>{
    const d=latest(planId); if(!d)return false
    const ids=signals(planId).map(s=>s.id)
    return ids.length!==d.evidenceIds.length||ids.some(i=>!d.evidenceIds.includes(i))
  }
  const readiness=(planId:string)=>latestSignal(planId,'survey')||latestSignal(planId,'preorder')?'READY':signals(planId).length||history(planId).length?'LIMITED':'INSUFFICIENT'
  const needsSurvey=(planId:string)=>history(planId).length>0&&!latestSignal(planId,'survey')
  const activeBatch=(planId:string)=>data.value.batches.find(b=>b.planId===planId&&b.status!=='RECEIVED')
  const productionReady=(p:Plan)=>p.finalQuantity!==undefined&&!activeBatch(p.id)&&(p.finalQuantity===0||data.value.batches.filter(b=>b.planId===p.id&&b.status==='RECEIVED').reduce((sum,b)=>sum+b.quantity,0)>=p.finalQuantity)
  const ready=(p:Plan)=>productionReady(p)&&p.allocated>0
  const eventStats=(eventId:string)=>{
    const ps=eventPlans(eventId)
    return {count:ps.length,ready:ps.filter(ready).length,demand:ps.filter(p=>readiness(p.id)==='READY').length,production:ps.filter(productionReady).length,sold:ps.reduce((s,p)=>s+sold(p.id),0),remaining:ps.reduce((s,p)=>s+remaining(p.id),0),recorded:ps.filter(p=>planSales(p.id).length).length}
  }
  const nextEvent=computed(()=>scene.value==='completed'?data.value.events.find(e=>e.id==='e1'):data.value.events.filter(e=>e.status!=='COMPLETED').sort((a,b)=>a.startDate.localeCompare(b.startDate))[0]||data.value.events.find(e=>e.id==='e1')||data.value.events[0])
  const tasks=(eventId:string)=>data.value.tasks.filter(t=>t.eventId===eventId).sort((a,b)=>a.dueAt.localeCompare(b.dueAt))
  function primary(planId:string):{label:string;action:string;tab?:string} {
    const p=plan(planId), e=event(p.eventId)
    if(e.status==='COMPLETED')return {label:'查看销售复盘',action:'tab',tab:'inventory'}
    if(e.status==='IN_PROGRESS'&&remaining(planId)>0)return {label:'记录销售',action:'sale'}
    if(readiness(planId)==='INSUFFICIENT')return {label:'添加需求信号',action:'signal'}
    if(needsSurvey(planId))return {label:'补充本场印调',action:'signal'}
    if(stale(planId))return {label:'更新备货建议',action:'tab',tab:'recommendation'}
    if(!latest(planId))return {label:'生成备货建议',action:'tab',tab:'recommendation'}
    if(p.finalQuantity===undefined||latest(planId)?.finalQuantity===undefined)return {label:'确认备货数量',action:'tab',tab:'recommendation'}
    if(p.finalQuantity>0&&!data.value.batches.some(b=>b.planId===p.id))return {label:'创建生产批次',action:'batch'}
    if(activeBatch(planId))return {label:'查看生产进度',action:'batch'}
    if(!p.allocated)return {label:'分配展会库存',action:'tab',tab:'inventory'}
    return {label:'查看备货计划',action:'tab',tab:'overview'}
  }
  const issues=(eventId:string)=>{
    const list:{id:string;title:string;detail:string;label:string;severity:number;planId?:string;batchId?:string;taskId?:string}[]=[]
    data.value.batches.filter(b=>b.status!=='RECEIVED'&&b.planId&&plan(b.planId)?.eventId===eventId&&daysBetween(b.expectedAt,today.value)<0).forEach(b=>list.push({id:b.id,title:product(b.productId).name,detail:'生产批次已超过预计到货时间',label:'查看批次',severity:0,batchId:b.id}))
    eventPlans(eventId).filter(p=>p.finalQuantity===undefined).forEach(p=>list.push({id:p.id,title:product(p.productId).name,detail:needsSurvey(p.id)?'再贩商品还没有本场新印调':latest(p.id)?'备货建议已生成，等待你确认数量':'尚未生成备货建议',label:primary(p.id).label,severity:needsSurvey(p.id)?2:1,planId:p.id}))
    tasks(eventId).filter(t=>t.status!=='DONE'&&daysBetween(t.dueAt,today.value)<=4).forEach(t=>list.push({id:t.id,title:t.title,detail:daysBetween(t.dueAt,today.value)<0?'任务已逾期':`${daysBetween(t.dueAt,today.value)} 天后截止`,label:'处理任务',severity:daysBetween(t.dueAt,today.value)<0?0:3,taskId:t.id}))
    return list.sort((a,b)=>a.severity-b.severity)
  }
  function switchScene(value:Scene){if(apiMode){notify('真实数据模式不支持切换演示场景');return}scene.value=value;data.value=mockWorkspaceSource.initialData(value);close();notify('已切换演示场景')}
  function addSignal(value:Omit<Signal,'id'|'createdAt'>){
    if(!Number.isInteger(value.value)||value.value<0)throw Error('请输入非负整数')
    if(apiMode)return backendWorkspaceSource.saveSignal(value).then(async()=>{await refresh();notify('需求快照已保存到后端')})
    data.value.signals.push({...value,id:id('signal'),createdAt:stamp()});notify('需求快照已追加，历史记录已保留')
  }
  async function removeSignal(signalId:string){
    if(apiMode){await backendWorkspaceSource.removeSignal(signalId);await refresh();notify('需求快照已从后端删除');return}
    data.value.signals=data.value.signals.filter(v=>v.id!==signalId);notify('快照已删除，请检查建议是否需要更新')
  }
  async function generate(planId:string){
    if(busy[planId])return
    if(readiness(planId)==='INSUFFICIENT')throw Error('至少添加一项需求信号，再生成建议')
    busy[planId]=true
    try{
      if(apiMode){await backendWorkspaceSource.generate(planId);await refresh();notify('后端已生成新的数量建议');return}
      await new Promise(resolve=>setTimeout(resolve,650))
      const survey=latestSignal(planId,'survey'),preorder=latestSignal(planId,'preorder'),manual=latestSignal(planId,'manual'),hist=history(planId).map(h=>h.sold)
      const base=Math.max(preorder?.value||0,Math.round((survey?survey.value*1.5:manual?manual.value:hist.length?hist.at(-1)!*.7:(latestSignal(planId,'wishlist')?.value||latestSignal(planId,'social')?.value||latestSignal(planId,'external')?.value||0)*.25)/10)*10)
      const demand:[number,number,number]=[Math.floor(base*.75/10)*10,base,Math.ceil(base*1.25/10)*10]
      const currentStock=stock(plan(planId).productId)
      const d:Decision={id:id('decision'),planId,demand,production:demand.map(n=>Math.max(0,n-currentStock)) as [number,number,number],stock:currentStock,confidence:survey&&preorder?'HIGH':survey?'MEDIUM':'LOW',createdAt:stamp(),notes:'',explanation:'READY',evidenceIds:signals(planId).map(s=>s.id),history:hist,survey:signals(planId).filter(s=>s.type==='survey').map(s=>s.value)}
      data.value.decisions.push(d);notify('已生成新的建议，上一版仍保留在历史中')
    }finally{busy[planId]=false}
  }
  function confirmQuantity(planId:string,quantity:number,notes:string){
    if(!Number.isInteger(quantity)||quantity<0)throw Error('生产数量必须是非负整数')
    if(activeBatch(planId))throw Error('已有进行中的生产批次，请先核对批次再调整决定')
    const d=latest(planId);if(!d)throw Error('请先生成建议')
    if(apiMode)return backendWorkspaceSource.confirmQuantity(d.id,quantity,notes).then(async()=>{await refresh();notify('最终生产决定已保存到后端')})
    d.finalQuantity=quantity;d.notes=notes;plan(planId).finalQuantity=quantity;notify('已保存你的最终生产决定')
  }
  function allocate(planId:string,quantity:number){
    if(!Number.isInteger(quantity)||quantity<sold(planId))throw Error('分配总量不能小于已售数量，且必须是整数')
    if(quantity>available(planId)+sold(planId))throw Error('分配数量超出可用库存；在途商品不能分配')
    if(apiMode)return backendWorkspaceSource.allocate(planId,quantity).then(async()=>{await refresh();notify('展会库存分配已保存到后端')})
    plan(planId).allocated=quantity;notify('展会库存分配已更新')
  }
  function saveSale(value:Omit<Sale,'id'>,saleId?:string){
    const p=plan(value.planId);if(!['IN_PROGRESS','COMPLETED'].includes(event(p.eventId).status))throw Error('展会开始后才能记录销售')
    if(value.date<event(p.eventId).startDate||value.date>event(p.eventId).endDate)throw Error('销售日期应在展会日期范围内')
    const old=data.value.sales.find(s=>s.id===saleId),previous=old?.quantity||0
    if(!Number.isInteger(value.quantity)||value.quantity<0)throw Error('销量必须是非负整数')
    if(value.quantity>remaining(p.id)+previous||value.quantity>stock(p.productId)+previous)throw Error('本次销量超过展会剩余可售库存')
    if(apiMode)return backendWorkspaceSource.saveSale(value,saleId).then(async()=>{await refresh();notify('销量已保存到后端')})
    if(old)Object.assign(old,value);else data.value.sales.push({...value,id:id('sale')})
    notify('销量已保存，库存与销售历史同步更新')
  }
  async function removeSale(saleId:string){
    if(apiMode){await backendWorkspaceSource.removeSale(saleId);await refresh();notify('销量记录已从后端删除');return}
    data.value.sales=data.value.sales.filter(v=>v.id!==saleId);notify('销量记录已删除，库存已恢复')
  }
  function saveBatch(value:Omit<Batch,'id'|'samples'>,batchId?:string){
    if(!Number.isInteger(value.quantity)||value.quantity<=0)throw Error('生产数量必须是正整数')
    const old=data.value.batches.find(b=>b.id===batchId)
    if(old?.status==='RECEIVED'&&(value.status!=='RECEIVED'||value.quantity!==old.quantity||value.productId!==old.productId))throw Error('已到货批次不能回退或修改数量，以免破坏库存记录')
    if(apiMode)return backendWorkspaceSource.saveBatch(value,batchId).then(async()=>{await refresh();notify('生产批次已保存到后端')})
    if(old)Object.assign(old,value);else data.value.batches.push({...value,id:id('batch'),samples:[]})
    notify(value.status==='RECEIVED'?'批次已收货，现货库存已更新':'生产批次已保存')
  }
  async function addPlan(value:Omit<Plan,'id'|'allocated'>){
    if(data.value.plans.some(p=>p.eventId===value.eventId&&p.productId===value.productId))throw Error('此商品已经加入该展会')
    if(apiMode){const planId=await backendWorkspaceSource.savePlan(value);await refresh();notify('商品已加入后端参展计划');return plan(planId)}
    const p={...value,id:id('plan'),allocated:0};data.value.plans.push(p);notify('商品已加入参展计划');return p
  }
  async function addProduct(value:Omit<Product,'id'>){if(apiMode){const productId=await backendWorkspaceSource.saveProduct(value);await refresh();return product(productId)}const p={...value,id:id('product')};data.value.products.push(p);return p}
  async function saveEvent(value:Omit<EventPlan,'id'>,eventId?:string){if(apiMode){await backendWorkspaceSource.saveEvent(value,eventId);await refresh();notify('参展计划已保存到后端');return}const old=data.value.events.find(e=>e.id===eventId);if(old)Object.assign(old,value);else data.value.events.push({...value,id:id('event')});notify('参展计划已保存')}
  async function saveProduct(value:Omit<Product,'id'>,productId?:string){if(apiMode){await backendWorkspaceSource.saveProduct(value,productId);await refresh();notify('商品已保存到后端');return}const old=data.value.products.find(p=>p.id===productId);if(old)Object.assign(old,value);else await addProduct(value);notify('商品已保存')}
  async function saveContent(value:Omit<Content,'id'>,linkedProductIds:string[],contentId?:string){if(apiMode){await backendWorkspaceSource.saveContent(value,linkedProductIds,contentId);await refresh();notify('作品与商品关联已保存到后端');return}const old=data.value.contents.find(c=>c.id===contentId),cid=old?.id||id('content');if(old)Object.assign(old,value);else data.value.contents.push({...value,id:cid});data.value.products.forEach(p=>{p.contentIds=p.contentIds.filter(x=>x!==cid);if(linkedProductIds.includes(p.id))p.contentIds.push(cid)});notify('作品与商品关联已保存')}
  async function saveTask(value:Omit<Task,'id'>,taskId?:string){if(apiMode){await backendWorkspaceSource.saveTask(value,taskId);await refresh();notify('截止任务已保存到后端');return}const old=data.value.tasks.find(t=>t.id===taskId);if(old)Object.assign(old,value);else data.value.tasks.push({...value,id:id('task')});notify('截止任务已保存')}
  async function removeTask(taskId:string){if(apiMode){await backendWorkspaceSource.removeTask(taskId);await refresh();notify('截止任务已从后端删除');return}data.value.tasks=data.value.tasks.filter(t=>t.id!==taskId);notify('任务已删除')}
  async function addSample(batchId:string,sample:{round:number;date:string;result:string;notes:string}){if(apiMode){await backendWorkspaceSource.addSample(batchId,sample);await refresh();notify('打样记录已保存到后端');return}const batch=data.value.batches.find(b=>b.id===batchId);if(batch)batch.samples.push(sample);notify('打样记录已保存')}
  return {scene,data,apiMode,loading,loadError,drawer,toast,busy,today,nextEvent,id,stamp,notify,refresh,open,close,product,event,plan,eventPlans,planSales,sold,produced,totalSold,stock,incoming,available,remaining,signals,latestSignal,history,latest,stale,readiness,needsSurvey,activeBatch,productionReady,ready,eventStats,tasks,primary,issues,switchScene,addSignal,removeSignal,generate,confirmQuantity,allocate,saveSale,removeSale,saveBatch,addPlan,addProduct,saveEvent,saveProduct,saveContent,saveTask,removeTask,addSample}
})

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useWorkspace, import.meta.hot))
}

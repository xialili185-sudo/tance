import { defineStore } from 'pinia'
import { ref } from 'vue'
import { checkReadiness } from '../services/api'
import type { HealthResponse } from '../types/api'
export const useEnvironmentStore = defineStore('environment', () => {
  const result = ref<HealthResponse | null>(null)
  const loading = ref(false)
  const error = ref('')
  async function refresh() {
    loading.value = true; error.value = ''; result.value = null
    try { result.value = (await checkReadiness()).data }
    catch { error.value = '连接失败。请确认 FastAPI 与 MySQL 已启动，然后重试。' }
    finally { loading.value = false }
  }
  return { result, loading, error, refresh }
})

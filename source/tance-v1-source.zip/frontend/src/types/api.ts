export interface HealthResponse {
  status: 'ok' | 'error'
  service: string
  database: 'not_checked' | 'connected' | 'unavailable'
  llm: 'disabled' | 'configured' | 'missing_configuration'
}

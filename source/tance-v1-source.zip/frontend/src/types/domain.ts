export type EventStatus = 'PLANNING' | 'PREPARING' | 'IN_PROGRESS' | 'COMPLETED'
export type BatchStatus = 'PLANNED' | 'SAMPLING' | 'ORDERED' | 'PRODUCING' | 'SHIPPED' | 'RECEIVED'
export type SignalType = 'survey' | 'wishlist' | 'preorder' | 'social' | 'manual' | 'external'
export type Scene = 'preparing' | 'cold' | 'limited' | 'recovery' | 'sufficient' | 'live' | 'completed' | 'fallback'
export interface EventPlan { id:string; name:string; location:string; startDate:string; endDate:string; deadline:string; status:EventStatus; sourceListingId?:string; notes:string }
export interface Product { id:string; name:string; type:string; fandom:string; description:string; price:number; color:string; mark:string; status:'ACTIVE'|'ARCHIVED'; contentIds:string[] }
export interface Content { id:string; title:string; type:string; tags:string; color:string; mark:string; notes:string }
export interface Plan { id:string; eventId:string; productId:string; price:number; initialQuantity?:number; finalQuantity?:number; allocated:number; notes:string }
export interface Signal { id:string; planId:string; type:SignalType; value:number; source:string; observedAt:string; createdAt:string; notes:string }
export interface Decision { id:string; planId:string; demand:[number,number,number]; production:[number,number,number]; stock:number; confidence:'LOW'|'MEDIUM'|'HIGH'; finalQuantity?:number; notes:string; createdAt:string; explanation:'READY'|'UNAVAILABLE'; evidenceIds:string[]; history:number[]; survey:number[] }
export interface Batch { id:string; productId:string; planId?:string; name:string; vendor:string; quantity:number; cost:number; status:BatchStatus; expectedAt:string; receivedAt?:string; notes:string; samples:{round:number;date:string;result:string;notes:string}[] }
export interface Sale { id:string; planId:string; date:string; quantity:number; notes:string }
export interface Task { id:string; eventId:string; planId?:string; title:string; dueAt:string; status:'TODO'|'IN_PROGRESS'|'DONE'; notes:string }
export interface Listing { id:string; name:string; location:string; startDate:string; endDate:string; deadline:string; status:'OPEN'|'CLOSING_SOON'|'CLOSED'; themes:string[]; description:string }
export interface Data { events:EventPlan[]; products:Product[]; contents:Content[]; plans:Plan[]; signals:Signal[]; decisions:Decision[]; batches:Batch[]; sales:Sale[]; tasks:Task[] }
export type DrawerType = ''|'event'|'product'|'addPlan'|'task'|'signal'|'batch'|'sale'|'content'|'history'|'recommend'|'sample'
export interface Drawer { type:DrawerType; id?:string; eventId?:string; planId?:string; productId?:string; contentId?:string }

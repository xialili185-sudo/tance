<script setup lang="ts">
import {useWorkspace} from '../stores/workspace'
import {shortDate,daysBetween} from '../utils/format'
import Icon from './common/Icon.vue'
const props=withDefaults(defineProps<{eventId:string;compact?:boolean}>(),{compact:false})
const s=useWorkspace()
async function remove(id:string){if(window.confirm('删除这项截止任务？'))await s.removeTask(id)}
</script>
<template><div v-if="!s.tasks(eventId).length" class="empty-inline muted">还没有截止任务，为参展安排第一个节点吧。</div><div class="timeline"><div v-for="task in s.tasks(props.eventId).filter(t=>!compact||t.status!=='DONE').slice(0,compact?3:100)" :key="task.id" class="timeline-item" :class="{finished:task.status==='DONE'}"><button class="task-check" :class="{checked:task.status==='DONE'}" :aria-label="task.status==='DONE'?'标为待完成':'标记任务完成'" @click="task.status=task.status==='DONE'?'TODO':'DONE'"><Icon v-if="task.status==='DONE'" name="check" :size="12"/></button><div class="timeline-content"><span class="timeline-date" :class="{'text-amber':task.status!=='DONE'&&daysBetween(task.dueAt,s.today)<=4}">{{shortDate(task.dueAt)}} <small v-if="task.status!=='DONE'&&daysBetween(task.dueAt,s.today)<0">· 已逾期</small></span><h4>{{task.title}}</h4><p class="muted text-xs">{{task.planId?s.product(s.plan(task.planId).productId).type+'商品':'展会事项'}}{{task.status==='DONE'?' · 已完成':''}}</p></div><div v-if="!compact" class="inline-actions"><button class="icon-button" aria-label="编辑任务" @click="s.open({type:'task',id:task.id,eventId})"><Icon name="edit" :size="16"/></button><button class="icon-button" aria-label="删除任务" @click="remove(task.id)"><Icon name="trash" :size="16"/></button></div></div></div></template>

<script setup lang="ts">
import {useWorkspace} from '../stores/workspace'
import {useRouter} from 'vue-router'
import Icon from './common/Icon.vue'
defineProps<{eventId:string}>()
const s=useWorkspace(),router=useRouter()
function act(issue:ReturnType<typeof s.issues>[number]){
 if(issue.taskId)s.open({type:'task',id:issue.taskId,eventId:s.data.tasks.find(t=>t.id===issue.taskId)?.eventId})
 else if(issue.batchId)s.open({type:'batch',id:issue.batchId})
 else if(issue.planId){const p=s.plan(issue.planId);router.push(`/events/${p.eventId}/products/${p.id}?tab=${s.needsSurvey(p.id)?'demand':'recommendation'}`)}
}
</script>
<template><div v-if="!s.issues(eventId).length" class="ready-message"><Icon name="circleCheck"/><div><strong>准备工作正在有序推进</strong><p>当前没有需要优先处理的事项。</p></div></div><div v-else class="attention-list"><div v-for="issue in s.issues(eventId).slice(0,4)" :key="issue.id" class="attention-item"><span class="issue-icon" :class="issue.severity===0?'red':issue.severity===1?'blue':'amber'"><Icon :name="issue.severity===1?'sparkle':issue.severity===3?'clock':'alert'" :size="18"/></span><div><h4>{{issue.title}}</h4><p>{{issue.detail}}</p></div><button class="text-link" @click="act(issue)">{{issue.label}}<Icon name="chevron" :size="15"/></button></div></div></template>

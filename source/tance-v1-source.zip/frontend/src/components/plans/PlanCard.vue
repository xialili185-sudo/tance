<script setup lang="ts">
import {computed} from 'vue'
import {useWorkspace} from '../../stores/workspace'
import type {Plan} from '../../types/domain'
import ProductArt from '../common/ProductArt.vue'
import Badge from '../common/Badge.vue'
import Icon from '../common/Icon.vue'
import {money} from '../../utils/format'
const props=defineProps<{plan:Plan}>()
const s=useWorkspace(),product=computed(()=>s.product(props.plan.productId))
</script>
<template><article class="panel plan-card"><div class="plan-card-top"><ProductArt :color="product.color" :mark="product.mark" :type="product.type" small/><div><h3>{{product.name}}</h3><p class="muted text-sm">{{product.type}} · {{s.history(plan.id).length?'再贩':'首次贩售'}} · {{money(plan.price)}}</p></div><Badge :status="s.ready(plan)?'READY':s.needsSurvey(plan.id)?'WARNING':'INCOMPLETE'" /></div><div class="plan-card-stats"><div><small>本场印调</small><strong>{{s.latestSignal(plan.id,'survey')?.value??'待补充'}}</strong></div><div><small>现货库存</small><strong>{{s.stock(product.id)}}<em> 件</em></strong></div><div><small>已分配</small><strong>{{plan.allocated}}<em> 件</em></strong></div><div><small>生产状态</small><strong class="text-sm">{{s.activeBatch(plan.id)?'进行中':s.ready(plan)?'准备完成':'待确认'}}</strong></div></div><div class="plan-card-bottom"><span :class="s.ready(plan)?'text-green':'muted'" class="text-sm"><Icon :name="s.ready(plan)?'circleCheck':s.needsSurvey(plan.id)?'alert':'clock'" :size="15"/>{{s.ready(plan)?'准备就绪，期待出摊':s.needsSurvey(plan.id)?'建议补充本场新印调':plan.finalQuantity===undefined?'等待确认最终数量':'继续完成备货'}}</span><RouterLink class="text-link" :to="`/events/${plan.eventId}/products/${plan.id}`">查看计划 <Icon name="arrow" :size="16"/></RouterLink></div></article></template>

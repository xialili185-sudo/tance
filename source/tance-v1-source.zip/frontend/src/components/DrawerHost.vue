<script setup lang="ts">
import {computed,nextTick,onBeforeUnmount,reactive,ref,watch} from 'vue'
import {useRouter} from 'vue-router'
import {useWorkspace} from '../stores/workspace'
import {listings} from '../mocks/seed'
import type {BatchStatus,EventStatus,SignalType,Listing} from '../types/domain'
import {dateRange,shortDate,timeLabel,signalLabels,statusLabels} from '../utils/format'
import Icon from './common/Icon.vue'
import Badge from './common/Badge.vue'
import AttentionList from './AttentionList.vue'
import RecommendationPanel from './plans/RecommendationPanel.vue'
const s=useWorkspace(),router=useRouter(),dialog=ref<HTMLDialogElement>(),form=reactive<Record<string,any>>({}),error=ref(''),working=ref(false)
const searched=ref(false),expanded=ref('')
const titles:Record<string,string>={event:'参展计划',product:'商品',addPlan:'添加参展商品',task:'截止任务',signal:'添加需求快照',batch:'生产批次',sale:'销售记录',content:'作品资产',history:'建议历史',recommend:'摊策 · 帮你想一步',sample:'记录打样结果'}
const heading=computed(()=>['event','product','task','batch','sale','content'].includes(s.drawer.type)?`${s.drawer.id?'编辑':'新建'}${titles[s.drawer.type]}`:titles[s.drawer.type]||'')
const plan=computed(()=>s.drawer.planId?s.plan(s.drawer.planId):null)
const listingMatches=computed(()=>listings.filter(l=>l.startDate>=form.fromDate&&l.startDate<=form.toDate&&(form.region==='不限'||l.location.includes(form.region))&&String(form.fandom||'').split(/[,，、\s]+/).filter(Boolean).some(tag=>l.themes.some(t=>t.includes(tag)||tag.includes(t)))))
const linkExists=(l:Listing)=>s.data.events.some(e=>e.sourceListingId===l.id||e.name===l.name)
watch(()=>s.drawer,async(d)=>{
  error.value='';working.value=false;searched.value=false;expanded.value=''
  if(!d.type){if(dialog.value?.open)dialog.value.close();document.body.style.overflow='';return}
  Object.keys(form).forEach(k=>delete form[k])
  const p=d.planId?s.plan(d.planId):undefined
  Object.assign(form,{name:'',notes:'',price:25,type:'徽章',fandom:'',color:'blue',mark:'',contentIds:[],linked:[],eventId:d.eventId||p?.eventId||s.data.events.find(e=>e.status!=='COMPLETED')?.id||'',productId:d.productId||p?.productId||s.data.products[0]?.id||'',mode:'existing',quantity:0,cost:0,source:'本场印调',date:s.today,status:'TODO'})
  if(d.type==='event'){const e=s.data.events.find(e=>e.id===d.id);Object.assign(form,e||{name:'',location:'',startDate:'2026-11-01',endDate:'2026-11-02',deadline:'',status:'PLANNING'})}
  if(d.type==='product'){const product=s.data.products.find(p=>p.id===d.id),c=s.data.contents.find(c=>c.id===d.contentId);Object.assign(form,product?JSON.parse(JSON.stringify(product)):{name:c?c.title+' · 新商品':'',description:'',fandom:c?.tags||'',color:c?.color||'blue',status:'ACTIVE',contentIds:c?[c.id]:[]})}
  if(d.type==='addPlan')form.price=s.product(form.productId)?.price||25
  if(d.type==='task'){const t=s.data.tasks.find(t=>t.id===d.id);Object.assign(form,t||{title:'',dueAt:s.today,planId:'',status:'TODO'})}
  if(d.type==='signal')Object.assign(form,{type:'survey',value:0,observedAt:s.today})
  if(d.type==='sale'){const sale=s.data.sales.find(v=>v.id===d.id);Object.assign(form,sale||{quantity:0,date:p?s.event(p.eventId).status==='COMPLETED'?s.event(p.eventId).endDate:s.today:s.today})}
  if(d.type==='batch'){const b=s.data.batches.find(b=>b.id===d.id);Object.assign(form,b?JSON.parse(JSON.stringify(b)):{name:`TC-${String(s.data.batches.length+1).padStart(4,'0')}`,quantity:p?.finalQuantity||30,cost:0,vendor:'',status:'PLANNED',expectedAt:s.today,planId:d.planId||''})}
  if(d.type==='content'){const c=s.data.contents.find(c=>c.id===d.id);Object.assign(form,c||{title:'',type:'插画',tags:'',mark:'NEW WORK'});form.linked=s.data.products.filter(p=>p.contentIds.includes(d.id||'')).map(p=>p.id)}
  if(d.type==='recommend')Object.assign(form,{fandom:'逆转裁判，原神',region:'上海',fromDate:s.today,toDate: s.scene==='completed'?'2027-01-26':'2026-12-21',productType:'不限',budget:'',})
  if(d.type==='sample')Object.assign(form,{date:s.today,result:'通过',notes:''})
  await nextTick();if(!dialog.value?.open)dialog.value?.showModal();document.body.style.overflow='hidden'
})
watch(()=>form.productId,()=>{if(s.drawer.type==='addPlan'&&form.mode==='existing')form.price=s.product(form.productId)?.price||25})
onBeforeUnmount(()=>document.body.style.overflow='')
function close(){s.close()}
async function save(){
  error.value=''
  try{
    const d=s.drawer
    if(d.type==='event'){
      if(form.endDate<form.startDate)throw Error('结束日期不能早于开始日期')
      if(form.deadline&&form.deadline>form.startDate)throw Error('报名截止日不能晚于展会开始日')
      const value={name:form.name.trim(),location:form.location.trim(),startDate:form.startDate,endDate:form.endDate,deadline:form.deadline,status:form.status as EventStatus,notes:form.notes}
      if(!value.name||!value.location)throw Error('请填写展会名称和地点')
      await s.saveEvent(value,d.id)
    }
    if(d.type==='product'){
      if(!form.name.trim()||Number(form.price)<0)throw Error('请填写商品名和有效的非负价格')
      const value={name:form.name.trim(),type:form.type,price:Number(form.price),description:form.description||'',fandom:form.fandom||'',color:form.color,mark:form.mark||form.name.slice(0,2),status:form.status as 'ACTIVE'|'ARCHIVED',contentIds:[...form.contentIds]}
      await s.saveProduct(value,d.id)
    }
    if(d.type==='addPlan'){
      if(!form.eventId)throw Error('请先选择或创建一场展会')
      if(!Number.isFinite(Number(form.price))||Number(form.price)<0)throw Error('展会价格必须为非负数')
      if(form.initialQuantity!==''&&form.initialQuantity!==undefined&&(!Number.isInteger(Number(form.initialQuantity))||Number(form.initialQuantity)<0))throw Error('初始计划数量须为非负整数')
      let productId=form.productId
      if(form.mode==='new'){
        if(!form.name.trim())throw Error('请输入新商品名称')
        productId=(await s.addProduct({name:form.name.trim(),type:form.type,price:Number(form.price),fandom:form.fandom,description:'',color:'blue',mark:form.name.slice(0,2),status:'ACTIVE',contentIds:[]})).id
      }
      if(!productId)throw Error('请选择商品')
      const result=await s.addPlan({eventId:form.eventId,productId,price:Number(form.price),initialQuantity:form.initialQuantity!==''&&form.initialQuantity!==undefined?Number(form.initialQuantity):undefined,notes:form.notes})
      close();router.push(`/events/${result.eventId}/products/${result.id}`);return
    }
    if(d.type==='task'){
      if(!form.title.trim())throw Error('请输入任务标题')
      const value={eventId:form.eventId,planId:form.planId||undefined,title:form.title.trim(),dueAt:form.dueAt,status:form.status as 'TODO'|'IN_PROGRESS'|'DONE',notes:form.notes}
      await s.saveTask(value,d.id)
    }
    if(d.type==='signal')await s.addSignal({planId:d.planId!,type:form.type as SignalType,value:Number(form.value),source:form.source,observedAt:form.observedAt,notes:form.notes})
    if(d.type==='sale')await s.saveSale({planId:d.planId!,date:form.date,quantity:Number(form.quantity),notes:form.notes},d.id)
    if(d.type==='batch'){
      if(!form.productId)throw Error('请选择生产的商品')
      if(form.cost<0)throw Error('成本不能为负数')
      await s.saveBatch({productId:form.productId,planId:form.planId||undefined,name:form.name,vendor:form.vendor,quantity:Number(form.quantity),cost:Number(form.cost),status:form.status as BatchStatus,expectedAt:form.expectedAt,receivedAt:form.status==='RECEIVED'?s.today:undefined,notes:form.notes},d.id)
    }
    if(d.type==='content'){
      if(!form.title.trim())throw Error('请输入作品标题')
      const value={title:form.title.trim(),type:form.type,tags:form.tags,color:form.color,mark:form.mark||form.title,notes:form.notes}
      await s.saveContent(value,form.linked,d.id)
    }
    if(d.type==='sample'){
      const b=s.data.batches.find(b=>b.id===d.id)!
      await s.addSample(b.id,{round:b.samples.length+1,date:form.date,result:form.result,notes:form.notes})
    }
    close()
  }catch(e){error.value=(e as Error).message}
}
async function searchEvents(){error.value='';if(form.toDate<form.fromDate){error.value='结束日期不能早于开始日期';return}working.value=true;await new Promise(r=>setTimeout(r,450));searched.value=true;working.value=false}
function addListing(l:Listing){if(l.status==='CLOSED'||linkExists(l))return;s.data.events.push({id:s.id('event'),sourceListingId:l.id,name:l.name,location:l.location,startDate:l.startDate,endDate:l.endDate,deadline:l.deadline,status:'PLANNING',notes:'来自演示推荐列表'});s.notify('已创建独立的参展计划，可在「展会」中继续准备')}
</script>
<template><dialog ref="dialog" class="drawer" :class="{wide:s.drawer.type==='recommend'&&s.drawer.planId}" aria-labelledby="drawer-title" @close="close" @click="(e:MouseEvent)=>{if(e.target===dialog)close()}"><div class="drawer-inner"><header class="drawer-header"><div><h2 id="drawer-title">{{heading}}</h2><p>{{plan?s.product(plan.productId).name+' · '+s.event(plan.eventId).name:'TANCE · 把下一步准备好'}}</p></div><button class="icon-button" aria-label="关闭侧栏" @click="close"><Icon name="close" :size="21"/></button></header><div class="drawer-body">
<template v-if="s.drawer.type==='recommend'">
  <RecommendationPanel v-if="s.drawer.planId" :plan-id="s.drawer.planId"/>
  <template v-else-if="s.drawer.eventId"><div class="banner" style="margin-bottom:23px"><Icon name="sparkle" :size="21"/><div><strong>{{s.event(s.drawer.eventId)?.name}}</strong><p>根据本场商品的准备状态，优先处理以下事项。</p></div></div><AttentionList :event-id="s.drawer.eventId"/><div class="form-footer"><button class="text-link" @click="s.open({type:'recommend'})">发现其他展会<Icon name="arrow" :size="15"/></button></div></template>
  <template v-else><div class="banner"><Icon name="sparkle" :size="20"/><div><strong>让你的创作，遇见合适的展会</strong><p>告诉我们创作主题、城市与时间，找到值得继续了解的活动。</p></div></div><form @submit.prevent="searchEvents" style="margin-top:25px"><label>IP / 创作主题<input v-model="form.fandom" placeholder="例如：逆转裁判、原神" required/></label><div class="form-row"><label>偏好城市<select v-model="form.region" required><option>上海</option><option>杭州</option><option>不限</option></select></label><label>商品类型 <small style="display:none">选填</small><select v-model="form.productType"><option>不限</option><option>徽章</option><option>亚克力</option><option>本子</option></select></label></div><div class="form-row"><label>可参展开始日期<input type="date" v-model="form.fromDate" required/></label><label>可参展结束日期<input type="date" v-model="form.toDate" required/></label></div><label>预算范围（选填）<input v-model="form.budget" placeholder="例如：¥500–1,000，用于人工筛选参考"/></label><button class="btn primary" :disabled="working" type="submit"><span v-if="working" class="loading-spinner"></span><Icon v-else name="sparkle" :size="16"/>{{working?'正在匹配展会…':'寻找适合的展会'}}</button></form><p class="muted text-xs" style="margin-top:13px">演示按主题、城市和日期筛选。商品类型及预算保留为偏好，未参与排名；报名信息均为示例。</p><p v-if="searched" class="text-sm" style="margin-top:26px">找到 {{listingMatches.length}} 场符合主题、时间与地点的展会</p><article v-for="l in searched?listingMatches:[]" :key="l.id" class="listing"><div class="row-between"><Badge :status="l.status"/><Badge status="HIGH" label="匹配度高"/></div><h3>{{l.name}}</h3><p>{{dateRange(l.startDate,l.endDate)}} · {{l.location}}</p><p>报名截止：{{shortDate(l.deadline)}}</p><div class="tag-row"><span v-for="tag in l.themes" :key="tag" class="tag">{{tag}}</span></div><p class="text-green">✓ 主题相关 · ✓ 日期符合 · ✓ 地点符合</p><div class="listing-actions"><button class="text-link neutral" @click="expanded=expanded===l.id?'':l.id">{{expanded===l.id?'收起详情':'查看展会详情'}}</button><button class="btn sm primary" :disabled="l.status==='CLOSED'||linkExists(l)" @click="addListing(l)">{{linkExists(l)?'已加入计划':l.status==='CLOSED'?'已截止报名':'加入参展计划'}}</button></div><p v-if="expanded===l.id" class="listing-details">{{l.description}}</p></article></template>
</template>
<template v-else-if="s.drawer.type==='history'"><p class="muted text-sm" style="margin-bottom:21px">每次重新生成都会新增记录。下面保留当时的需求方案、库存快照与最终决定。</p><article v-for="(d,index) in [...s.data.decisions.filter(d=>d.planId===s.drawer.planId)].reverse()" :key="d.id" class="history-item"><div class="row-between"><h3>{{timeLabel(d.createdAt)}}</h3><Badge :status="d.confidence"/></div><span v-if="index===0" class="tag">最新建议</span><div class="history-values"><div v-for="(label,i) in ['保守需求','平衡需求','积极需求']" :key="label">{{label}}<strong>{{d.demand[i]}}</strong></div></div><p class="text-xs muted">当时现货 {{d.stock}} 件 · 平衡建议生产 {{d.production[1]}} 件</p><div class="definition-row"><span>最终追加生产</span><strong>{{d.finalQuantity===undefined?'未确认':d.finalQuantity+' 件'}}</strong></div><p class="muted text-xs">{{d.notes||'未填写决策备注'}}</p></article><p v-if="!s.data.decisions.some(d=>d.planId===s.drawer.planId)" class="empty-inline muted">还没有数量建议历史</p></template>
<form v-else-if="s.drawer.type" @submit.prevent="save">
  <template v-if="s.drawer.type==='event'"><label>展会名称<input v-model="form.name" placeholder="例如：CP32 · COMICUP" required maxlength="80"/></label><label>城市与地点<input v-model="form.location" placeholder="例如：上海 · 国家会展中心" required maxlength="100"/></label><div class="form-row"><label>开始日期<input type="date" v-model="form.startDate" required/></label><label>结束日期<input type="date" v-model="form.endDate" required/></label></div><label>报名截止日期<input type="date" v-model="form.deadline"/></label><label>计划状态<select v-model="form.status"><option v-for="key in ['PLANNING','PREPARING','IN_PROGRESS','COMPLETED']" :key="key" :value="key">{{statusLabels[key]}}</option></select><small>演示中可切到「进行中」或「已结束」体验销售与复盘。</small></label></template>
  <template v-else-if="s.drawer.type==='product'"><label>商品名称<input v-model="form.name" required maxlength="80" placeholder="为这件商品起个名字"/></label><div class="form-row"><label>商品类型<select v-model="form.type"><option v-for="t in ['徽章','亚克力','明信片','色纸','贴纸','本子','其他']" :key="t">{{t}}</option></select></label><label>默认价格（元）<input v-model.number="form.price" type="number" min="0" step="0.01" required/></label></div><label>IP / 创作主题<input v-model="form.fandom" placeholder="例如：逆转裁判"/></label><label>商品说明<textarea v-model="form.description" placeholder="尺寸、材质、工艺或系列信息"></textarea></label><div class="form-row"><label>封面简称<input v-model="form.mark" maxlength="6" placeholder="例如：御剑"/></label><label>封面色调<select v-model="form.color"><option v-for="[v,t] in [['blue','蓝调'],['rose','莓红'],['green','青绿'],['violet','星紫'],['orange','暖橙'],['yellow','浅金']]" :key="v" :value="v">{{t}}</option></select></label></div><label>商品状态<select v-model="form.status"><option value="ACTIVE">使用中</option><option value="ARCHIVED">已归档</option></select></label><div><label>关联作品（可多选）</label><div class="tag-row" style="margin-top:12px"><label v-for="c in s.data.contents" :key="c.id" class="inline-actions" style="font-size:12px;padding:8px 11px;background:#f6f9fe;border-radius:6px"><input type="checkbox" v-model="form.contentIds" :value="c.id"/>{{c.title}}</label></div></div></template>
  <template v-else-if="s.drawer.type==='addPlan'"><label>目标展会<select v-model="form.eventId" required><option disabled value="">请选择展会</option><option v-for="e in s.data.events" :key="e.id" :value="e.id">{{e.name}}</option></select></label><div v-if="!s.data.events.length" class="banner amber">请先创建参展计划。<button type="button" class="text-link" @click="s.open({type:'event'})">创建展会</button></div><div class="segmented"><button type="button" :class="{active:form.mode==='existing'}" @click="form.mode='existing'">选择已有商品</button><button type="button" :class="{active:form.mode==='new'}" @click="form.mode='new'">创建新商品</button></div><template v-if="form.mode==='existing'"><label>选择商品<select v-model="form.productId" required><option v-for="p in s.data.products.filter(p=>p.status==='ACTIVE')" :key="p.id" :value="p.id">{{p.name}}</option></select></label><div v-if="s.data.plans.some(p=>p.productId===form.productId&&s.planSales(p.id).length)" class="banner amber"><Icon name="info" :size="19"/><div>这是一件再贩商品<p>将参考历史销售与当前库存，建议为新展会补充印调。也可以直接继续创建计划。</p></div></div></template><template v-else><label>新商品名称<input v-model="form.name" required/></label><label>商品类型<select v-model="form.type"><option>徽章</option><option>亚克力</option><option>本子</option><option>明信片</option><option>其他</option></select></label></template><div class="form-row"><label>本场售价（元）<input v-model.number="form.price" type="number" min="0" step="0.01" required/></label><label>初始计划数量（选填）<input v-model.number="form.initialQuantity" type="number" min="0" step="1" placeholder="暂不确定可留空"/></label></div><p class="muted text-xs">初始计划数量不等于最终生产决定，之后仍可根据需求调整。</p></template>
  <template v-else-if="s.drawer.type==='task'"><label>任务标题<input v-model="form.title" required maxlength="100"/></label><label>截止日期<input v-model="form.dueAt" type="date" required/></label><label>关联范围<select v-model="form.planId"><option value="">整个展会</option><option v-for="p in s.eventPlans(form.eventId)" :key="p.id" :value="p.id">{{s.product(p.productId).name}}</option></select></label><label>任务状态<select v-model="form.status"><option value="TODO">待完成</option><option value="IN_PROGRESS">进行中</option><option value="DONE">已完成</option></select></label></template>
  <template v-else-if="s.drawer.type==='signal'"><label>信号类型<select v-model="form.type"><option v-for="(label,value) in signalLabels" :key="value" :value="value">{{label}}</option></select></label><div class="banner" :class="['wishlist','social'].includes(form.type)?'amber':''"><Icon name="info" :size="18"/><div>{{form.type==='wishlist'?'累计心愿单只是辅助证据，可能包含已经购买的用户，不等于本场预计买家。':form.type==='survey'?'输入目前的累计有效意向人数。每次更新都会新增快照，保留之前的记录。':form.type==='external'?'仅用于系统外的历史数据；系统内销售会自动读取，不要重复录入。':'填写本次观测的总值，不要把多次快照相加。'}}</div></div><label>当前数值<input v-model.number="form.value" type="number" min="0" step="1" required/></label><label>来源<input v-model="form.source" placeholder="例如：问卷、CPP 心愿单" required/></label><label>观测日期<input v-model="form.observedAt" type="date" :max="s.today" required/></label></template>
  <template v-else-if="s.drawer.type==='batch'"><label>生产商品<select v-model="form.productId" required :disabled="!!form.planId||!!s.drawer.id"><option v-for="p in s.data.products" :key="p.id" :value="p.id">{{p.name}}</option></select></label><div class="form-row"><label>批次编号<input v-model="form.name" required/></label><label>供应商<input v-model="form.vendor" placeholder="例如：纸间造物" required/></label></div><div class="form-row"><label>生产数量<input v-model.number="form.quantity" type="number" min="1" step="1" required :disabled="s.data.batches.find(b=>b.id===s.drawer.id)?.status==='RECEIVED'"/></label><label>批次总成本（元）<input v-model.number="form.cost" type="number" min="0" step="0.01"/></label></div><label>批次状态<select v-model="form.status" :disabled="s.data.batches.find(b=>b.id===s.drawer.id)?.status==='RECEIVED'"><option v-for="key in ['PLANNED','SAMPLING','ORDERED','PRODUCING','SHIPPED','RECEIVED']" :key="key" :value="key">{{statusLabels[key]}}</option></select></label><label>预计到货日期<input v-model="form.expectedAt" type="date" required/></label><div v-if="form.status==='RECEIVED'" class="banner green"><Icon name="circleCheck" :size="18"/><div>保存后计入已收货现货。<p>已到货批次的数量与状态不再回退，避免库存与销售记录矛盾。</p></div></div><div v-if="s.drawer.id"><div class="row-between"><h3>打样记录</h3><button type="button" class="text-link" @click="s.open({type:'sample',id:s.drawer.id})">添加打样轮次<Icon name="plus" :size="14"/></button></div><article v-for="sample in s.data.batches.find(b=>b.id===s.drawer.id)?.samples||[]" :key="sample.round" class="history-item" style="margin-top:15px;margin-bottom:0"><div class="row-between"><strong class="text-sm">第 {{sample.round}} 轮 · {{sample.result}}</strong><small class="muted">{{shortDate(sample.date)}}</small></div><p class="muted text-xs" style="margin-top:10px">{{sample.notes}}</p></article></div></template>
  <template v-else-if="s.drawer.type==='sample'"><label>打样日期<input type="date" v-model="form.date" required/></label><label>打样结果<select v-model="form.result"><option>通过</option><option>需修改</option><option>未通过</option><option>待确认</option></select></label></template>
  <template v-else-if="s.drawer.type==='sale'"><div v-if="plan" class="banner"><Icon name="package" :size="19"/><div>本场分配 {{plan.allocated}} 件，当前剩余 {{s.remaining(plan.id)}} 件。<p>编辑时，原记录的数量会释放后重新计算。</p></div></div><label>销售日期<input v-model="form.date" type="date" :min="plan?s.event(plan.eventId).startDate:undefined" :max="plan?s.event(plan.eventId).endDate:undefined" required/></label><label>本次售出数量<input v-model.number="form.quantity" type="number" min="0" step="1" required/></label></template>
  <template v-else-if="s.drawer.type==='content'"><label>作品标题<input v-model="form.title" required maxlength="80"/></label><label>作品类型<select v-model="form.type"><option>插画</option><option>角色设计</option><option>平面设计</option><option>文本</option><option>其他</option></select></label><label>主题标签<input v-model="form.tags" placeholder="例如：逆转裁判 / 御剑怜侍"/></label><div class="form-row"><label>文字封面<input v-model="form.mark" maxlength="20" placeholder="例如：TEA TIME"/></label><label>色调<select v-model="form.color"><option v-for="[v,t] in [['blue','蓝调'],['rose','莓红'],['green','青绿'],['violet','星紫'],['orange','暖橙'],['yellow','浅金']]" :key="v" :value="v">{{t}}</option></select></label></div><div><label>关联已有商品</label><div style="display:grid;gap:12px;margin-top:14px"><label v-for="p in s.data.products" :key="p.id" class="inline-actions" style="font-size:12px"><input type="checkbox" v-model="form.linked" :value="p.id"/>{{p.name}}</label></div></div></template>
  <label v-if="s.drawer.type!=='product'">备注（选填）<textarea v-model="form.notes" placeholder="记录你想保留的信息"></textarea></label><div v-if="error" class="form-error" role="alert">{{error}}</div><div class="form-footer"><button class="btn" type="button" @click="close">取消</button><button class="btn primary" type="submit"><Icon name="check" :size="16"/>{{s.drawer.type==='signal'?'追加需求快照':s.drawer.type==='addPlan'?'加入参展计划':'保存'}}</button></div>
</form><p v-if="s.drawer.type==='recommend'&&error" class="form-error section-gap" role="alert">{{error}}</p>
</div></div></dialog></template>

<script setup lang="ts">
withDefaults(defineProps<{color?:string;mark?:string;type?:string;small?:boolean}>(),{color:'blue',mark:'创作',type:'TANCE ORIGINAL',small:false})
</script>
<template><div class="product-art" :class="[color,{small}]" aria-hidden="true"><span class="art-caption">{{type}}</span><strong>{{mark}}</strong><span class="art-edition">TANCE / COLLECTION</span><span class="art-cross">＋</span></div></template>

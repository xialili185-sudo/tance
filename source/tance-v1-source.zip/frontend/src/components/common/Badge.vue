<script setup lang="ts">
import {computed} from 'vue'
import {statusLabels} from '../../utils/format'
const props=defineProps<{status?:string;label?:string}>()
const tone=computed(()=>['READY','RECEIVED','DONE','HIGH','OPEN','ACTIVE'].includes(props.status||'')?'green':['WARNING','SAMPLING','CLOSING_SOON','LOW','LIMITED','INSUFFICIENT'].includes(props.status||'')?'amber':['COMPLETED','ARCHIVED','CLOSED'].includes(props.status||'')?'neutral':'blue')
</script>
<template><span class="badge" :class="tone"><span class="badge-dot"></span>{{label||statusLabels[status||'']||status}}</span></template>

<script setup lang="ts">
import {computed} from 'vue'
const props=withDefaults(defineProps<{values:number[];labels?:string[];color?:string}>(),{color:'#3974ef'})
const points=computed(()=>props.values.map((v,i)=>`${32+i*276/Math.max(props.values.length-1,1)},${100-v/Math.max(...props.values,1)*66}`).join(' '))
</script>
<template><div v-if="values.length" class="trend-chart"><svg viewBox="0 0 340 132" role="img" :aria-label="'趋势：'+values.join(' → ')"><path d="M25 32H315 M25 66H315 M25 100H315" stroke="#edf0f5" stroke-dasharray="4 4"/><polyline :points="points" fill="none" :stroke="color" stroke-width="2.6" stroke-linejoin="round"/><g v-for="(value,i) in values" :key="i"><circle :cx="32+i*276/Math.max(values.length-1,1)" :cy="100-value/Math.max(...values,1)*66" r="4" :fill="color" stroke="white" stroke-width="2"/><text :x="32+i*276/Math.max(values.length-1,1)" :y="88-value/Math.max(...values,1)*66" text-anchor="middle" fill="#4b5b71" font-size="12">{{value}}</text><text :x="32+i*276/Math.max(values.length-1,1)" y="126" text-anchor="middle" fill="#8490a2" font-size="10">{{labels?.[i]||`第 ${i+1} 次`}}</text></g></svg></div><p v-else class="muted empty-inline">还没有足够的趋势记录</p></template>

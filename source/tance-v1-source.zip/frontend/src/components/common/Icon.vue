<script setup lang="ts">
withDefaults(defineProps<{name:string;size?:number}>(),{size:20})
const paths:Record<string,string[]>={
 grid:['M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z'],
 calendar:['M5 5h14a2 2 0 0 1 2 2v13H3V7a2 2 0 0 1 2-2Z','M7 3v4 M17 3v4 M3 11h18 M7 15h2 M13 15h4 M7 18h4'],
 box:['m12 3 9 5v9l-9 5-9-5V8z','m3 8 9 5 9-5 M12 13v9 M7.5 5.5l9 5'],
 image:['M3 3h18v18H3z','m3 16 5-5 4 4 3-3 6 6','M8 7h.01'],
 layers:['m12 3 10 5-10 5L2 8z','m2 12 10 5 10-5 M2 16l10 5 10-5'],
 sparkle:['m12 3 2.3 6.7L21 12l-6.7 2.3L12 21l-2.3-6.7L3 12l6.7-2.3z','M20 2v4 M18 4h4'],
 plus:['M12 5v14 M5 12h14'],arrow:['M4 12h16 M14 6l6 6-6 6'],chevron:['m9 5 7 7-7 7'],down:['m6 9 6 6 6-6'],
 search:['M10.5 3a7.5 7.5 0 1 0 0 15 7.5 7.5 0 0 0 0-15 M16 16l5 5'],
 check:['m5 12 4 4L19 6'],circleCheck:['M22 11.1V12a10 10 0 1 1-5.9-9.1','m22 4-10 10-3-3'],
 clock:['M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20','M12 6v6l4 2'],
 pin:['M20 10c0 6-8 12-8 12S4 16 4 10a8 8 0 0 1 16 0Z','M12 7a3 3 0 1 0 0 6 3 3 0 0 0 0-6'],
 alert:['m12 3 10 18H2z','M12 9v5 M12 17h.01'],info:['M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20','M12 11v6 M12 7h.01'],
 close:['m6 6 12 12 M18 6 6 18'],edit:['m16 3 5 5-12 12H4v-5z','m14 5 5 5'],trash:['M3 6h18 M8 6V3h8v3 M5 6l1 15h12l1-15 M10 10v7 M14 10v7'],
 trend:['m3 17 6-6 4 4 8-11','M15 4h6v6'],trendDown:['m3 7 6 6 4-4 8 11','M15 20h6v-6'],
 heart:['M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z'],
 package:['M3 7h18v14H3z M2 3h20v4H2z M9 11h6'], truck:['M1 3h14v13H1z M15 8h4l3 4v4h-7','M5 16a2 2 0 1 0 0 4 2 2 0 0 0 0-4 M18 16a2 2 0 1 0 0 4 2 2 0 0 0 0-4'],
 list:['M9 6h12 M9 12h12 M9 18h12 M3 6h.01 M3 12h.01 M3 18h.01'],
 refresh:['M20 7V3l-4 4 M4 17v4l4-4','M3 11a9 9 0 0 1 17-4 M21 13a9 9 0 0 1-17 4'],
 history:['M3 12a9 9 0 1 0 3-6.7L3 8','M3 3v5h5 M12 7v5l3 2'],
 menu:['M3 6h18 M3 12h18 M3 18h18'],help:['M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20','M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3 M12 17h.01'],
 leaf:['M20 3C8 2 2 8 5 15s15 5 15-12Z','M5 20 16 9'],external:['M15 3h6v6 M10 14 21 3 M10 3H3v18h18v-7'],
 receipt:['M5 3h14v18l-3-2-4 2-4-2-3 2z','M8 7h8 M8 11h8 M8 15h4'],
 sun:['M12 8a4 4 0 1 0 0 8 4 4 0 0 0 0-8 M12 2v2 M12 20v2 M2 12h2 M20 12h2 M5 5l1 1 M18 18l1 1 M5 19l1-1 M18 6l1-1'],
 inbox:['M3 3h18v18H3z','M3 13h5l2 3h4l2-3h5'],back:['M20 12H4 M10 6l-6 6 6 6'],
}
</script>
<template><svg :width="size" :height="size" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path v-for="(d,i) in paths[name]||paths.box" :key="i" :d="d" /></svg></template>
